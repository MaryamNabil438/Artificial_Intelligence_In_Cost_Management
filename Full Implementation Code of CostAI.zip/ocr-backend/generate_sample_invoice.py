#!/usr/bin/env python3
"""
Generate a sample invoice image for testing OCR.
Usage: python generate_sample_invoice.py
Output: sample_invoice.png
"""

from PIL import Image, ImageDraw, ImageFont
import os

def generate_sample_invoice():
    """Create a simple invoice image for OCR testing"""

    # Create a white image (8.5" x 11" at 150 DPI)
    width, height = 1275, 1650
    img = Image.new('RGB', (width, height), 'white')
    draw = ImageDraw.Draw(img)

    # Try to use a standard font, fallback to default
    try:
        font_large = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 36)
        font_medium = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 24)
        font_small = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 18)
    except:
        # Fallback to default font
        font_large = ImageFont.load_default()
        font_medium = ImageFont.load_default()
        font_small = ImageFont.load_default()

    y = 50

    # Company header
    draw.text((50, y), "ACME CORPORATION", fill='black', font=font_large)
    y += 60
    draw.text((50, y), "123 Business Street, Suite 100", fill='black', font=font_small)
    y += 30
    draw.text((50, y), "San Francisco, CA 94105", fill='black', font=font_small)
    y += 80

    # Invoice title
    draw.text((50, y), "INVOICE", fill='black', font=font_large)
    y += 80

    # Invoice details
    draw.text((50, y), "Invoice Number: INV-2024-001", fill='black', font=font_medium)
    y += 40
    draw.text((50, y), "Invoice Date: May 11, 2026", fill='black', font=font_medium)
    y += 40
    draw.text((50, y), "Due Date: June 10, 2026", fill='black', font=font_medium)
    y += 80

    # Bill to section
    draw.text((50, y), "BILL TO:", fill='black', font=font_medium)
    y += 40
    draw.text((50, y), "ABC Company", fill='black', font=font_small)
    y += 30
    draw.text((50, y), "456 Client Avenue", fill='black', font=font_small)
    y += 30
    draw.text((50, y), "New York, NY 10001", fill='black', font=font_small)
    y += 80

    # Line items header
    draw.text((50, y), "Description", fill='black', font=font_medium)
    draw.text((700, y), "Quantity", fill='black', font=font_medium)
    draw.text((900, y), "Price", fill='black', font=font_medium)
    draw.text((1050, y), "Total", fill='black', font=font_medium)
    y += 10
    draw.line([(50, y), (1200, y)], fill='black', width=2)
    y += 30

    # Line items
    items = [
        ("Professional Services - Web Development", "40 hrs", "$150.00", "$6,000.00"),
        ("Consulting Services", "8 hrs", "$200.00", "$1,600.00"),
        ("Software License - Annual", "1", "$2,500.00", "$2,500.00"),
    ]

    for desc, qty, price, total in items:
        draw.text((50, y), desc, fill='black', font=font_small)
        draw.text((700, y), qty, fill='black', font=font_small)
        draw.text((900, y), price, fill='black', font=font_small)
        draw.text((1050, y), total, fill='black', font=font_small)
        y += 40

    y += 20
    draw.line([(50, y), (1200, y)], fill='black', width=1)
    y += 30

    # Totals
    draw.text((900, y), "Subtotal:", fill='black', font=font_medium)
    draw.text((1050, y), "$10,100.00", fill='black', font=font_medium)
    y += 40
    draw.text((900, y), "Tax (8.5%):", fill='black', font=font_medium)
    draw.text((1050, y), "$858.50", fill='black', font=font_medium)
    y += 40
    draw.line([(900, y), (1200, y)], fill='black', width=2)
    y += 30
    draw.text((900, y), "Total Amount:", fill='black', font=font_large)
    draw.text((1050, y), "$10,958.50", fill='black', font=font_large)
    y += 80

    # Payment terms
    draw.text((50, y), "Payment Terms: Net 30 days", fill='black', font=font_small)
    y += 30
    draw.text((50, y), "Please make checks payable to: ACME Corporation", fill='black', font=font_small)
    y += 30
    draw.text((50, y), "Bank Transfer: Account #12345678, Routing #987654321", fill='black', font=font_small)

    # Save the image
    output_path = "sample_invoice.png"
    img.save(output_path, "PNG")
    print(f"✓ Sample invoice generated: {output_path}")
    print(f"  Size: {os.path.getsize(output_path) / 1024:.1f} KB")
    print(f"  Dimensions: {width} x {height} px")
    print("\nTest the OCR backend with:")
    print(f"  python test_ocr.py {output_path}")

    return output_path

if __name__ == "__main__":
    generate_sample_invoice()
