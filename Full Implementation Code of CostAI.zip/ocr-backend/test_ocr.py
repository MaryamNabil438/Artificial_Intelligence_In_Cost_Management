#!/usr/bin/env python3
"""
Quick test script for the OCR endpoint.
Usage: python test_ocr.py <path-to-image>
"""

import sys
import requests
import json

def test_ocr(image_path: str):
    """Test the OCR endpoint with an image file"""
    url = "http://localhost:8000/process-document"

    print(f"Testing OCR with: {image_path}")
    print(f"Endpoint: {url}\n")

    try:
        with open(image_path, 'rb') as f:
            files = {'file': f}
            response = requests.post(url, files=files)

        if response.status_code == 200:
            data = response.json()
            print("✓ Success!\n")
            print(f"Pages processed: {data.get('page_count', 'N/A')}")
            print(f"Fields extracted: {len(data.get('fields', []))}\n")

            print("Extracted Fields:")
            print("-" * 60)
            for field in data.get('fields', []):
                confidence_pct = int(field['confidence'] * 100)
                print(f"{field['label']:20s} | {field['value']:25s} | {confidence_pct}%")

            print("\n" + "=" * 60)
            print("Raw Text Preview:")
            print("=" * 60)
            raw_text = data.get('raw_text', '')
            print(raw_text[:500] + ("..." if len(raw_text) > 500 else ""))

        else:
            print(f"✗ Error: {response.status_code}")
            print(response.text)

    except FileNotFoundError:
        print(f"✗ Error: File not found: {image_path}")
    except requests.exceptions.ConnectionError:
        print("✗ Error: Cannot connect to OCR backend.")
        print("Make sure the server is running: python main.py")
    except Exception as e:
        print(f"✗ Error: {e}")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python test_ocr.py <path-to-image>")
        print("Example: python test_ocr.py invoice.png")
        sys.exit(1)

    test_ocr(sys.argv[1])
