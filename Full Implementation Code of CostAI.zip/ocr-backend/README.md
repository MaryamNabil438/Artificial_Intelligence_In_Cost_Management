# Document OCR Backend

FastAPI endpoint for processing financial documents using Google Document AI Form Parser.

## Architecture

1. **Preprocessing**: OpenCV deskew, denoise, contrast enhancement
2. **OCR**: Google Document AI Form Parser API
3. **Response**: Structured JSON with field names, values, and confidence scores

## Setup

### 1. Install Dependencies

```bash
cd ocr-backend
pip install -r requirements.txt
```

### 2. Google Document AI Setup

#### Create a Processor

1. Go to [Google Cloud Console](https://console.cloud.google.com)
2. Enable Document AI API
3. Navigate to Document AI → Processors
4. Click "Create Processor"
5. Select **Form Parser**
6. Choose region (e.g., `us`)
7. Copy the Processor ID (format: `abc123def456...`)

#### Create Service Account

1. Go to IAM & Admin → Service Accounts
2. Create a new service account
3. Grant role: **Document AI API User**
4. Create and download JSON key
5. Save as `service-account-key.json` in this directory

### 3. Environment Variables

```bash
cp .env.example .env
```

Edit `.env`:
```
GOOGLE_CLOUD_PROJECT_ID=your-gcp-project-id
GOOGLE_CLOUD_LOCATION=us
GOOGLE_DOCUMENT_AI_PROCESSOR_ID=abc123def456...
GOOGLE_APPLICATION_CREDENTIALS=./service-account-key.json
```

### 4. Run the Server

```bash
python main.py
```

Server runs on `http://localhost:8000`

## API Endpoints

### POST /process-document

Upload and process a document image.

**Request:**
- Content-Type: `multipart/form-data`
- Body: `file` (image file: PNG, JPG, PDF)

**Response:**
```json
{
  "success": true,
  "fields": [
    {
      "label": "Invoice Number",
      "value": "INV-001",
      "confidence": 0.95,
      "key": "invoice_number"
    },
    {
      "label": "Total Amount",
      "value": "$4,120.00",
      "confidence": 0.92,
      "key": "total_amount"
    }
  ],
  "raw_text": "Full extracted text...",
  "page_count": 1
}
```

### GET /health

Health check endpoint.

## Testing

Test with curl:

```bash
curl -X POST "http://localhost:8000/process-document" \
  -H "accept: application/json" \
  -H "Content-Type: multipart/form-data" \
  -F "file=@/path/to/invoice.png"
```

## Google Document AI Pricing

- **Free Tier**: 1,000 pages/month
- **Beyond Free**: $1.50 per 1,000 pages

## Frontend Integration

Update `AIDocumentScanModal.tsx` to call this endpoint:

```typescript
const handleScan = async () => {
  if (!file) return;

  setStage('preprocessing');
  
  const formData = new FormData();
  formData.append('file', file);

  try {
    const response = await fetch('http://localhost:8000/process-document', {
      method: 'POST',
      body: formData,
    });

    const data = await response.json();
    
    if (data.success) {
      setExtractedFields(data.fields);
      setStage('complete');
    }
  } catch (error) {
    console.error('OCR failed:', error);
  }
};
```

## Next Steps

Once OCR works:
1. Connect Supabase for storage
2. Store images in Supabase Storage
3. Store extracted data in PostgreSQL table
4. Build document repository queries
