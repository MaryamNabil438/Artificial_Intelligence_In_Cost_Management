#!/bin/bash
# Quick setup script for OCR backend

echo "=== Document OCR Backend Setup ==="
echo ""

# Check Python version
if ! command -v python3 &> /dev/null; then
    echo "✗ Python 3 not found. Please install Python 3.8 or higher."
    exit 1
fi

echo "✓ Python 3 found: $(python3 --version)"

# Create virtual environment
if [ ! -d "venv" ]; then
    echo "Creating virtual environment..."
    python3 -m venv venv
    echo "✓ Virtual environment created"
else
    echo "✓ Virtual environment already exists"
fi

# Activate virtual environment
echo "Activating virtual environment..."
source venv/bin/activate

# Install dependencies
echo "Installing dependencies..."
pip install --upgrade pip
pip install -r requirements.txt

echo ""
echo "✓ Setup complete!"
echo ""
echo "Next steps:"
echo "1. Set up Google Document AI (see QUICKSTART.md)"
echo "2. Copy .env.example to .env and add your credentials"
echo "3. Activate the virtual environment:"
echo "   source venv/bin/activate"
echo "4. Run the server:"
echo "   python main.py"
echo ""
