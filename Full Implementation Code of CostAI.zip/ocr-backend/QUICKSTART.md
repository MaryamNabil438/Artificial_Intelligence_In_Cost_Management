# Quick Start Guide - OCR Backend

Get the document scanning backend running in ~10 minutes.

## Step 1: Google Cloud Setup (5 minutes)

### Create Google Cloud Project

1. Go to [console.cloud.google.com](https://console.cloud.google.com)
2. Create new project or select existing one
3. Note your Project ID (e.g., `my-ocr-project-123`)

### Enable Document AI API

1. In Google Cloud Console, go to **APIs & Services** → **Library**
2. Search for "Document AI API"
3. Click **Enable**

### Create Form Parser Processor

1. Go to **Document AI** → **Processors**
2. Click **Create Processor**
3. Select **Form Parser**
4. Choose region: **us** (recommended)
5. Click **Create**
6. Copy the **Processor ID** (long alphanumeric string like `abc123def456...`)

### Create Service Account

1. Go to **IAM & Admin** → **Service Accounts**
2. Click **Create Service Account**
3. Name: `document-ocr-service`
4. Click **Create and Continue**
5. Grant role: **Document AI API User**
6. Click **Continue** → **Done**
7. Click on the service account you just created
8. Go to **Keys** tab
9. Click **Add Key** → **Create New Key** → **JSON**
10. Download the JSON file
11. Save it as `service-account-key.json` in the `ocr-backend/` directory

## Step 2: Install Backend (2 minutes)

```bash
cd ocr-backend

# Run setup script
./setup.sh

# Or manually:
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

## Step 3: Configure Environment (1 minute)

```bash
cp .env.example .env
```

Edit `.env`:
```
GOOGLE_CLOUD_PROJECT_ID=my-ocr-project-123
GOOGLE_CLOUD_LOCATION=us
GOOGLE_DOCUMENT_AI_PROCESSOR_ID=abc123def456...
GOOGLE_APPLICATION_CREDENTIALS=./service-account-key.json
```

## Step 4: Run the Server (30 seconds)

```bash
source venv/bin/activate  # If not already activated
python main.py
```

You should see:
```
INFO:     Uvicorn running on http://0.0.0.0:8000
```

## Step 5: Test It

Generate a sample invoice for testing:
```bash
cd ocr-backend
python generate_sample_invoice.py
# Creates sample_invoice.png
```

Test OCR with the sample:
```bash
./test_ocr.py sample_invoice.png
```

Or use your own document:
```bash
./test_ocr.py /path/to/your-invoice.png
```

Or test with curl:
```bash
curl -X POST http://localhost:8000/process-document \
  -F "file=@sample_invoice.png"
```

## Verify Frontend Connection

1. Open the Figma Make app
2. Go to Finance Manager → AI Document Scan
3. Upload a document
4. You should see real extracted fields instead of errors

## Troubleshooting

### "Failed to fetch" error
- Make sure backend is running: `python main.py`
- Check it's on port 8000: `curl http://localhost:8000/health`

### "Permission denied" error
- Verify service account key path in `.env`
- Check service account has "Document AI API User" role

### "Processor not found" error
- Double-check Processor ID in `.env`
- Verify processor region matches `GOOGLE_CLOUD_LOCATION`

### Poor extraction quality
- Try higher resolution images (300 DPI minimum)
- Ensure document is well-lit and not skewed
- Remove shadows and creases if possible

## Costs

- **Free tier**: 1,000 pages/month
- **Beyond free tier**: $1.50 per 1,000 pages
- See [pricing](https://cloud.google.com/document-ai/pricing)

## Next Steps

Once OCR works:
1. Connect Supabase for document storage
2. Store images in Supabase Storage
3. Save extracted data to PostgreSQL
4. Build document search and analytics
