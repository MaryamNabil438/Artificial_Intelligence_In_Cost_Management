from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from google.cloud import documentai_v1 as documentai
import cv2
import numpy as np
from typing import List, Dict
import os
import io
from PIL import Image

app = FastAPI()

# CORS for frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Google Document AI configuration
PROJECT_ID = os.getenv("GOOGLE_CLOUD_PROJECT_ID")
LOCATION = os.getenv("GOOGLE_CLOUD_LOCATION", "us")
PROCESSOR_ID = os.getenv("GOOGLE_DOCUMENT_AI_PROCESSOR_ID")

def preprocess_image(image_bytes: bytes) -> bytes:
    """Preprocess image: deskew, denoise, normalize contrast"""
    # Convert bytes to numpy array
    nparr = np.frombuffer(image_bytes, np.uint8)
    img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)

    if img is None:
        raise ValueError("Failed to decode image")

    # Convert to grayscale
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    # Denoise
    denoised = cv2.fastNlMeansDenoising(gray, None, 10, 7, 21)

    # Normalize contrast using CLAHE
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    contrast_enhanced = clahe.apply(denoised)

    # Deskew
    coords = np.column_stack(np.where(contrast_enhanced > 0))
    angle = cv2.minAreaRect(coords)[-1]
    if angle < -45:
        angle = -(90 + angle)
    else:
        angle = -angle

    if abs(angle) > 0.5:  # Only deskew if angle is significant
        (h, w) = contrast_enhanced.shape
        center = (w // 2, h // 2)
        M = cv2.getRotationMatrix2D(center, angle, 1.0)
        deskewed = cv2.warpAffine(
            contrast_enhanced, M, (w, h),
            flags=cv2.INTER_CUBIC,
            borderMode=cv2.BORDER_REPLICATE
        )
    else:
        deskewed = contrast_enhanced

    # Convert back to bytes
    _, buffer = cv2.imencode('.png', deskewed)
    return buffer.tobytes()

def extract_fields_from_document(document: documentai.Document) -> List[Dict]:
    """Extract fields with confidence scores from Document AI response"""
    fields = []

    # Extract form fields (key-value pairs)
    for page in document.pages:
        for field in page.form_fields:
            # Get field name
            field_name = ""
            if field.field_name.text_anchor.text_segments:
                field_name = field.field_name.text_anchor.text_segments[0].start_index
                field_name = document.text[
                    field.field_name.text_anchor.text_segments[0].start_index:
                    field.field_name.text_anchor.text_segments[0].end_index
                ].strip()

            # Get field value
            field_value = ""
            if field.field_value.text_anchor.text_segments:
                field_value = document.text[
                    field.field_value.text_anchor.text_segments[0].start_index:
                    field.field_value.text_anchor.text_segments[0].end_index
                ].strip()

            # Get confidence
            confidence = field.field_value.confidence if field.field_value.confidence else 0.0

            if field_name and field_value:
                fields.append({
                    "label": field_name,
                    "value": field_value,
                    "confidence": round(confidence, 2),
                    "key": field_name.lower().replace(" ", "_")
                })

    return fields

@app.post("/process-document")
async def process_document(file: UploadFile = File(...)):
    """Process uploaded document with Google Document AI"""
    try:
        # Read uploaded file
        image_bytes = await file.read()

        # Preprocess image
        preprocessed_bytes = preprocess_image(image_bytes)

        # Initialize Document AI client
        client = documentai.DocumentProcessorServiceClient()

        # Configure the process request
        name = client.processor_path(PROJECT_ID, LOCATION, PROCESSOR_ID)

        # Create the document
        raw_document = documentai.RawDocument(
            content=preprocessed_bytes,
            mime_type="image/png"
        )

        # Process the document
        request = documentai.ProcessRequest(
            name=name,
            raw_document=raw_document
        )

        result = client.process_document(request=request)
        document = result.document

        # Extract structured fields
        fields = extract_fields_from_document(document)

        # Also extract full text for fallback
        full_text = document.text

        return {
            "success": True,
            "fields": fields,
            "raw_text": full_text,
            "page_count": len(document.pages)
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Processing failed: {str(e)}")

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "service": "document-ocr"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
