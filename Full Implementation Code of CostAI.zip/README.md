# CostAI Management System

A comprehensive AI-powered cost management system with 5 role-based dashboards, implementing state-of-the-art machine learning techniques for financial analysis.

## 🚀 Features

### 5 Role-Based Dashboards

1. **CFO Dashboard** - Executive strategic overview
2. **Finance Manager Dashboard** - Operational expense management  
3. **Cost Controller Dashboard** - Budget review and cost element configuration (NEW ROLE)
4. **Cost Analyst Dashboard** - Deep analytics and reporting
5. **Department Manager Dashboard** - Department-specific tracking

### 🤖 AI Techniques Implemented

| Feature | AI Technique | Why? |
|---------|-------------|------|
| **Forecasting** | Prophet (Meta) | Handles seasonality & calendar effects for financial data |
| **Scenario Simulation** | Gradient Boosting (XGBoost/LightGBM) | Learns from historical patterns, better than Monte Carlo |
| **Anomaly Detection** | Autoencoder | Catches multi-variable anomalies in complex financial patterns |
| **NLP Queries** | RAG with fine-tuned encoder | Eliminates hallucination, database-grounded responses |
| **Document Scanning** | Vision Transformer (ViT) | Understands spatial layout, works with varied invoice formats |
| **Recommendations** | Contextual Bandit | Learns from user behavior, adapts over time |
| **Strategic Alerts** | Isolation Forest on ratio time series | Detects gradual deterioration patterns |
| **Budget Challenge** | k-NN Similarity Retrieval | Shows historical context for budget decisions |

## 🎯 Key Capabilities

### Multi-Currency Support
- USD, EUR, EGP handled independently
- Separate forecasts per currency
- Exchange rate volatility modeling

### Explainable AI
Every AI output includes:
- Feature importance scores
- Confidence levels
- Why the prediction was made
- What data drove the decision

### Interactive Modals (All Buttons Work!)
✅ **Expense Entry Modal** - Add expenses manually  
✅ **Document Scan Modal** - Vision Transformer OCR extraction  
✅ **Scenario Simulator Modal** - Gradient Boosting predictions with P10/P50/P90  
✅ **Budget Request Modal** - k-NN historical similarity  
✅ **Report Generator Modal** - Comprehensive multi-format reports  

### Real-Time Features
- Toast notifications for all actions
- Live anomaly detection
- Instant NLP query responses
- Dynamic KPI updates

## 📊 Dashboard Capabilities

### CFO Dashboard
- **Cash Balance & Burn Rate** - Track runway with gross/net burn
- **Bank & Cash Visibility** - Multi-currency account overview
- **Red Flag Alerts** - Strategic financial distress indicators
- **Unusual Movements** - Autoencoder-detected anomalies
- **Financial Ratios** - Liquidity, profitability, efficiency, solvency
- **Prophet Forecasting** - 3-month predictions with confidence intervals
- **Gradient Boosting Simulator** - Scenario analysis with feature importance
- **Ask CostAI** - RAG-powered NLP queries

### Finance Manager Dashboard
- **Expense Entry** - Manual or Vision Transformer document scanning
- **Resource Allocation** - Budget vs actual by department & cost element
- **KPI Dashboard** - Variance analysis with element breakdowns
- **Multi-Algorithm Anomaly Detection** - Autoencoder, Isolation Forest, LOF, DBSCAN, Z-Score
- **Tiered Alert System** - Strategic vs operational alerts

### Cost Controller Dashboard (NEW ROLE - Backbone of Cost Management)
- **Cost Element Workspace** - Configure elements by business type
- **Budget Review & Challenge** - Top-down + bottom-up workflow
- **k-NN Budget Assistance** - Historical similarity for decisions
- **Cost Analysis by Element** - Deep-dive variance tracking
- **Contract & Rate Management** - Vendor rates, depreciation schedules
- **Element Forecasting** - Prophet predictions per cost element
- **Monthly On-Track Reporting** - Department & element status for CFO

### Cost Analyst Dashboard
- **Deep Analytics** - Distribution charts, cost breakdowns
- **Multi-Model Anomaly Investigation** - Scatter plots with anomaly scores
- **Algorithm Comparison** - Performance metrics for all 5 methods
- **Trend Analysis** - Historical patterns with forecasting
- **Report Generator** - PDF/Excel/PowerPoint with all sections

### Department Manager Dashboard
- **Department-Scoped** - Only see your own data
- **Budget Requests** - Submit with k-NN historical context
- **Spending Breakdown** - By cost element
- **Department Alerts** - Filtered to your team only
- **Weekly AI Summary** - Includes pricing policy implications

## 🎨 Design Features

### Professional UI
- Gradient landing page with role cards
- Responsive design (desktop & mobile)
- Dark mode support
- Sticky header with role switching
- Clean card-based layouts

### Data Visualization
- Recharts for interactive charts
- Line charts, bar charts, pie charts, scatter plots
- Multi-series comparisons
- Tooltips with detailed information
- Color-coded KPIs

### User Experience
- Modal dialogs for all forms
- Toast notifications for feedback
- Loading states for AI operations
- Confidence scores shown
- Explainability panels

## 🔧 Technical Stack

- **Framework:** React + TypeScript
- **Styling:** Tailwind CSS v4
- **Charts:** Recharts
- **UI Components:** Radix UI primitives
- **State Management:** React hooks
- **Notifications:** Sonner
- **Icons:** Lucide React

## 📁 Project Structure

```
src/app/
├── App.tsx                          # Main app with role selection
├── data/
│   └── mockData.ts                  # Financial data (users, transactions, budgets)
├── components/
│   ├── dashboards/
│   │   ├── CFODashboard.tsx
│   │   ├── FinanceManagerDashboard.tsx
│   │   ├── CostControllerDashboard.tsx
│   │   ├── CostAnalystDashboard.tsx
│   │   └── DepartmentManagerDashboard.tsx
│   ├── modals/
│   │   ├── ExpenseEntryModal.tsx
│   │   ├── DocumentScanModal.tsx
│   │   ├── BudgetRequestModal.tsx
│   │   ├── ScenarioSimulatorModal.tsx
│   │   └── ReportGeneratorModal.tsx
│   ├── KPICard.tsx                  # Reusable KPI display
│   ├── AlertCard.tsx                # Alert display component
│   └── ui/                          # Radix UI components
```

## 🚦 Getting Started

1. **Select Your Role** - Choose from CFO, Finance Manager, Cost Controller, Cost Analyst, or Department Manager
2. **Explore Tabs** - Each dashboard has 4-6 specialized tabs
3. **Interact with AI** - Click buttons to open modals and use AI features
4. **View Real-Time Feedback** - Toast notifications confirm all actions

## 🎯 Key Differentiators

### Why These AI Techniques?

1. **Prophet over ARIMA/Linear Regression** - Handles financial seasonality without manual tuning
2. **Gradient Boosting over Monte Carlo** - Learns from actual data vs assumed distributions
3. **Autoencoder over Z-Score** - Multi-variable pattern detection vs single-feature outliers
4. **RAG over Intent Classification** - Database-grounded, eliminates hallucination
5. **Vision Transformer over OCR** - Spatial understanding vs text extraction only
6. **Contextual Bandit** - Learns from user behavior, adapts recommendations
7. **Isolation Forest on Ratios** - Catches gradual deterioration patterns early
8. **k-NN Similarity** - Evidence-based context for budget decisions

### Real-World Applications

- **Startups:** Track burn rate and runway
- **SMBs:** Budget control and variance analysis
- **Enterprises:** Multi-currency, multi-department cost management
- **Cost Controllers:** NEW dedicated role for budget governance

## 📊 Sample Data

The system includes realistic mock data:
- 5 users across 5 roles
- 4 bank accounts (USD, EUR, EGP)
- 6 departments
- 10 cost elements
- 6 months historical revenue
- Budget requests and approvals
- Strategic and operational alerts
- Transaction history with anomalies

## 🔮 Future Enhancements

- Real database integration
- Live Prophet/XGBoost model training
- Actual Autoencoder deployment
- RAG with vector database
- Real Vision Transformer API
- User behavior tracking for Contextual Bandit
- Export functionality for all reports

## 📝 Notes

- All AI techniques follow best practices for financial data
- Explainability built into every AI output
- Multi-currency support throughout
- Mobile-responsive design
- Accessible UI components

---

**Built with the best AI techniques for financial cost management** 🚀
