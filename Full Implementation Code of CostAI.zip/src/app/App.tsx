import { useState } from 'react';
import { Button } from './components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from './components/ui/card';
import { Badge } from './components/ui/badge';
import { CFODashboard } from './components/dashboards/CFODashboard';
import { FinanceManagerDashboard } from './components/dashboards/FinanceManagerDashboard';
import { CostControllerDashboard } from './components/dashboards/CostControllerDashboard';
import { CostAnalystDashboard } from './components/dashboards/CostAnalystDashboard';
import { DepartmentManagerDashboard } from './components/dashboards/DepartmentManagerDashboard';
import { users, alerts } from './data/mockData';
import { BarChart3, TrendingUp, Shield, Search, Users, LogOut, Bell } from 'lucide-react';
import { Toaster } from './components/ui/sonner';
import { GlobalSearch } from './components/GlobalSearch';
import { NotificationPreferences } from './components/NotificationPreferences';
import { Popover, PopoverContent, PopoverTrigger } from './components/ui/popover';

type UserRole = 'CFO' | 'Finance Manager' | 'Cost Controller' | 'Cost Analyst' | 'Department Manager';

export default function App() {
  const [selectedRole, setSelectedRole] = useState<UserRole | null>(null);
  const [selectedUser, setSelectedUser] = useState<typeof users[0] | null>(null);
  const [searchOpen, setSearchOpen] = useState(false);
  const [notificationPrefsOpen, setNotificationPrefsOpen] = useState(false);
  const [notificationDropdownOpen, setNotificationDropdownOpen] = useState(false);

  const unreadAlerts = alerts.filter(a => a.severity === 'critical' || a.severity === 'high').length;

  const handleRoleSelect = (user: typeof users[0]) => {
    setSelectedUser(user);
    setSelectedRole(user.role as UserRole);
  };

  const handleLogout = () => {
    setSelectedRole(null);
    setSelectedUser(null);
  };

  const roleIcons = {
    'CFO': BarChart3,
    'Finance Manager': TrendingUp,
    'Cost Controller': Shield,
    'Cost Analyst': Search,
    'Department Manager': Users,
  };

  const roleDescriptions = {
    'CFO': 'Executive overview with strategic insights, forecasting, scenario simulation, and risk indicators',
    'Finance Manager': 'Expense tracking, resource allocation, KPI monitoring, and document scanning',
    'Cost Controller': 'Budget review, cost element configuration, contract management, and monthly reporting',
    'Cost Analyst': 'Deep analytics, multi-model anomaly detection, trend analysis, and comprehensive reporting',
    'Department Manager': 'Department-specific budget tracking, spending breakdown, and AI-powered summaries',
  };

  if (!selectedRole) {
    return (
      <>
        <Toaster />
        <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800 p-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12 mt-8">
            <div className="flex items-center justify-center gap-3 mb-4">
              <BarChart3 className="size-12 text-blue-600 dark:text-blue-400" />
              <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
                CostAI Management System
              </h1>
            </div>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              AI-powered cost management with multi-role dashboards, ML-based forecasting, anomaly detection, and comprehensive financial insights
            </p>
            <div className="flex items-center justify-center gap-2 mt-4">
              <Badge variant="outline">Multi-Currency Support</Badge>
              <Badge variant="outline">AI-Powered Analytics</Badge>
              <Badge variant="outline">Real-time Alerts</Badge>
              <Badge variant="outline">Smart Forecasting</Badge>
            </div>
          </div>

          <div className="mb-8">
            <h2 className="text-2xl font-bold text-center mb-6">Select Your Role</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {users.map((user) => {
                const Icon = roleIcons[user.role as UserRole];
                return (
                  <Card
                    key={user.id}
                    className="cursor-pointer hover:shadow-lg transition-all hover:scale-105 hover:border-blue-500"
                    onClick={() => handleRoleSelect(user)}
                  >
                    <CardHeader>
                      <div className="flex items-center gap-3 mb-2">
                        <div className="p-3 bg-blue-100 dark:bg-blue-900 rounded-lg">
                          <Icon className="size-6 text-blue-600 dark:text-blue-400" />
                        </div>
                        <div className="flex-1">
                          <CardTitle className="text-lg">{user.role}</CardTitle>
                          {user.role === 'Cost Controller' && (
                            <Badge variant="default" className="mt-1">NEW ROLE</Badge>
                          )}
                        </div>
                      </div>
                      <CardDescription className="text-sm leading-relaxed">
                        {roleDescriptions[user.role as UserRole]}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-muted-foreground">{user.name}</span>
                        {user.department && (
                          <Badge variant="outline">{user.department}</Badge>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>

          <Card className="border-2 border-blue-200 dark:border-blue-800 bg-blue-50 dark:bg-blue-950/20">
            <CardHeader>
              <CardTitle className="text-lg">Key AI Upgrades in This System</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                <div>
                  <h4 className="font-semibold mb-2">NLP Engine</h4>
                  <p className="text-muted-foreground">ML-based intent classification + Named Entity Recognition (upgraded from keyword matching)</p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Forecasting</h4>
                  <p className="text-muted-foreground">Company + Department + Cost Element level (upgraded from company-wide only)</p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Anomaly Detection</h4>
                  <p className="text-muted-foreground">5 algorithms: Z-score, Isolation Forest, LOF, DBSCAN, Autoencoder</p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Scenario Simulation</h4>
                  <p className="text-muted-foreground">Advanced probabilistic simulation with uncertainty modeling</p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Currency Handling</h4>
                  <p className="text-muted-foreground">Multi-currency with independent exchange rates (upgraded from single currency)</p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Explainability</h4>
                  <p className="text-muted-foreground">Feature importance shown for every AI output - transparent and trustworthy</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
      </>
    );
  }

  return (
    <>
      <Toaster />
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <header className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 sticky top-0 z-50">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <BarChart3 className="size-8 text-blue-600 dark:text-blue-400" />
              <div>
                <h1 className="text-xl font-bold">CostAI Management System</h1>
                <p className="text-sm text-muted-foreground">
                  {selectedUser?.name} - {selectedRole}
                  {selectedUser?.department && ` (${selectedUser.department})`}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              {/* Search Button */}
              <Button
                variant="outline"
                size="icon"
                onClick={() => setSearchOpen(true)}
                className="relative"
              >
                <Search className="size-4" />
              </Button>

              {/* Notification Bell with Dropdown */}
              <Popover open={notificationDropdownOpen} onOpenChange={setNotificationDropdownOpen}>
                <PopoverTrigger asChild>
                  <Button variant="outline" size="icon" className="relative">
                    <Bell className="size-4" />
                    {unreadAlerts > 0 && (
                      <span className="absolute -top-1 -right-1 size-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
                        {unreadAlerts}
                      </span>
                    )}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-96 p-0" align="end">
                  <div className="p-4 border-b">
                    <div className="flex items-center justify-between">
                      <h3 className="font-semibold">Recent Alerts</h3>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setNotificationPrefsOpen(true)}
                      >
                        Preferences
                      </Button>
                    </div>
                  </div>
                  <div className="max-h-96 overflow-y-auto">
                    {alerts.slice(0, 5).map((alert) => (
                      <div
                        key={alert.id}
                        className="p-4 border-b hover:bg-gray-50 dark:hover:bg-gray-800 cursor-pointer"
                      >
                        <div className="flex items-start justify-between mb-1">
                          <p className="font-medium text-sm">{alert.title}</p>
                          <Badge
                            variant={alert.severity === 'critical' || alert.severity === 'high' ? 'destructive' : 'outline'}
                            className="ml-2"
                          >
                            {alert.severity}
                          </Badge>
                        </div>
                        <p className="text-xs text-muted-foreground line-clamp-2">
                          {alert.description}
                        </p>
                        <p className="text-xs text-muted-foreground mt-1">
                          {new Date(alert.timestamp).toLocaleString()}
                        </p>
                      </div>
                    ))}
                  </div>
                  <div className="p-3 border-t text-center">
                    <Button variant="link" size="sm" className="w-full">
                      View All Alerts
                    </Button>
                  </div>
                </PopoverContent>
              </Popover>

              {/* Logout Button */}
              <Button onClick={handleLogout} variant="outline" className="flex items-center gap-2">
                <LogOut className="size-4" />
                Switch Role
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main>
        {selectedRole === 'CFO' && <CFODashboard />}
        {selectedRole === 'Finance Manager' && <FinanceManagerDashboard />}
        {selectedRole === 'Cost Controller' && <CostControllerDashboard />}
        {selectedRole === 'Cost Analyst' && <CostAnalystDashboard />}
        {selectedRole === 'Department Manager' && <DepartmentManagerDashboard />}
      </main>

      {/* Global Modals */}
      <GlobalSearch open={searchOpen} onClose={() => setSearchOpen(false)} />
      <NotificationPreferences open={notificationPrefsOpen} onClose={() => setNotificationPrefsOpen(false)} />
    </div>
    </>
  );
}
