import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from './ui/dialog';
import { Switch } from './ui/switch';
import { Label } from './ui/label';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { toast } from 'sonner';

interface NotificationPreferencesProps {
  open: boolean;
  onClose: () => void;
}

export function NotificationPreferences({ open, onClose }: NotificationPreferencesProps) {
  const [preferences, setPreferences] = useState({
    critical: { email: true, sms: true, push: true },
    high: { email: true, sms: false, push: false },
    medium: { email: false, sms: false, push: false },
  });

  const handleToggle = (category: 'critical' | 'high' | 'medium', channel: 'email' | 'sms' | 'push') => {
    setPreferences({
      ...preferences,
      [category]: {
        ...preferences[category],
        [channel]: !preferences[category][channel],
      },
    });
    toast.success('Notification preferences updated');
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Notification Preferences</DialogTitle>
          <DialogDescription>
            Configure how you want to receive alerts for different severity levels
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Critical Alerts */}
          <Card className="border-red-200 dark:border-red-800">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  Critical Alerts (Strategic Red Flags)
                  <Badge variant="destructive">HIGH PRIORITY</Badge>
                </CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                Financial distress indicators, liquidity issues, asset mismanagement
              </p>
              <div className="grid grid-cols-3 gap-6">
                <div className="flex items-center justify-between">
                  <Label htmlFor="critical-email" className="flex items-center gap-2">
                    Email Notifications
                  </Label>
                  <Switch
                    id="critical-email"
                    checked={preferences.critical.email}
                    onCheckedChange={() => handleToggle('critical', 'email')}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="critical-sms" className="flex items-center gap-2">
                    SMS Notifications
                  </Label>
                  <Switch
                    id="critical-sms"
                    checked={preferences.critical.sms}
                    onCheckedChange={() => handleToggle('critical', 'sms')}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="critical-push" className="flex items-center gap-2">
                    Push Notifications
                  </Label>
                  <Switch
                    id="critical-push"
                    checked={preferences.critical.push}
                    onCheckedChange={() => handleToggle('critical', 'push')}
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* High Severity Alerts */}
          <Card className="border-orange-200 dark:border-orange-800">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  High Severity Alerts
                  <Badge variant="destructive">MEDIUM PRIORITY</Badge>
                </CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                Budget overruns, unusual payment patterns, vendor anomalies
              </p>
              <div className="grid grid-cols-3 gap-6">
                <div className="flex items-center justify-between">
                  <Label htmlFor="high-email" className="flex items-center gap-2">
                    Email Notifications
                  </Label>
                  <Switch
                    id="high-email"
                    checked={preferences.high.email}
                    onCheckedChange={() => handleToggle('high', 'email')}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="high-sms" className="flex items-center gap-2">
                    SMS Notifications
                  </Label>
                  <Switch
                    id="high-sms"
                    checked={preferences.high.sms}
                    onCheckedChange={() => handleToggle('high', 'sms')}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="high-push" className="flex items-center gap-2">
                    Push Notifications
                  </Label>
                  <Switch
                    id="high-push"
                    checked={preferences.high.push}
                    onCheckedChange={() => handleToggle('high', 'push')}
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Low/Medium Alerts */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  Low/Medium Alerts
                  <Badge variant="outline">LOW PRIORITY</Badge>
                </CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                Informational alerts, minor variances, scheduled reminders
              </p>
              <div className="grid grid-cols-3 gap-6">
                <div className="flex items-center justify-between">
                  <Label htmlFor="medium-email" className="flex items-center gap-2">
                    Email Notifications
                  </Label>
                  <Switch
                    id="medium-email"
                    checked={preferences.medium.email}
                    onCheckedChange={() => handleToggle('medium', 'email')}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="medium-sms" className="flex items-center gap-2">
                    SMS Notifications
                  </Label>
                  <Switch
                    id="medium-sms"
                    checked={preferences.medium.sms}
                    onCheckedChange={() => handleToggle('medium', 'sms')}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="medium-push" className="flex items-center gap-2">
                    Push Notifications
                  </Label>
                  <Switch
                    id="medium-push"
                    checked={preferences.medium.push}
                    onCheckedChange={() => handleToggle('medium', 'push')}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </DialogContent>
    </Dialog>
  );
}
