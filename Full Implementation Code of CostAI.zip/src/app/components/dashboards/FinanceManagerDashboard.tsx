import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../ui/card';
import { KPICard } from '../KPICard';
import { AlertCard } from '../AlertCard';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Badge } from '../ui/badge';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { departmentCosts, costElementBreakdown, alerts, transactions } from '../../data/mockData';
import { Upload, MessageSquare, FileText, Plus, Edit, Database, AlertCircle, Scan } from 'lucide-react';
import { useState } from 'react';
import { ExpenseEntryModal } from '../modals/ExpenseEntryModal';
import { AIDocumentScanModal } from '../modals/AIDocumentScanModal';
import { DocumentRepositoryModal } from '../modals/DocumentRepositoryModal';
import { ReviewQueueModal } from '../modals/ReviewQueueModal';
import { toast } from 'sonner';

export function FinanceManagerDashboard() {
  const [nlpQuery, setNlpQuery] = useState('');
  const [nlpResponse, setNlpResponse] = useState('');
  const [selectedDetection, setSelectedDetection] = useState('isolation-forest');
  const [expenseModalOpen, setExpenseModalOpen] = useState(false);
  const [scanModalOpen, setScanModalOpen] = useState(false);
  const [repositoryModalOpen, setRepositoryModalOpen] = useState(false);
  const [reviewQueueModalOpen, setReviewQueueModalOpen] = useState(false);
  const [expenses, setExpenses] = useState<any[]>([]);
  const [documents, setDocuments] = useState<any[]>([
    {
      id: 1,
      type: 'Invoice',
      invoiceNumber: 'INV-2026-0512',
      vendor: 'AWS Egypt',
      date: '2026-05-08',
      amount: '57,555.00',
      currency: 'EGP',
      tax: '7,822.43',
      costElement: 'Software Licenses',
      department: 'Engineering',
      status: 'verified',
      confidence: 0.96,
      uploadDate: '2026-05-08T10:30:00',
    },
    {
      id: 2,
      type: 'Receipt',
      receiptNumber: 'RCP-8821-2026',
      vendor: 'Office Depot Cairo',
      date: '2026-05-10',
      amount: '2,340.00',
      currency: 'EGP',
      paymentMethod: 'Credit Card',
      costElement: 'Office Supplies',
      department: 'Operations',
      status: 'verified',
      confidence: 0.93,
      uploadDate: '2026-05-10T14:15:00',
    },
    {
      id: 3,
      type: 'Invoice',
      invoiceNumber: 'INV-2026-0521',
      vendor: 'Freelancer - Ahmed Hassan',
      date: '2026-05-07',
      amount: '8,500.00',
      currency: 'EGP',
      tax: '0.00',
      costElement: 'Contractor Fees',
      department: 'Marketing',
      status: 'pending-review',
      confidence: 0.78,
      uploadDate: '2026-05-11T09:20:00',
    },
  ]);
  const [reviewQueue, setReviewQueue] = useState<any[]>([
    {
      id: 3,
      type: 'Invoice',
      uploadDate: '2026-05-11T09:20:00',
      lowConfidenceFields: [
        { label: 'Vendor Name', value: 'Freelancer - Ahmed Hassan', confidence: 0.72, key: 'vendor' },
        { label: 'Cost Element', value: 'Contractor Fees', confidence: 0.78, key: 'costElement' },
        { label: 'Tax Amount', value: '0.00', confidence: 0.65, key: 'tax' },
      ],
    },
  ]);
  const [costElements, setCostElements] = useState([
    'Wages & Salaries',
    'Electricity & Utilities',
    'Raw Materials',
    'Rent & Facilities',
    'Depreciation',
    'Contractor Fees',
    'Loan Repayments',
    'Software Licenses',
    'Office Supplies',
    'Travel & Entertainment',
  ]);
  const [newElement, setNewElement] = useState('');
  const [selectedDocument, setSelectedDocument] = useState<any>(null);

  const handleNLPQuery = () => {
    const query = nlpQuery.toLowerCase();
    if (query.includes('variance')) {
      setNlpResponse('Marketing has the highest variance at +8.9% ($25K over budget). Engineering is +3.3% over budget. Sales and Operations are performing under budget.');
    } else {
      setNlpResponse('I can help you analyze variances, track expenses, and identify budget concerns. What specific information do you need?');
    }
  };

  const handleExpenseSubmit = (expense: any) => {
    setExpenses([...expenses, expense]);
    toast.success('Expense added successfully!');
  };

  const handleDocumentComplete = (data: any) => {
    // Convert extracted fields to document format
    const fieldsObj: any = {};
    data.fields.forEach((field: any) => {
      fieldsObj[field.key] = field.value;
    });

    const lowConfidenceFields = data.fields.filter((f: any) => f.confidence < 0.85);
    const hasLowConfidence = lowConfidenceFields.length > 0;

    const newDoc = {
      id: documents.length + 1,
      type: data.documentType,
      ...fieldsObj,
      status: hasLowConfidence ? 'pending-review' : 'verified',
      confidence: data.fields.reduce((sum: number, f: any) => sum + f.confidence, 0) / data.fields.length,
      uploadDate: data.scanDate,
      isHandwritten: data.isHandwritten,
    };

    setDocuments([newDoc, ...documents]);

    // Add to review queue if low confidence
    if (hasLowConfidence) {
      setReviewQueue([
        {
          id: newDoc.id,
          type: data.documentType,
          uploadDate: data.scanDate,
          lowConfidenceFields: lowConfidenceFields.map((f: any) => ({
            label: f.label,
            value: f.value,
            confidence: f.confidence,
            key: f.key,
          })),
        },
        ...reviewQueue,
      ]);
      toast.success('Document scanned and added to review queue for verification');
    } else {
      toast.success('Document scanned, verified, and added to repository');
    }

    setScanModalOpen(false);
  };

  const handleViewDocument = (doc: any) => {
    setSelectedDocument(doc);
    toast.info('Document detail view - feature available in full implementation');
  };

  const handleApproveDocuments = (docIds: number[]) => {
    setDocuments(prev =>
      prev.map(doc =>
        docIds.includes(doc.id) ? { ...doc, status: 'verified' } : doc
      )
    );
    setReviewQueue(prev => prev.filter(doc => !docIds.includes(doc.id)));
    toast.success(`${docIds.length} document(s) approved and moved to repository`);
  };

  const handleRejectDocuments = (docIds: number[]) => {
    setDocuments(prev => prev.filter(doc => !docIds.includes(doc.id)));
    setReviewQueue(prev => prev.filter(doc => !docIds.includes(doc.id)));
    toast.success(`${docIds.length} document(s) rejected and removed`);
  };

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Finance Manager Dashboard</h1>
        <p className="text-muted-foreground">Expense tracking, resource allocation, and operational oversight</p>
      </div>

      <Tabs defaultValue="entry" className="w-full">
        <TabsList>
          <TabsTrigger value="entry">Expense Entry</TabsTrigger>
          <TabsTrigger value="allocation">Resource Allocation</TabsTrigger>
          <TabsTrigger value="elements">Cost Elements</TabsTrigger>
          <TabsTrigger value="statements">Financial Statements</TabsTrigger>
          <TabsTrigger value="kpi">KPI Dashboard</TabsTrigger>
          <TabsTrigger value="alerts">Alerts & Anomalies</TabsTrigger>
          <TabsTrigger value="ai">Ask CostAI</TabsTrigger>
        </TabsList>

        <TabsContent value="entry" className="space-y-6">
          {/* Quick Actions */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">Manual Entry</CardTitle>
              </CardHeader>
              <CardContent>
                <Button onClick={() => setExpenseModalOpen(true)} className="w-full" size="sm">
                  <Plus className="size-4 mr-2" />
                  Add Expense
                </Button>
              </CardContent>
            </Card>

            <Card className="border-blue-200 dark:border-blue-800 bg-blue-50 dark:bg-blue-950/20">
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <Scan className="size-4" />
                  AI Scan
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Button onClick={() => setScanModalOpen(true)} className="w-full" size="sm">
                  <Upload className="size-4 mr-2" />
                  Scan Document
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <Database className="size-4" />
                  Repository
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Button onClick={() => setRepositoryModalOpen(true)} className="w-full" variant="outline" size="sm">
                  <Database className="size-4 mr-2" />
                  View All ({documents.length})
                </Button>
              </CardContent>
            </Card>

            <Card className={reviewQueue.length > 0 ? "border-amber-200 dark:border-amber-800 bg-amber-50 dark:bg-amber-950/20" : ""}>
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <AlertCircle className="size-4" />
                  Review Queue
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Button
                  onClick={() => setReviewQueueModalOpen(true)}
                  className="w-full"
                  variant={reviewQueue.length > 0 ? "default" : "outline"}
                  size="sm"
                >
                  <AlertCircle className="size-4 mr-2" />
                  Review ({reviewQueue.length})
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Document Intelligence Pipeline */}
          <Card className="border-blue-200 dark:border-blue-800">
            <CardHeader>
              <CardTitle>3-Stage AI Document Intelligence Pipeline</CardTitle>
              <CardDescription>
                LayoutLMv3/Donut + AWS Textract/Google Document AI with TrOCR for handwritten content
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-3 gap-4 text-sm">
                  <div className="p-4 border rounded-lg">
                    <div className="font-mono text-blue-600 font-semibold mb-2">Stage 1</div>
                    <div className="font-medium mb-1">Preprocessing</div>
                    <p className="text-xs text-muted-foreground">
                      Deskew, contrast enhancement, noise removal
                    </p>
                  </div>
                  <div className="p-4 border rounded-lg">
                    <div className="font-mono text-blue-600 font-semibold mb-2">Stage 2</div>
                    <div className="font-medium mb-1">Layout Analysis</div>
                    <p className="text-xs text-muted-foreground">
                      ViT model visually detects document regions
                    </p>
                  </div>
                  <div className="p-4 border rounded-lg">
                    <div className="font-mono text-blue-600 font-semibold mb-2">Stage 3</div>
                    <div className="font-medium mb-1">OCR Extraction</div>
                    <p className="text-xs text-muted-foreground">
                      Field extraction per detected region
                    </p>
                  </div>
                </div>

                <div className="flex gap-3">
                  <Button onClick={() => setScanModalOpen(true)} size="lg" className="flex-1">
                    <Scan className="size-4 mr-2" />
                    Start AI Document Scan
                  </Button>
                  <Button onClick={() => setRepositoryModalOpen(true)} variant="outline" size="lg" className="flex-1">
                    <Database className="size-4 mr-2" />
                    Browse Repository
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {expenses.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Recent Expenses</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left p-2">Date</th>
                        <th className="text-left p-2">Vendor</th>
                        <th className="text-right p-2">Amount</th>
                        <th className="text-left p-2">Department</th>
                        <th className="text-left p-2">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {expenses.slice(0, 10).map((expense) => (
                        <tr key={expense.id} className="border-b">
                          <td className="p-2">{expense.date}</td>
                          <td className="p-2">{expense.vendor}</td>
                          <td className="text-right p-2 font-mono">{expense.currency} {expense.amount}</td>
                          <td className="p-2">{expense.department}</td>
                          <td className="p-2">
                            <Badge variant="default">Added</Badge>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          )}

        </TabsContent>

        <TabsContent value="elements" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Cost Element Workspace</CardTitle>
              <CardDescription>Add and edit cost elements for your business</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex gap-2">
                  <Input
                    placeholder="Add new cost element (e.g., Cloud Infrastructure)"
                    className="flex-1"
                    value={newElement}
                    onChange={(e) => setNewElement(e.target.value)}
                  />
                  <Button
                    onClick={() => {
                      if (newElement.trim()) {
                        setCostElements([...costElements, newElement.trim()]);
                        setNewElement('');
                        toast.success('Cost element added successfully!');
                      }
                    }}
                  >
                    <Plus className="size-4 mr-2" />
                    Add Element
                  </Button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {costElements.map((element, index) => (
                    <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                      <span className="font-medium text-sm">{element}</span>
                      <div className="flex items-center gap-2">
                        <Badge variant="secondary">Active</Badge>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => {
                            const elementName = prompt('Edit element name:', element);
                            if (elementName && elementName.trim()) {
                              const newElements = [...costElements];
                              newElements[index] = elementName.trim();
                              setCostElements(newElements);
                              toast.success('Element updated successfully!');
                            }
                          }}
                        >
                          <Edit className="size-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="bg-blue-50 dark:bg-blue-950/20 p-4 rounded-lg border border-blue-200 dark:border-blue-800 mt-6">
                  <h4 className="font-semibold mb-2">Element Configuration Guidelines</h4>
                  <p className="text-sm">
                    Cost elements should reflect your business nature: manufacturing companies need raw materials and depreciation,
                    SaaS companies need cloud infrastructure and software licenses. Elements are not fixed - adapt them to your
                    organizational needs. Each element can be tracked separately for better cost visibility.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="statements" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="size-5" />
                Financial Statements Repository
              </CardTitle>
              <CardDescription>
                Access and manage financial statements with role-based permissions and ViT document scanning
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button
                onClick={() => setStatementsModalOpen(true)}
                className="w-full"
                size="lg"
              >
                <FileText className="size-4 mr-2" />
                Open Financial Statements Repository
              </Button>

              <div className="bg-green-50 dark:bg-green-950/20 p-4 rounded-lg border border-green-200 dark:border-green-800 mt-4">
                <h4 className="font-semibold mb-2 text-sm">Features</h4>
                <ul className="text-sm space-y-1">
                  <li>• Role-based access control (CFO, Finance Manager, Cost Controller, Cost Analyst)</li>
                  <li>• Vision Transformer (ViT) for automatic data extraction from scanned documents</li>
                  <li>• Organize balance sheets, income statements, cash flow statements, and more</li>
                  <li>• Download and preview capabilities</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="allocation" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Resource Allocation Overview</CardTitle>
              <CardDescription>Budget vs actual at department and cost element levels</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="mb-6">
                <h4 className="font-semibold mb-3">By Department</h4>
                <ResponsiveContainer width="100%" height={350}>
                  <BarChart data={departmentCosts} margin={{ top: 10, right: 30, left: 20, bottom: 80 }} barGap={8}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
                    <XAxis dataKey="department" angle={-45} textAnchor="end" height={100} interval={0} />
                    <YAxis tickFormatter={(value) => `${(value / 1000).toFixed(0)}K`} />
                    <Tooltip
                      formatter={(value) => `$${(Number(value) / 1000).toFixed(0)}K`}
                      contentStyle={{ backgroundColor: 'rgba(255, 255, 255, 0.95)', border: '1px solid #ccc' }}
                    />
                    <Legend wrapperStyle={{ paddingTop: '10px' }} />
                    <Bar dataKey="budget" fill="#94a3b8" name="Budget" radius={[4, 4, 0, 0]} minPointSize={5} />
                    <Bar dataKey="actual" fill="#3b82f6" name="Actual" radius={[4, 4, 0, 0]} minPointSize={5} />
                  </BarChart>
                </ResponsiveContainer>
              </div>

              <div>
                <h4 className="font-semibold mb-3">By Cost Element</h4>
                <ResponsiveContainer width="100%" height={350}>
                  <BarChart data={costElementBreakdown} margin={{ top: 10, right: 30, left: 20, bottom: 100 }} barGap={8}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
                    <XAxis dataKey="element" angle={-45} textAnchor="end" height={120} interval={0} />
                    <YAxis tickFormatter={(value) => `${(value / 1000).toFixed(0)}K`} />
                    <Tooltip
                      formatter={(value) => `$${(Number(value) / 1000).toFixed(0)}K`}
                      contentStyle={{ backgroundColor: 'rgba(255, 255, 255, 0.95)', border: '1px solid #ccc' }}
                    />
                    <Legend wrapperStyle={{ paddingTop: '10px' }} />
                    <Bar dataKey="budget" fill="#94a3b8" name="Budget" radius={[4, 4, 0, 0]} minPointSize={5} />
                    <Bar dataKey="amount" fill="#10b981" name="Actual" radius={[4, 4, 0, 0]} minPointSize={5} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="kpi" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <KPICard
              title="Total Budget"
              value="$1.59M"
              subtitle="Monthly allocation"
              variant="default"
            />
            <KPICard
              title="Total Actual"
              value="$1.59M"
              subtitle="Monthly spending"
              variant="default"
            />
            <KPICard
              title="Variance"
              value="+$3K"
              subtitle="+0.2% over budget"
              variant="warning"
            />
            <KPICard
              title="Budget Utilization"
              value="100.2%"
              subtitle="Slightly over"
              variant="warning"
            />
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Variance Analysis with Cost Element Breakdown</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {departmentCosts.map((dept) => {
                  const variancePercent = (dept.variance / dept.budget) * 100;
                  return (
                    <div key={dept.department} className="border rounded-lg p-4">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-semibold">{dept.department}</h4>
                        <Badge variant={dept.variance > 0 ? 'destructive' : 'default'}>
                          {dept.variance > 0 ? '+' : ''}{variancePercent.toFixed(1)}%
                        </Badge>
                      </div>
                      <div className="grid grid-cols-3 gap-4 text-sm">
                        <div>
                          <p className="text-muted-foreground">Budget</p>
                          <p className="font-mono">${dept.budget.toLocaleString()}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Actual</p>
                          <p className="font-mono">${dept.actual.toLocaleString()}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Variance</p>
                          <p className={`font-mono ${dept.variance > 0 ? 'text-red-600 dark:text-red-400' : 'text-green-600 dark:text-green-400'}`}>
                            {dept.variance > 0 ? '+' : ''}${Math.abs(dept.variance).toLocaleString()}
                          </p>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="alerts" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <KPICard
              title="Critical Alerts"
              value={alerts.filter(a => a.severity === 'critical').length.toString()}
              subtitle="Require immediate action"
              variant="danger"
            />
            <KPICard
              title="High Severity"
              value={alerts.filter(a => a.severity === 'high').length.toString()}
              subtitle="Needs attention"
              variant="warning"
            />
            <KPICard
              title="All Alerts"
              value={alerts.length.toString()}
              subtitle="Total flagged"
              variant="default"
            />
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                AI Anomaly Detection
                <Badge variant="default">Autoencoder & Isolation Forest</Badge>
              </CardTitle>
              <CardDescription>Neural network and tree-based methods for comprehensive pattern recognition</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="bg-blue-50 dark:bg-blue-950/20 p-4 rounded-lg border border-blue-200 dark:border-blue-800">
                  <h4 className="font-semibold mb-2">Dual-Model Approach</h4>
                  <p className="text-sm">
                    Financial transactions have complex, high-dimensional patterns. A payment that looks normal in isolation
                    becomes anomalous when you consider vendor history, department, time of month, and cost element together.
                    Our AI uses both Autoencoder (neural network) and Isolation Forest (tree-based) methods to catch
                    subtle multi-variable anomalies with high precision.
                  </p>
                </div>

                <div className="flex gap-2 flex-wrap">
                  <Button
                    variant={selectedDetection === 'autoencoder' ? 'default' : 'outline'}
                    onClick={() => setSelectedDetection('autoencoder')}
                  >
                    Autoencoder (Primary)
                  </Button>
                  <Button
                    variant={selectedDetection === 'isolation-forest' ? 'default' : 'outline'}
                    onClick={() => setSelectedDetection('isolation-forest')}
                  >
                    Isolation Forest
                  </Button>
                </div>

                <div className="bg-purple-50 dark:bg-purple-950/20 p-4 rounded-lg border border-purple-200 dark:border-purple-800">
                  <p className="text-sm">
                    <strong>Active Algorithm: {selectedDetection === 'isolation-forest' ? 'Isolation Forest' : 'Autoencoder Neural Network'}</strong>
                  </p>
                  <p className="text-sm mt-2">
                    {selectedDetection === 'isolation-forest' && 'Tree-based - fast and simple, excellent for high-dimensional data'}
                    {selectedDetection === 'autoencoder' && 'Primary method: Learns normal multi-variable patterns, flags reconstruction errors. Best detection quality for financial data.'}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Tiered Alert System</CardTitle>
              <CardDescription>Operational vs Strategic alerts with specific descriptions</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <h4 className="font-semibold mb-3">Strategic Alerts (High Priority)</h4>
                  <div className="space-y-3">
                    {alerts.filter(a => a.type === 'strategic').map(alert => (
                      <AlertCard key={alert.id} {...alert} />
                    ))}
                  </div>
                </div>

                <div>
                  <h4 className="font-semibold mb-3">Operational Alerts</h4>
                  <div className="space-y-3">
                    {alerts.filter(a => a.type === 'operational').map(alert => (
                      <AlertCard key={alert.id} {...alert} />
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="ai" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageSquare className="size-5" />
                Ask CostAI - Enhanced NLP
              </CardTitle>
              <CardDescription>ML-based intent classification with Named Entity Recognition</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex gap-2">
                  <Input
                    placeholder="e.g., Which department has the highest variance?"
                    value={nlpQuery}
                    onChange={(e) => setNlpQuery(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleNLPQuery()}
                    className="flex-1"
                  />
                  <Button onClick={handleNLPQuery}>Ask</Button>
                </div>

                {nlpResponse && (
                  <div className="bg-blue-50 dark:bg-blue-950/20 p-4 rounded-lg border border-blue-200 dark:border-blue-800">
                    <h4 className="font-semibold mb-2">CostAI Response:</h4>
                    <p className="text-sm">{nlpResponse}</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <ExpenseEntryModal
        open={expenseModalOpen}
        onClose={() => setExpenseModalOpen(false)}
        onSubmit={handleExpenseSubmit}
      />
      <AIDocumentScanModal
        open={scanModalOpen}
        onClose={() => setScanModalOpen(false)}
        onComplete={handleDocumentComplete}
      />
      <DocumentRepositoryModal
        open={repositoryModalOpen}
        onClose={() => setRepositoryModalOpen(false)}
        userRole="Finance Manager"
        documents={documents}
        onViewDocument={handleViewDocument}
      />
      <ReviewQueueModal
        open={reviewQueueModalOpen}
        onClose={() => setReviewQueueModalOpen(false)}
        documents={reviewQueue}
        onApprove={handleApproveDocuments}
        onReject={handleRejectDocuments}
      />
    </div>
  );
}
