import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardAction } from '../ui/card';
import { KPICard } from '../KPICard';
import { AlertCard } from '../AlertCard';
import { Table } from '../ui/table';
import { Badge } from '../ui/badge';
import { Input } from '../ui/input';
import { Button } from '../ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { bankAccounts, alerts, upcomingPayments, financialRatios, monthlyRevenueData, departmentCosts, costElementBreakdown, forecastData, costElementForecastData, costElements } from '../../data/mockData';
import { TrendingUp, DollarSign, Zap, Calendar, MessageSquare, AlertTriangle, X } from 'lucide-react';
import { useState, useMemo } from 'react';
import { ScenarioSimulatorModal } from '../modals/ScenarioSimulatorModal';
import { toast } from 'sonner';
import { DateRangeSelector } from '../DateRangeSelector';
import { ExportButton } from '../ExportButton';

export function CFODashboard() {
  const [nlpQuery, setNlpQuery] = useState('');
  const [nlpResponse, setNlpResponse] = useState('');
  const [scenarioModalOpen, setScenarioModalOpen] = useState(false);
  const [selectedCostElement, setSelectedCostElement] = useState<string>('');
  const [showWhyProphet, setShowWhyProphet] = useState(true);

  // Prepare combined data for company forecast with proper connection
  const companyForecastData = useMemo(() => {
    const historical = monthlyRevenueData.map(d => ({...d}));
    const forecast = forecastData.prophet.map((d: any) => ({...d}));

    // Add last actual value to first forecast point to connect the lines
    if (forecast.length > 0 && historical.length > 0) {
      forecast[0] = { ...forecast[0], actual: historical[historical.length - 1].actual };
    }

    return [...historical, ...forecast];
  }, []);

  // Prepare cost element forecast data with proper connection
  const getCostElementChartData = (element: string) => {
    if (!costElementForecastData[element]) return [];

    const historical = costElementForecastData[element].historical.map((d: any) => ({...d}));
    const forecast = costElementForecastData[element].forecast.map((d: any) => ({...d}));

    // Add last actual value to first forecast point to connect the lines
    if (forecast.length > 0 && historical.length > 0) {
      forecast[0] = { ...forecast[0], actual: historical[historical.length - 1].actual };
    }

    return [...historical, ...forecast];
  };

  const totalCash = bankAccounts.reduce((sum, acc) => {
    // Simple conversion for demo (in real app, use actual exchange rates)
    const usdValue = acc.currency === 'USD' ? acc.balance :
                     acc.currency === 'EUR' ? acc.balance * 1.08 :
                     acc.balance / 30.5;
    return sum + usdValue;
  }, 0);

  const grossBurn = 1593000;
  const revenue = 1520000;
  const netBurn = grossBurn - revenue;
  const runway = totalCash / netBurn;

  const handleNLPQuery = () => {
    // Simulated ML-based NER and intent classification
    const query = nlpQuery.toLowerCase();
    if (query.includes('marketing') && query.includes('spent')) {
      setNlpResponse('Marketing department actual spending is $305,000 against a budget of $280,000, showing a variance of +$25,000 (8.9% over budget). Primary drivers: Contractor Fees increased by $20,000.');
    } else if (query.includes('burn rate')) {
      setNlpResponse(`Current gross burn rate is $${(grossBurn/1000).toFixed(0)}K/month, net burn is $${(netBurn/1000).toFixed(0)}K/month. This gives a runway of ${runway.toFixed(1)} months based on current cash balance.`);
    } else if (query.includes('alert') || query.includes('risk')) {
      setNlpResponse('There are 2 strategic alerts requiring attention: (1) Current ratio below threshold at 1.2, and (2) Asset mismanagement detected in depreciation schedules. Recommend immediate liquidity review.');
    } else {
      setNlpResponse('Query understood. Based on current data analysis, I can provide insights on revenue trends, cost forecasts, department variances, and financial ratios. Please specify what metrics you need.');
    }
  };

  const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899'];

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold">CFO Dashboard</h1>
        <p className="text-muted-foreground">Executive overview and strategic insights</p>
      </div>

      <Tabs defaultValue="overview" className="w-full">
        <TabsList>
          <TabsTrigger value="overview">Executive Overview</TabsTrigger>
          <TabsTrigger value="forecast">Cost Forecast</TabsTrigger>
          <TabsTrigger value="scenario">Scenario Simulator</TabsTrigger>
          <TabsTrigger value="risk">Risk Indicators</TabsTrigger>
          <TabsTrigger value="ai">Ask CostAI</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {/* KPI Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <KPICard
              title="Cash Balance"
              value={`$${(totalCash / 1000000).toFixed(2)}M`}
              subtitle="Across all accounts"
              trend="up"
              trendValue="+2.5% from last month"
            />
            <KPICard
              title="Gross Burn Rate"
              value={`$${(grossBurn / 1000).toFixed(0)}K/mo`}
              subtitle="Total monthly expenses"
              trend="down"
              trendValue="-3.2% improvement"
              variant="success"
            />
            <KPICard
              title="Net Burn Rate"
              value={`$${(netBurn / 1000).toFixed(0)}K/mo`}
              subtitle="Expenses minus revenue"
              trend="down"
              trendValue="-8.1% improvement"
              variant="success"
            />
            <KPICard
              title="Runway"
              value={`${runway.toFixed(1)} months`}
              subtitle={`At $${(netBurn/1000).toFixed(0)}K/mo burn`}
              trend="up"
              trendValue="+1.2 months"
            />
          </div>

          {/* Revenue vs Forecast Chart */}
          <Card>
            <CardHeader>
              <CardTitle>Revenue vs. Forecast</CardTitle>
              <CardDescription>Actual revenue compared to forecasted amounts</CardDescription>
              <CardAction>
                <DateRangeSelector />
              </CardAction>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={monthlyRevenueData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
                  <XAxis dataKey="month" />
                  <YAxis tickFormatter={(value) => `${(value / 1000).toFixed(0)}K`} />
                  <Tooltip
                    formatter={(value) => `$${(Number(value) / 1000).toFixed(0)}K`}
                    contentStyle={{ backgroundColor: 'rgba(255, 255, 255, 0.95)', border: '1px solid #ccc' }}
                  />
                  <Legend wrapperStyle={{ paddingTop: '10px' }} />
                  <Line
                    type="monotone"
                    dataKey="actual"
                    stroke="#3b82f6"
                    strokeWidth={3}
                    name="Actual Revenue"
                    dot={{ r: 4, fill: '#3b82f6' }}
                    activeDot={{ r: 6 }}
                  />
                  <Line
                    type="monotone"
                    dataKey="forecast"
                    stroke="#10b981"
                    strokeWidth={3}
                    strokeDasharray="5 5"
                    name="Forecast"
                    dot={{ r: 4, fill: '#10b981' }}
                    activeDot={{ r: 6 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Cost Breakdown */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Cost Breakdown by Department</CardTitle>
                <CardAction>
                  <DateRangeSelector />
                </CardAction>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={350}>
                  <BarChart data={departmentCosts} margin={{ top: 10, right: 30, left: 20, bottom: 80 }} barGap={8} barCategoryGap="20%">
                    <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
                    <XAxis
                      dataKey="department"
                      angle={-45}
                      textAnchor="end"
                      height={100}
                      interval={0}
                      tick={{ fontSize: 12 }}
                    />
                    <YAxis tickFormatter={(value) => `${(value / 1000).toFixed(0)}K`} />
                    <Tooltip
                      formatter={(value) => `$${(Number(value) / 1000).toFixed(0)}K`}
                      cursor={{ fill: 'rgba(59, 130, 246, 0.1)' }}
                      contentStyle={{ backgroundColor: 'rgba(255, 255, 255, 0.95)', border: '1px solid #ccc' }}
                    />
                    <Legend wrapperStyle={{ paddingTop: '10px' }} />
                    <Bar dataKey="budget" fill="#94a3b8" name="Budget" radius={[4, 4, 0, 0]} minPointSize={5} />
                    <Bar dataKey="actual" fill="#3b82f6" name="Actual" radius={[4, 4, 0, 0]} minPointSize={5} />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Cost by Element</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={350}>
                  <PieChart>
                    <Pie
                      data={costElementBreakdown}
                      cx="50%"
                      cy="45%"
                      labelLine={false}
                      label={(entry) => entry.element.split(' ')[0]}
                      outerRadius={90}
                      fill="#8884d8"
                      dataKey="amount"
                    >
                      {costElementBreakdown.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip
                      formatter={(value) => `$${(Number(value) / 1000).toFixed(0)}K`}
                      contentStyle={{ backgroundColor: 'rgba(255, 255, 255, 0.95)', border: '1px solid #ccc' }}
                    />
                    <Legend
                      verticalAlign="bottom"
                      height={36}
                      formatter={(value, entry: any) => `${entry.payload.element}`}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          {/* Bank Accounts */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <DollarSign className="size-5" />
                Bank & Cash Visibility
              </CardTitle>
              <CardAction>
                <ExportButton />
              </CardAction>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left p-2">Account Name</th>
                      <th className="text-right p-2">Balance</th>
                      <th className="text-left p-2">Currency</th>
                    </tr>
                  </thead>
                  <tbody>
                    {bankAccounts.map((account) => (
                      <tr key={account.id} className="border-b">
                        <td className="p-2">{account.name}</td>
                        <td className="text-right p-2 font-mono">{account.balance.toLocaleString()}</td>
                        <td className="p-2">{account.currency}</td>
                      </tr>
                    ))}
                    <tr className="font-bold">
                      <td className="p-2">Total (USD equivalent)</td>
                      <td className="text-right p-2 font-mono">${totalCash.toLocaleString(undefined, { maximumFractionDigits: 0 })}</td>
                      <td className="p-2">USD</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>

          {/* Red Flag Alerts */}
          <Card className="border-red-500">
            <CardHeader className="bg-red-50 dark:bg-red-950/20">
              <CardTitle className="flex items-center gap-2 text-red-600 dark:text-red-400">
                <AlertTriangle className="size-5" />
                Strategic Red Flag Alerts
              </CardTitle>
              <CardDescription>Critical financial distress indicators requiring immediate attention</CardDescription>
            </CardHeader>
            <CardContent className="pt-6">
              <div className="space-y-4">
                {alerts.filter(a => a.type === 'strategic').map(alert => (
                  <AlertCard key={alert.id} {...alert} />
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Unusual Movements */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="size-5" />
                Unusual Movements Detected
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {alerts.filter(a => a.type === 'operational').map(alert => (
                  <AlertCard key={alert.id} {...alert} />
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Upcoming Payments */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="size-5" />
                Upcoming Payments
              </CardTitle>
              <CardAction>
                <ExportButton />
              </CardAction>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left p-2">Type</th>
                      <th className="text-left p-2">Vendor</th>
                      <th className="text-right p-2">Amount</th>
                      <th className="text-left p-2">Currency</th>
                      <th className="text-left p-2">Due Date</th>
                    </tr>
                  </thead>
                  <tbody>
                    {upcomingPayments.map((payment) => (
                      <tr key={payment.id} className="border-b">
                        <td className="p-2">
                          <Badge variant="outline">{payment.type}</Badge>
                        </td>
                        <td className="p-2">{payment.vendor}</td>
                        <td className="text-right p-2 font-mono">{payment.amount.toLocaleString()}</td>
                        <td className="p-2">{payment.currency}</td>
                        <td className="p-2">{new Date(payment.dueDate).toLocaleDateString()}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>

          {/* Financial Ratios */}
          <Card className={financialRatios.liquidity.currentRatio < 1.5 ? 'border-red-500 border-2' : ''}>
            <CardHeader className={financialRatios.liquidity.currentRatio < 1.5 ? 'bg-amber-50 dark:bg-amber-950/20' : ''}>
              <CardTitle className={financialRatios.liquidity.currentRatio < 1.5 ? 'text-amber-900 dark:text-amber-100' : ''}>
                {financialRatios.liquidity.currentRatio < 1.5 ? 'Financial Ratios — 1 Critical' : 'Built-in Financial Ratios'}
              </CardTitle>
              <CardDescription>Key financial metrics and equations sourced from standard references</CardDescription>
              <CardAction>
                <ExportButton />
              </CardAction>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <div>
                  <h4 className="font-semibold mb-3">Liquidity</h4>
                  <div className="space-y-2">
                    <div>
                      <p className="text-sm text-muted-foreground">Current Ratio</p>
                      <p className={`text-lg font-mono ${financialRatios.liquidity.currentRatio < 1.5 ? 'text-red-600 dark:text-red-400' : 'text-green-600 dark:text-green-400'}`}>
                        {financialRatios.liquidity.currentRatio.toFixed(2)}
                      </p>
                      <p className="text-xs text-muted-foreground">Current Assets ÷ Current Liabilities</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Quick Ratio</p>
                      <p className="text-lg font-mono">{financialRatios.liquidity.quickRatio.toFixed(2)}</p>
                      <p className="text-xs text-muted-foreground">(Current Assets - Inventory) ÷ Current Liabilities</p>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="font-semibold mb-3">Profitability</h4>
                  <div className="space-y-2">
                    <div>
                      <p className="text-sm text-muted-foreground">Gross Margin</p>
                      <p className="text-lg font-mono text-green-600 dark:text-green-400">{(financialRatios.profitability.grossMargin * 100).toFixed(1)}%</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Net Margin</p>
                      <p className="text-lg font-mono">{(financialRatios.profitability.netMargin * 100).toFixed(1)}%</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">ROE</p>
                      <p className="text-lg font-mono">{(financialRatios.profitability.roe * 100).toFixed(1)}%</p>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="font-semibold mb-3">Efficiency</h4>
                  <div className="space-y-2">
                    <div>
                      <p className="text-sm text-muted-foreground">Asset Turnover</p>
                      <p className="text-lg font-mono">{financialRatios.efficiency.assetTurnover.toFixed(2)}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Inventory Turnover</p>
                      <p className="text-lg font-mono">{financialRatios.efficiency.inventoryTurnover.toFixed(1)}</p>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="font-semibold mb-3">Solvency</h4>
                  <div className="space-y-2">
                    <div>
                      <p className="text-sm text-muted-foreground">Debt-to-Equity</p>
                      <p className="text-lg font-mono">{financialRatios.solvency.debtToEquity.toFixed(2)}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Interest Coverage</p>
                      <p className="text-lg font-mono text-green-600 dark:text-green-400">{financialRatios.solvency.interestCoverage.toFixed(1)}x</p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="forecast" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                AI-Powered Cost Forecasting - Prophet
                <Badge variant="default">Best for Financial Data</Badge>
              </CardTitle>
              <CardDescription>Prophet by Meta - handles seasonality, calendar effects, and multi-currency without manual tuning</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <KPICard
                    title="Prophet Forecast (Jul)"
                    value={`$${(forecastData.prophet[0].forecast / 1000).toFixed(0)}K`}
                    subtitle={`Range: $${(forecastData.prophet[0].lower / 1000).toFixed(0)}K - $${(forecastData.prophet[0].upper / 1000).toFixed(0)}K`}
                    variant="success"
                  />
                  <KPICard
                    title="Prophet Forecast (Aug)"
                    value={`$${(forecastData.prophet[1].forecast / 1000).toFixed(0)}K`}
                    subtitle={`Range: $${(forecastData.prophet[1].lower / 1000).toFixed(0)}K - $${(forecastData.prophet[1].upper / 1000).toFixed(0)}K`}
                    variant="default"
                  />
                  <KPICard
                    title="Prophet Forecast (Sep)"
                    value={`$${(forecastData.prophet[2].forecast / 1000).toFixed(0)}K`}
                    subtitle={`Range: $${(forecastData.prophet[2].lower / 1000).toFixed(0)}K - $${(forecastData.prophet[2].upper / 1000).toFixed(0)}K`}
                    variant="default"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-4">
                    <h4 className="font-semibold">3-Month Company-Wide Forecast</h4>
                    <DateRangeSelector />
                  </div>
                  <ResponsiveContainer width="100%" height={400}>
                    <LineChart data={companyForecastData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
                      <XAxis dataKey="month" />
                      <YAxis tickFormatter={(value) => `${(value / 1000).toFixed(0)}K`} />
                      <Tooltip
                        formatter={(value) => value != null ? `$${(Number(value) / 1000).toFixed(0)}K` : 'N/A'}
                        contentStyle={{ backgroundColor: 'rgba(255, 255, 255, 0.95)', border: '1px solid #ccc' }}
                      />
                      <Legend wrapperStyle={{ paddingTop: '10px' }} />
                      <Line
                        type="monotone"
                        dataKey="actual"
                        stroke="#3b82f6"
                        strokeWidth={3}
                        name="Historical"
                        connectNulls
                        dot={{ r: 4, fill: '#3b82f6' }}
                        activeDot={{ r: 6 }}
                      />
                      <Line
                        type="monotone"
                        dataKey="forecast"
                        stroke="#10b981"
                        strokeWidth={3}
                        strokeDasharray="5 5"
                        name="Forecast"
                        connectNulls
                        dot={{ r: 4, fill: '#10b981' }}
                        activeDot={{ r: 6 }}
                      />
                      <Line
                        type="monotone"
                        dataKey="lower"
                        stroke="#94a3b8"
                        strokeWidth={2}
                        strokeDasharray="3 3"
                        name="Lower Bound"
                        connectNulls
                        dot={false}
                      />
                      <Line
                        type="monotone"
                        dataKey="upper"
                        stroke="#94a3b8"
                        strokeWidth={2}
                        strokeDasharray="3 3"
                        name="Upper Bound"
                        connectNulls
                        dot={false}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>

                <div className="bg-blue-50 dark:bg-blue-950/20 p-4 rounded-lg border border-blue-200 dark:border-blue-800">
                  <h4 className="font-semibold mb-2 flex items-center gap-2">
                    <TrendingUp className="size-4" />
                    AI Explainability
                  </h4>
                  <p className="text-sm">
                    <strong>Why this forecast:</strong> Models analyzed 6 months of historical data, identifying a strong upward trend (+12% MoM average).
                    Key factors: Seasonal patterns in Q2, department expansion in Engineering (+15% headcount), and new product launches affecting revenue.
                    ARIMA model accounts for time-series autocorrelation, while Prophet handles seasonality and holidays.
                    Multi-currency forecasts split by currency and apply independent exchange rate projections.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Cost Element Forecasting</CardTitle>
              <CardDescription>Drill down into specific cost elements for detailed forecasts</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div>
                  <label className="text-sm font-medium mb-2 block">Select Cost Element</label>
                  <Select
                    value={selectedCostElement}
                    onValueChange={setSelectedCostElement}
                  >
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder="-- Choose a cost element --" />
                    </SelectTrigger>
                    <SelectContent>
                      {costElements.filter(element => costElementForecastData[element]).map((element) => (
                        <SelectItem key={element} value={element}>{element}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {selectedCostElement && costElementForecastData[selectedCostElement] && (
                  <>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <KPICard
                        title={`${selectedCostElement} - Jul`}
                        value={`$${(costElementForecastData[selectedCostElement].forecast[0].forecast / 1000).toFixed(0)}K`}
                        subtitle={`Range: $${(costElementForecastData[selectedCostElement].forecast[0].lower / 1000).toFixed(0)}K - $${(costElementForecastData[selectedCostElement].forecast[0].upper / 1000).toFixed(0)}K`}
                        variant="success"
                      />
                      <KPICard
                        title={`${selectedCostElement} - Aug`}
                        value={`$${(costElementForecastData[selectedCostElement].forecast[1].forecast / 1000).toFixed(0)}K`}
                        subtitle={`Range: $${(costElementForecastData[selectedCostElement].forecast[1].lower / 1000).toFixed(0)}K - $${(costElementForecastData[selectedCostElement].forecast[1].upper / 1000).toFixed(0)}K`}
                        variant="default"
                      />
                      <KPICard
                        title={`${selectedCostElement} - Sep`}
                        value={`$${(costElementForecastData[selectedCostElement].forecast[2].forecast / 1000).toFixed(0)}K`}
                        subtitle={`Range: $${(costElementForecastData[selectedCostElement].forecast[2].lower / 1000).toFixed(0)}K - $${(costElementForecastData[selectedCostElement].forecast[2].upper / 1000).toFixed(0)}K`}
                        variant="default"
                      />
                    </div>

                    <div>
                      <h4 className="font-semibold mb-4">{selectedCostElement} - 3-Month Forecast</h4>
                      <ResponsiveContainer width="100%" height={400}>
                        <LineChart data={getCostElementChartData(selectedCostElement)} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                          <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
                          <XAxis dataKey="month" />
                          <YAxis tickFormatter={(value) => `${(value / 1000).toFixed(0)}K`} />
                          <Tooltip
                            formatter={(value) => value != null ? `$${(Number(value) / 1000).toFixed(0)}K` : 'N/A'}
                            contentStyle={{ backgroundColor: 'rgba(255, 255, 255, 0.95)', border: '1px solid #ccc' }}
                          />
                          <Legend wrapperStyle={{ paddingTop: '10px' }} />
                          <Line
                            type="monotone"
                            dataKey="actual"
                            stroke="#3b82f6"
                            strokeWidth={3}
                            name="Historical"
                            connectNulls
                            dot={{ r: 4, fill: '#3b82f6' }}
                            activeDot={{ r: 6 }}
                          />
                          <Line
                            type="monotone"
                            dataKey="forecast"
                            stroke="#10b981"
                            strokeWidth={3}
                            strokeDasharray="5 5"
                            name="Forecast"
                            connectNulls
                            dot={{ r: 4, fill: '#10b981' }}
                            activeDot={{ r: 6 }}
                          />
                          <Line
                            type="monotone"
                            dataKey="lower"
                            stroke="#94a3b8"
                            strokeWidth={2}
                            strokeDasharray="3 3"
                            name="Lower Bound"
                            connectNulls
                            dot={false}
                          />
                          <Line
                            type="monotone"
                            dataKey="upper"
                            stroke="#94a3b8"
                            strokeWidth={2}
                            strokeDasharray="3 3"
                            name="Upper Bound"
                            connectNulls
                            dot={false}
                          />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>
                  </>
                )}
              </div>
            </CardContent>
          </Card>

          {showWhyProphet && (
            <Card className="bg-blue-50 dark:bg-blue-950/20 border-blue-200 dark:border-blue-800">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <CardTitle>Why Prophet?</CardTitle>
                    <CardDescription className="mt-2">
                      Financial cost data has strong seasonality (payroll cycles, quarterly budgets) and calendar effects
                      (holidays, fiscal year-end). Prophet was built specifically for these patterns and handles multi-currency
                      series independently. More robust than ARIMA (needs expert tuning) or Linear Regression (too simplistic).
                    </CardDescription>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setShowWhyProphet(false)}
                    className="ml-2"
                  >
                    <X className="size-4" />
                  </Button>
                </div>
              </CardHeader>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="scenario" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="size-5" />
                Scenario Simulator - Gradient Boosting (XGBoost/LightGBM)
              </CardTitle>
              <CardDescription>AI-powered scenario analysis learning from historical patterns</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="bg-blue-50 dark:bg-blue-950/20 p-4 rounded-lg border border-blue-200 dark:border-blue-800">
                  <h4 className="font-semibold mb-2">Why Gradient Boosting?</h4>
                  <p className="text-sm">
                    Gradient Boosting (XGBoost/LightGBM) learns non-linear relationships from your actual historical data.
                    It produces predictions grounded in real patterns and handles multi-currency environments naturally.
                    Highly accurate for tabular financial data with complex interdependencies.
                  </p>
                </div>

                <Button onClick={() => setScenarioModalOpen(true)} className="w-full" size="lg">
                  <Zap className="size-4 mr-2" />
                  Open Scenario Simulator
                </Button>

              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="risk" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Department-Level Risk</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {departmentCosts.map((dept) => {
                    const variancePercent = (dept.variance / dept.budget) * 100;
                    const riskLevel = Math.abs(variancePercent) > 10 ? 'high' : Math.abs(variancePercent) > 5 ? 'medium' : 'low';
                    return (
                      <div key={dept.department} className="flex items-center justify-between p-3 border rounded-lg">
                        <span className="font-medium">{dept.department}</span>
                        <div className="flex items-center gap-2">
                          <span className={`text-sm ${dept.variance > 0 ? 'text-red-600 dark:text-red-400' : 'text-green-600 dark:text-green-400'}`}>
                            {dept.variance > 0 ? '+' : ''}{variancePercent.toFixed(1)}%
                          </span>
                          <Badge variant={riskLevel === 'high' ? 'destructive' : riskLevel === 'medium' ? 'outline' : 'secondary'}>
                            {riskLevel.toUpperCase()}
                          </Badge>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Cost Element Risk</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {costElementBreakdown.map((element) => {
                    const variancePercent = (element.variance / element.budget) * 100;
                    const riskLevel = Math.abs(variancePercent) > 15 ? 'high' : Math.abs(variancePercent) > 8 ? 'medium' : 'low';
                    return (
                      <div key={element.element} className="flex items-center justify-between p-3 border rounded-lg">
                        <span className="font-medium text-sm">{element.element}</span>
                        <div className="flex items-center gap-2">
                          <span className={`text-sm ${element.variance > 0 ? 'text-red-600 dark:text-red-400' : 'text-green-600 dark:text-green-400'}`}>
                            {element.variance > 0 ? '+' : ''}{variancePercent.toFixed(1)}%
                          </span>
                          <Badge variant={riskLevel === 'high' ? 'destructive' : riskLevel === 'medium' ? 'outline' : 'secondary'}>
                            {riskLevel.toUpperCase()}
                          </Badge>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-4">
            {alerts.filter(a => a.type === 'strategic').map(alert => (
              <AlertCard key={alert.id} {...alert} />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="ai" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageSquare className="size-5" />
                Ask CostAI - Enhanced NLP Engine
              </CardTitle>
              <CardDescription>
                ML-based intent classification with Named Entity Recognition (NER) - grounded in database queries
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex gap-2">
                  <Input
                    placeholder="e.g., How much did marketing spend last month? What's our burn rate?"
                    value={nlpQuery}
                    onChange={(e) => setNlpQuery(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleNLPQuery()}
                    className="flex-1"
                  />
                  <Button onClick={handleNLPQuery}>Ask</Button>
                </div>

                {nlpResponse && (
                  <div className="bg-blue-50 dark:bg-blue-950/20 p-4 rounded-lg border border-blue-200 dark:border-blue-800">
                    <h4 className="font-semibold mb-2">CostAI Response:</h4>
                    <p className="text-sm">{nlpResponse}</p>
                    <div className="mt-3 pt-3 border-t border-blue-200 dark:border-blue-800">
                      <p className="text-xs text-muted-foreground">
                        <strong>NER Entities Detected:</strong> {nlpQuery.toLowerCase().includes('marketing') ? 'Department: Marketing, ' : ''}
                        {nlpQuery.toLowerCase().includes('burn') ? 'Metric: Burn Rate, ' : ''}
                        Intent: {nlpQuery.includes('?') ? 'Query' : 'Analysis Request'}
                      </p>
                    </div>
                  </div>
                )}

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-4 border rounded-lg">
                    <h4 className="font-semibold mb-2 text-sm">Example Queries:</h4>
                    <ul className="text-sm space-y-1 text-muted-foreground">
                      <li>• "How much did marketing spend last month?"</li>
                      <li>• "What's our current burn rate and runway?"</li>
                      <li>• "Show me alerts and risks"</li>
                      <li>• "Which departments are over budget?"</li>
                    </ul>
                  </div>
                  <div className="p-4 border rounded-lg">
                    <h4 className="font-semibold mb-2 text-sm">AI Capabilities:</h4>
                    <ul className="text-sm space-y-1 text-muted-foreground">
                      <li>• Intent classification (ML-based)</li>
                      <li>• Named Entity Recognition (departments, vendors, amounts)</li>
                      <li>• Database-grounded responses (no hallucinations)</li>
                      <li>• Multi-turn conversation support</li>
                    </ul>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <ScenarioSimulatorModal
        open={scenarioModalOpen}
        onClose={() => setScenarioModalOpen(false)}
      />
    </div>
  );
}
