import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../ui/card';
import { KPICard } from '../KPICard';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Input } from '../ui/input';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LineChart, Line, AreaChart, Area } from 'recharts';
import { costElements, budgetRequests, departmentCosts, costElementBreakdown, forecastData } from '../../data/mockData';
import { CheckCircle, XCircle, Clock, TrendingUp, AlertTriangle, DollarSign, FileText, Zap, Brain, TrendingDown, Send, Eye } from 'lucide-react';
import { useState } from 'react';
import { StatusIndicator } from '../StatusIndicator';
import { toast } from 'sonner';

export function CostControllerDashboard() {
  const [requests, setRequests] = useState(budgetRequests);

  const handleApprove = (id: number, amount: number) => {
    setRequests(requests.map(r => r.id === id ? { ...r, approved: amount, status: 'approved' } : r));
  };

  const handleChallenge = (id: number, amount: number) => {
    setRequests(requests.map(r => r.id === id ? { ...r, approved: amount, status: 'challenged' } : r));
  };

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Cost Controller Dashboard</h1>
        <p className="text-muted-foreground">Backbone of cost management - element configuration, budget review, and analysis</p>
      </div>

      <Tabs defaultValue="elements" className="w-full">
        <TabsList>
          <TabsTrigger value="elements">Cost Elements</TabsTrigger>
          <TabsTrigger value="budget">Budget Review & Challenge</TabsTrigger>
          <TabsTrigger value="analysis">Cost Analysis by Element</TabsTrigger>
          <TabsTrigger value="contracts">Contract & Rate Management</TabsTrigger>
          <TabsTrigger value="forecast">Element Forecasting</TabsTrigger>
          <TabsTrigger value="report">Monthly On-Track Report</TabsTrigger>
        </TabsList>

        <TabsContent value="elements" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Cost Element Workspace</CardTitle>
              <CardDescription>Configure cost elements relevant to your business type</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex gap-2">
                  <Input placeholder="Add new cost element (e.g., Cloud Infrastructure)" className="flex-1" />
                  <Button>Add Element</Button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {costElements.map((element, index) => (
                    <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                      <span className="font-medium text-sm">{element}</span>
                      <div className="flex items-center gap-2">
                        <Badge variant="secondary">Active</Badge>
                        <Button size="sm" variant="ghost">Edit</Button>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="bg-blue-50 dark:bg-blue-950/20 p-4 rounded-lg border border-blue-200 dark:border-blue-800 mt-6">
                  <h4 className="font-semibold mb-2">Element Configuration Guidelines</h4>
                  <p className="text-sm">
                    Cost elements should reflect your business nature: manufacturing companies need raw materials and depreciation,
                    SaaS companies need cloud infrastructure and software licenses. Elements are not fixed - adapt them to your
                    organizational needs. Each element can be tracked separately for better cost visibility.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="budget" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <KPICard
              title="Pending Requests"
              value={requests.filter(r => r.status === 'pending').length.toString()}
              subtitle="Awaiting review"
              variant="warning"
            />
            <KPICard
              title="Challenged"
              value={requests.filter(r => r.status === 'challenged').length.toString()}
              subtitle="Requires justification"
              variant="danger"
            />
            <KPICard
              title="Approved"
              value={requests.filter(r => r.status === 'approved').length.toString()}
              subtitle="Ready for CFO review"
              variant="success"
            />
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Budget Review & Challenge Workflow</CardTitle>
              <CardDescription>
                Top-down targets from CFO meet bottom-up submissions from departments. Review, challenge, and consolidate budgets.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {requests.map((request) => (
                  <div key={request.id} className="border rounded-lg p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h4 className="font-semibold">{request.department}</h4>
                          <Badge variant={
                            request.status === 'approved' ? 'default' :
                            request.status === 'challenged' ? 'destructive' :
                            'outline'
                          }>
                            {request.status}
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">{request.element}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-muted-foreground">Requested</p>
                        <p className="text-lg font-mono font-semibold">${request.requested.toLocaleString()}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 mb-3">
                      <Input
                        type="number"
                        placeholder="Approved amount"
                        defaultValue={request.approved || ''}
                        className="flex-1"
                        id={`amount-${request.id}`}
                      />
                    </div>

                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="default"
                        onClick={() => {
                          const input = document.getElementById(`amount-${request.id}`) as HTMLInputElement;
                          handleApprove(request.id, parseInt(input.value));
                        }}
                        className="flex items-center gap-1"
                      >
                        <CheckCircle className="size-4" />
                        Approve
                      </Button>
                      <Button
                        size="sm"
                        variant="destructive"
                        onClick={() => {
                          const input = document.getElementById(`amount-${request.id}`) as HTMLInputElement;
                          handleChallenge(request.id, parseInt(input.value));
                        }}
                        className="flex items-center gap-1"
                      >
                        <XCircle className="size-4" />
                        Challenge
                      </Button>
                      <Button size="sm" variant="outline">Request Justification</Button>
                    </div>

                    {request.status === 'challenged' && (
                      <div className="mt-3 p-3 bg-red-50 dark:bg-red-950/20 rounded border border-red-200 dark:border-red-800">
                        <p className="text-sm text-red-600 dark:text-red-400">
                          Challenged: Requested amount ${request.requested.toLocaleString()} exceeds historical baseline.
                          Approved ${request.approved?.toLocaleString()} pending department justification.
                        </p>
                      </div>
                    )}
                  </div>
                ))}
              </div>

              <div className="mt-6 p-4 bg-green-50 dark:bg-green-950/20 rounded-lg border border-green-200 dark:border-green-800">
                <h4 className="font-semibold mb-2">Budget Workflow</h4>
                <ol className="text-sm space-y-1">
                  <li>1. CFO/CEO sets top-down targets for each department</li>
                  <li>2. Departments submit bottom-up budget requests</li>
                  <li>3. Cost Controller reviews, challenges unjustified requests, removes misaligned items</li>
                  <li>4. Approved budgets consolidated into company-wide budget</li>
                  <li>5. Final budget sent to CFO for approval, then to Board/CEO</li>
                </ol>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analysis" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Cost Analysis by Element</CardTitle>
              <CardDescription>Deep-dive into costs broken down by element - reveals true inefficiencies</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <BarChart data={costElementBreakdown}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="element" angle={-45} textAnchor="end" height={120} />
                  <YAxis />
                  <Tooltip formatter={(value) => `$${Number(value).toLocaleString()}`} />
                  <Legend />
                  <Bar dataKey="budget" fill="#94a3b8" name="Budget" />
                  <Bar dataKey="amount" fill="#3b82f6" name="Actual" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Element Variance Analysis</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {costElementBreakdown.map((element) => {
                    const variancePercent = (element.variance / element.budget) * 100;
                    return (
                      <div key={element.element} className="flex items-center justify-between p-3 border rounded-lg">
                        <div className="flex-1">
                          <p className="font-medium text-sm">{element.element}</p>
                          <p className="text-xs text-muted-foreground">
                            Budget: ${element.budget.toLocaleString()} | Actual: ${element.amount.toLocaleString()}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className={`text-sm font-semibold ${element.variance > 0 ? 'text-red-600 dark:text-red-400' : 'text-green-600 dark:text-green-400'}`}>
                            {element.variance > 0 ? '+' : ''}${Math.abs(element.variance).toLocaleString()}
                          </p>
                          <p className={`text-xs ${element.variance > 0 ? 'text-red-600 dark:text-red-400' : 'text-green-600 dark:text-green-400'}`}>
                            {variancePercent > 0 ? '+' : ''}{variancePercent.toFixed(1)}%
                          </p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Department Budget vs Actual</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {departmentCosts.map((dept) => {
                    const variancePercent = (dept.variance / dept.budget) * 100;
                    return (
                      <div key={dept.department} className="flex items-center justify-between p-3 border rounded-lg">
                        <div className="flex-1">
                          <p className="font-medium text-sm">{dept.department}</p>
                          <p className="text-xs text-muted-foreground">
                            Budget: ${dept.budget.toLocaleString()} | Actual: ${dept.actual.toLocaleString()}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className={`text-sm font-semibold ${dept.variance > 0 ? 'text-red-600 dark:text-red-400' : 'text-green-600 dark:text-green-400'}`}>
                            {dept.variance > 0 ? '+' : ''}${Math.abs(dept.variance).toLocaleString()}
                          </p>
                          <p className={`text-xs ${dept.variance > 0 ? 'text-red-600 dark:text-red-400' : 'text-green-600 dark:text-green-400'}`}>
                            {variancePercent > 0 ? '+' : ''}{variancePercent.toFixed(1)}%
                          </p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="contracts" className="space-y-6">
          {/* TOP KPI ROW */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <KPICard
              title="Forecast Budget Variance"
              value="+$42K"
              subtitle="Contracts over budget"
              variant="warning"
            />
            <KPICard
              title="Savings Opportunities"
              value="$125K"
              subtitle="Identified potential savings"
              variant="success"
            />
            <KPICard
              title="High-Risk Contracts"
              value="3"
              subtitle="Require immediate action"
              variant="danger"
            />
            <KPICard
              title="Contracts Expiring Soon"
              value="2"
              subtitle="Within 90 days"
              variant="warning"
            />
          </div>

          {/* MAIN SECTION 1: Contract Cost Intelligence */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Brain className="size-5" />
                Contract Cost Intelligence
              </CardTitle>
              <CardDescription>AI-powered contract analysis with risk assessment and recommendations</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                {/* LEFT: Inputs */}
                <div className="lg:col-span-3 space-y-4">
                  <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-800">
                    <h4 className="font-semibold mb-3 text-sm flex items-center gap-2">
                      <FileText className="size-4" />
                      Contract Inputs
                    </h4>
                    <div className="space-y-3 text-sm">
                      <div className="p-2 bg-white dark:bg-gray-900 rounded">
                        <p className="font-medium text-xs">Vendor Contracts</p>
                        <p className="text-xs text-muted-foreground">12 active contracts</p>
                      </div>
                      <div className="p-2 bg-white dark:bg-gray-900 rounded">
                        <p className="font-medium text-xs">Escalation Clauses</p>
                        <p className="text-xs text-muted-foreground">3-5% annual increase</p>
                      </div>
                      <div className="p-2 bg-white dark:bg-gray-900 rounded">
                        <p className="font-medium text-xs">Renewal Dates</p>
                        <p className="text-xs text-muted-foreground">2 expiring Q3 2026</p>
                      </div>
                      <div className="p-2 bg-white dark:bg-gray-900 rounded">
                        <p className="font-medium text-xs">Monthly Rates</p>
                        <p className="text-xs text-muted-foreground">$245K total</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* CENTER: AI Analysis Engine */}
                <div className="lg:col-span-3 space-y-4">
                  <div className="p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg border border-purple-200 dark:border-purple-800">
                    <h4 className="font-semibold mb-3 text-sm flex items-center gap-2">
                      <Zap className="size-4" />
                      AI Processing
                    </h4>
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 p-2 bg-white dark:bg-gray-900 rounded">
                        <div className="size-2 bg-green-500 rounded-full animate-pulse"></div>
                        <span className="text-xs">NLP Contract Analysis</span>
                      </div>
                      <div className="text-center py-2">
                        <div className="text-2xl">↓</div>
                      </div>
                      <div className="flex items-center gap-2 p-2 bg-white dark:bg-gray-900 rounded">
                        <div className="size-2 bg-green-500 rounded-full animate-pulse"></div>
                        <span className="text-xs">Risk Scoring</span>
                      </div>
                      <div className="text-center py-2">
                        <div className="text-2xl">↓</div>
                      </div>
                      <div className="flex items-center gap-2 p-2 bg-white dark:bg-gray-900 rounded">
                        <div className="size-2 bg-green-500 rounded-full animate-pulse"></div>
                        <span className="text-xs">Cost Trend Forecasting</span>
                      </div>
                      <div className="text-center py-2">
                        <div className="text-2xl">↓</div>
                      </div>
                      <div className="flex items-center gap-2 p-2 bg-white dark:bg-gray-900 rounded">
                        <div className="size-2 bg-green-500 rounded-full animate-pulse"></div>
                        <span className="text-xs">Anomaly Detection</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* RIGHT: Outputs & Actions */}
                <div className="lg:col-span-6">
                  <div className="p-4 bg-green-50 dark:bg-green-900/20 rounded-lg border border-green-200 dark:border-green-800">
                    <h4 className="font-semibold mb-3 text-sm flex items-center gap-2">
                      <CheckCircle className="size-4" />
                      Outputs & Recommended Actions
                    </h4>
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm">
                        <thead>
                          <tr className="border-b">
                            <th className="text-left p-2">Vendor</th>
                            <th className="text-left p-2">Risk</th>
                            <th className="text-right p-2">Budget Impact</th>
                            <th className="text-left p-2">Action</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr className="border-b">
                            <td className="p-2 text-xs">Office Lease Corp</td>
                            <td className="p-2">
                              <div className="flex items-center gap-1">
                                <div className="size-2 bg-red-500 rounded-full"></div>
                                <span className="text-xs">High</span>
                              </div>
                            </td>
                            <td className="text-right p-2 font-mono text-xs">+$42K</td>
                            <td className="p-2 text-xs">Renegotiate lease</td>
                          </tr>
                          <tr className="border-b">
                            <td className="p-2 text-xs">Cloud Services</td>
                            <td className="p-2">
                              <div className="flex items-center gap-1">
                                <div className="size-2 bg-yellow-500 rounded-full"></div>
                                <span className="text-xs">Medium</span>
                              </div>
                            </td>
                            <td className="text-right p-2 font-mono text-xs">+$18K</td>
                            <td className="p-2 text-xs">Optimize usage</td>
                          </tr>
                          <tr className="border-b">
                            <td className="p-2 text-xs">Tech Supplies Inc</td>
                            <td className="p-2">
                              <div className="flex items-center gap-1">
                                <div className="size-2 bg-green-500 rounded-full"></div>
                                <span className="text-xs">Low</span>
                              </div>
                            </td>
                            <td className="text-right p-2 font-mono text-xs">-$5K</td>
                            <td className="p-2 text-xs">Monitor quarterly</td>
                          </tr>
                          <tr className="border-b">
                            <td className="p-2 text-xs">Payroll Services</td>
                            <td className="p-2">
                              <div className="flex items-center gap-1">
                                <div className="size-2 bg-green-500 rounded-full"></div>
                                <span className="text-xs">Low</span>
                              </div>
                            </td>
                            <td className="text-right p-2 font-mono text-xs">On track</td>
                            <td className="p-2 text-xs">No action needed</td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* MAIN SECTION 2: Workforce & Asset Cost Intelligence */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="size-5" />
                Workforce & Asset Cost Intelligence
              </CardTitle>
              <CardDescription>Real-time cost analysis with AI-generated insights</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-semibold mb-3 text-sm">Payroll Trend Analysis</h4>
                  <ResponsiveContainer width="100%" height={200}>
                    <AreaChart data={[
                      { month: 'Jan', payroll: 850000, forecast: 850000 },
                      { month: 'Feb', payroll: 865000, forecast: 860000 },
                      { month: 'Mar', payroll: 880000, forecast: 870000 },
                      { month: 'Apr', payroll: 890000, forecast: 880000 },
                      { month: 'May', payroll: 915000, forecast: 890000 },
                    ]}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip formatter={(value) => `$${(Number(value) / 1000).toFixed(0)}K`} />
                      <Area type="monotone" dataKey="payroll" stroke="#3b82f6" fill="#93c5fd" name="Actual" />
                      <Area type="monotone" dataKey="forecast" stroke="#10b981" fill="#86efac" strokeDasharray="5 5" name="Forecast" />
                    </AreaChart>
                  </ResponsiveContainer>

                  <div className="mt-4 p-3 bg-orange-50 dark:bg-orange-900/20 rounded border border-orange-200 dark:border-orange-800">
                    <div className="flex items-start gap-2">
                      <AlertTriangle className="size-4 text-orange-600 dark:text-orange-400 mt-0.5" />
                      <div className="text-sm">
                        <strong>Operations payroll exceeds forecast by 12%</strong>
                        <p className="text-xs mt-1 text-muted-foreground">
                          New hires + overtime contributing to variance. Consider headcount freeze.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="font-semibold mb-3 text-sm">Asset Depreciation Forecast</h4>
                  <ResponsiveContainer width="100%" height={200}>
                    <LineChart data={[
                      { month: 'Jan', depreciation: 9500 },
                      { month: 'Feb', depreciation: 9600 },
                      { month: 'Mar', depreciation: 9650 },
                      { month: 'Apr', depreciation: 9667 },
                      { month: 'May', depreciation: 9667 },
                      { month: 'Jun', depreciation: 12000 },
                    ]}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip formatter={(value) => `$${Number(value).toLocaleString()}`} />
                      <Line type="monotone" dataKey="depreciation" stroke="#ef4444" strokeWidth={2} />
                    </LineChart>
                  </ResponsiveContainer>

                  <div className="mt-4 p-3 bg-red-50 dark:bg-red-900/20 rounded border border-red-200 dark:border-red-800">
                    <div className="flex items-start gap-2">
                      <AlertTriangle className="size-4 text-red-600 dark:text-red-400 mt-0.5" />
                      <div className="text-sm">
                        <strong>Machinery replacement likely within 8 months</strong>
                        <p className="text-xs mt-1 text-muted-foreground">
                          Manufacturing equipment reaching end of useful life. Budget $450K for replacement.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* MAIN SECTION 3: AI Recommendations */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Brain className="size-5" />
                AI Recommendations
              </CardTitle>
              <CardDescription>Automated insights and actionable suggestions prioritized by impact</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="p-4 bg-gradient-to-r from-purple-50 to-blue-50 dark:from-purple-900/20 dark:to-blue-900/20 rounded-lg border border-purple-200 dark:border-purple-800">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <Badge variant="destructive">Priority: HIGH</Badge>
                      <Badge variant="outline">Potential Savings: $85K/year</Badge>
                    </div>
                  </div>
                  <h4 className="font-semibold mb-2 flex items-center gap-2">
                    <DollarSign className="size-4" />
                    Renegotiate Office Lease
                  </h4>
                  <p className="text-sm text-muted-foreground mb-3">
                    Current lease is 15% above market rate for similar properties in the area.
                    Comparable spaces available at $72K/mo (current: $85K/mo). Contract renewal in 18 months.
                  </p>
                  <div className="flex gap-2">
                    <Button size="sm" variant="default">Schedule Review</Button>
                    <Button size="sm" variant="outline">View Comparables</Button>
                  </div>
                </div>

                <div className="p-4 bg-gradient-to-r from-yellow-50 to-orange-50 dark:from-yellow-900/20 dark:to-orange-900/20 rounded-lg border border-yellow-200 dark:border-yellow-800">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <Badge variant="default">Priority: MEDIUM</Badge>
                      <Badge variant="outline">Cost Reduction: 12%</Badge>
                    </div>
                  </div>
                  <h4 className="font-semibold mb-2 flex items-center gap-2">
                    <TrendingDown className="size-4" />
                    Freeze Hiring in Operations
                  </h4>
                  <p className="text-sm text-muted-foreground mb-3">
                    Operations department is 12% over payroll budget. Current headcount sufficient based on productivity analysis.
                    Recommend hiring freeze for Q3-Q4 2026 to bring costs back in line.
                  </p>
                  <div className="flex gap-2">
                    <Button size="sm" variant="default">Implement Freeze</Button>
                    <Button size="sm" variant="outline">Review Analysis</Button>
                  </div>
                </div>

                <div className="p-4 bg-gradient-to-r from-green-50 to-teal-50 dark:from-green-900/20 dark:to-teal-900/20 rounded-lg border border-green-200 dark:border-green-800">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <Badge variant="default">Priority: MEDIUM</Badge>
                      <Badge variant="outline">Potential Savings: $40K/year</Badge>
                    </div>
                  </div>
                  <h4 className="font-semibold mb-2 flex items-center gap-2">
                    <TrendingDown className="size-4" />
                    Reduce Cloud Infrastructure Usage
                  </h4>
                  <p className="text-sm text-muted-foreground mb-3">
                    Cloud spend increased 25% MoM. AI analysis shows 30% of compute resources idle during off-peak hours.
                    Implement auto-scaling and reserved instances for predictable workloads.
                  </p>
                  <div className="flex gap-2">
                    <Button size="sm" variant="default">Optimize Now</Button>
                    <Button size="sm" variant="outline">View Usage Report</Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="forecast" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Forecasting by Element & Department</CardTitle>
              <CardDescription>Budget vs actual comparisons per quota with AI-powered forecasts</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <KPICard
                    title="Wages & Salaries (Jul)"
                    value="$915K"
                    subtitle="Forecast (Budget: $850K)"
                    variant="warning"
                  />
                  <KPICard
                    title="Contractor Fees (Jul)"
                    value="$125K"
                    subtitle="Forecast (Budget: $100K)"
                    variant="warning"
                  />
                  <KPICard
                    title="Electricity (Jul)"
                    value="$42K"
                    subtitle="Forecast (Budget: $40K)"
                    variant="default"
                  />
                </div>

                <ResponsiveContainer width="100%" height={350}>
                  <LineChart data={[
                    { month: 'Jan', wages: 850000, contractors: 100000, electricity: 38000 },
                    { month: 'Feb', wages: 865000, contractors: 105000, electricity: 40000 },
                    { month: 'Mar', wages: 880000, contractors: 110000, electricity: 41000 },
                    { month: 'Apr', wages: 890000, contractors: 115000, electricity: 43000 },
                    { month: 'May', wages: 890000, contractors: 120000, electricity: 45000 },
                    { month: 'Jun', wages: 905000, contractors: 122000, electricity: 44000 },
                    { month: 'Jul', wages: 915000, contractors: 125000, electricity: 42000 },
                  ]}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip formatter={(value) => `$${(Number(value) / 1000).toFixed(0)}K`} />
                    <Legend />
                    <Line type="monotone" dataKey="wages" stroke="#3b82f6" strokeWidth={2} name="Wages & Salaries" />
                    <Line type="monotone" dataKey="contractors" stroke="#10b981" strokeWidth={2} name="Contractor Fees" />
                    <Line type="monotone" dataKey="electricity" stroke="#f59e0b" strokeWidth={2} name="Electricity" />
                  </LineChart>
                </ResponsiveContainer>

                <div className="bg-purple-50 dark:bg-purple-950/20 p-4 rounded-lg border border-purple-200 dark:border-purple-800">
                  <h4 className="font-semibold mb-2 flex items-center gap-2">
                    <TrendingUp className="size-4" />
                    Element-Level Forecast Insights
                  </h4>
                  <ul className="text-sm space-y-1">
                    <li>• <strong>Wages & Salaries:</strong> Trending +7.6% over budget due to new hires in Engineering</li>
                    <li>• <strong>Contractor Fees:</strong> Likely to exceed budget by 25% - consider renegotiating rates or reducing scope</li>
                    <li>• <strong>Electricity:</strong> On track with seasonal variations accounted for</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="report" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Monthly On-Track Reporting</CardTitle>
              <CardDescription>Comprehensive report for CFO covering department and element status</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <KPICard
                    title="On-Track Departments"
                    value="3 / 6"
                    subtitle="50% within budget"
                    variant="warning"
                  />
                  <KPICard
                    title="Total Depreciation"
                    value="$9,667"
                    subtitle="This month"
                    variant="default"
                  />
                  <KPICard
                    title="Cost Leakage"
                    value="$72K"
                    subtitle="Identified opportunities"
                    variant="danger"
                  />
                </div>

                <div>
                  <h4 className="font-semibold mb-3">Department Status</h4>
                  <div className="space-y-2">
                    {departmentCosts.map((dept) => {
                      const variancePercent = (dept.variance / dept.budget) * 100;
                      const onTrack = Math.abs(variancePercent) < 5;
                      return (
                        <div key={dept.department} className="flex items-center justify-between p-3 border rounded-lg">
                          <span className="font-medium">{dept.department}</span>
                          <StatusIndicator status={onTrack ? 'on-track' : 'off-track'} />
                        </div>
                      );
                    })}
                  </div>
                </div>

                <div>
                  <h4 className="font-semibold mb-3">Cost Element Status</h4>
                  <div className="space-y-2">
                    {costElementBreakdown.slice(0, 5).map((element) => {
                      const variancePercent = (element.variance / element.budget) * 100;
                      const onTrack = Math.abs(variancePercent) < 8;
                      return (
                        <div key={element.element} className="flex items-center justify-between p-3 border rounded-lg">
                          <span className="font-medium text-sm">{element.element}</span>
                          <StatusIndicator status={onTrack ? 'on-track' : 'off-track'} />
                        </div>
                      );
                    })}
                  </div>
                </div>

                <div className="bg-orange-50 dark:bg-orange-950/20 p-4 rounded-lg border border-orange-200 dark:border-orange-800">
                  <h4 className="font-semibold mb-2">Asset Management Gaps</h4>
                  <ul className="text-sm space-y-1">
                    <li>• 3 assets showing irregular depreciation patterns (flagged for CFO review)</li>
                    <li>• Office equipment depreciation schedule needs updating - 2 items reached end of useful life</li>
                    <li>• Vehicle lease renewals due in Q3 - recommend early negotiations</li>
                  </ul>
                </div>

                <div className="flex gap-2">
                  <Button
                    className="flex-1"
                    variant="outline"
                    onClick={() => {
                      toast.info('Opening report preview...');
                      setTimeout(() => {
                        const reportContent = `
MONTHLY ON-TRACK REPORT
Generated: ${new Date().toLocaleDateString()}

DEPARTMENT STATUS:
- On-Track: 3/6 departments
- Budget Utilization: 100.2%

COST ELEMENT STATUS:
- Wages & Salaries: OFF TRACK (+4.7%)
- Contractor Fees: OFF TRACK (+20%)
- Other elements: ON TRACK

ASSET MANAGEMENT:
- 3 assets with irregular depreciation
- Vehicle lease renewals due Q3

RECOMMENDATIONS:
- Review contractor fee structure
- Update office equipment depreciation schedule
                        `;
                        const blob = new Blob([reportContent], { type: 'text/plain' });
                        const url = URL.createObjectURL(blob);
                        const a = document.createElement('a');
                        a.href = url;
                        a.download = `Monthly_Report_Preview_${new Date().toISOString().split('T')[0]}.txt`;
                        a.click();
                        URL.revokeObjectURL(url);
                        toast.success('Preview downloaded!');
                      }, 500);
                    }}
                  >
                    <Eye className="size-4 mr-2" />
                    Preview Report
                  </Button>
                  <Button
                    className="flex-1"
                    onClick={() => {
                      toast.success('Sending report to CFO...');
                      setTimeout(() => {
                        toast.success('Monthly report successfully sent to CFO (Sarah Johnson)');
                      }, 1500);
                    }}
                  >
                    <Send className="size-4 mr-2" />
                    Send to CFO
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
