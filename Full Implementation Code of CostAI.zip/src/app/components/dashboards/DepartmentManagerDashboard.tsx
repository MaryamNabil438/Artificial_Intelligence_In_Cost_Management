import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../ui/card';
import { KPICard } from '../KPICard';
import { AlertCard } from '../AlertCard';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Badge } from '../ui/badge';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { alerts, budgetRequests } from '../../data/mockData';
import { CheckCircle, Clock, FileText, Download, Eye } from 'lucide-react';
import { useState, useMemo } from 'react';
import { BudgetRequestModal } from '../modals/BudgetRequestModal';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { toast } from 'sonner';

export function DepartmentManagerDashboard() {
  const department = 'Engineering';
  const [requestModalOpen, setRequestModalOpen] = useState(false);
  const [requests, setRequests] = useState(budgetRequests);
  const [timelineMonths, setTimelineMonths] = useState(3);

  const allMonthlyData = [
    { month: 'Dec 2025', budget: 430000, actual: 425000 },
    { month: 'Jan', budget: 440000, actual: 435000 },
    { month: 'Feb', budget: 445000, actual: 448000 },
    { month: 'Mar', budget: 450000, actual: 452000 },
    { month: 'Apr', budget: 450000, actual: 458000 },
    { month: 'May', budget: 450000, actual: 465000 },
    { month: 'Jun', budget: 455000, actual: 472000 },
    { month: 'Jul', budget: 460000, actual: 468000 },
    { month: 'Aug', budget: 460000, actual: 475000 },
  ];

  const monthlyData = useMemo(() => {
    return allMonthlyData.slice(-timelineMonths);
  }, [timelineMonths]);

  const myRequests = requests.filter(r => r.department === department);
  const departmentAlerts = alerts.filter(a => a.department === department);

  const handleRequestSubmit = (request: any) => {
    setRequests([...requests, request]);
    toast.success('Budget request submitted successfully!');
  };

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Department Manager Dashboard</h1>
        <p className="text-muted-foreground">{department} Department - Budget tracking and performance</p>
      </div>

      <Tabs defaultValue="dashboard" className="w-full">
        <TabsList>
          <TabsTrigger value="dashboard">My Dashboard</TabsTrigger>
          <TabsTrigger value="budget">Budget Requests</TabsTrigger>
          <TabsTrigger value="spending">Spending Breakdown</TabsTrigger>
          <TabsTrigger value="alerts">My Alerts</TabsTrigger>
          <TabsTrigger value="summary">Weekly AI Summary</TabsTrigger>
        </TabsList>

        <TabsContent value="dashboard" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <KPICard
              title="Monthly Budget"
              value="$450K"
              subtitle={department}
              variant="default"
            />
            <KPICard
              title="Actual Spending"
              value="$465K"
              subtitle="Current month"
              variant="warning"
            />
            <KPICard
              title="Variance"
              value="+$15K"
              subtitle="+3.3% over budget"
              variant="danger"
            />
            <KPICard
              title="Budget Utilization"
              value="103.3%"
              subtitle="Slightly over"
              variant="warning"
            />
          </div>

          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Monthly Budget Trend - {department}</CardTitle>
                  <CardDescription>Budget vs actual spending over time</CardDescription>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-sm text-muted-foreground">Last</span>
                  <Select value={timelineMonths.toString()} onValueChange={(val) => setTimelineMonths(Number(val))}>
                    <SelectTrigger className="w-32">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="3">3 months</SelectItem>
                      <SelectItem value="4">4 months</SelectItem>
                      <SelectItem value="5">5 months</SelectItem>
                      <SelectItem value="6">6 months</SelectItem>
                      <SelectItem value="7">7 months</SelectItem>
                      <SelectItem value="8">8 months</SelectItem>
                      <SelectItem value="9">9 months</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={monthlyData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip formatter={(value) => `$${(Number(value) / 1000).toFixed(0)}K`} />
                  <Legend />
                  <Bar dataKey="budget" fill="#94a3b8" name="Budget" />
                  <Bar dataKey="actual" fill="#3b82f6" name="Actual" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Department Performance</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <span className="text-sm font-medium">Budget Status</span>
                    <Badge variant="destructive">OFF TRACK</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <span className="text-sm font-medium">Headcount</span>
                    <span className="font-mono">42 employees</span>
                  </div>
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <span className="text-sm font-medium">Avg Cost per Employee</span>
                    <span className="font-mono">$11.1K/mo</span>
                  </div>
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <span className="text-sm font-medium">Top Cost Element</span>
                    <span className="text-sm">Wages & Salaries (68%)</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <Button
                    className="w-full justify-start"
                    variant="outline"
                    onClick={() => setRequestModalOpen(true)}
                  >
                    <FileText className="size-4 mr-2" />
                    Submit New Budget Request
                  </Button>
                  <Button
                    className="w-full justify-start"
                    variant="outline"
                    onClick={() => toast.success('Redirecting to expense approval page...')}
                  >
                    <CheckCircle className="size-4 mr-2" />
                    Approve Team Expenses
                  </Button>
                  <Button
                    className="w-full justify-start"
                    variant="outline"
                    onClick={() => toast.info('Showing pending approvals: 3 items waiting for your review')}
                  >
                    <Clock className="size-4 mr-2" />
                    View Pending Approvals
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="budget" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>My Budget Requests</CardTitle>
              <CardDescription>Submitted requests and approval status - scoped to {department} only</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {myRequests.length > 0 ? (
                  myRequests.map((request) => (
                    <div key={request.id} className="border rounded-lg p-4">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex-1">
                          <h4 className="font-semibold">{request.element}</h4>
                          <p className="text-sm text-muted-foreground">{request.department} Department</p>
                        </div>
                        <Badge variant={
                          request.status === 'approved' ? 'default' :
                          request.status === 'challenged' ? 'destructive' :
                          'outline'
                        }>
                          {request.status.toUpperCase()}
                        </Badge>
                      </div>

                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <p className="text-muted-foreground">Requested Amount</p>
                          <p className="text-lg font-mono font-semibold">${request.requested.toLocaleString()}</p>
                        </div>
                        {request.approved !== null && (
                          <div>
                            <p className="text-muted-foreground">Approved Amount</p>
                            <p className="text-lg font-mono font-semibold text-green-600 dark:text-green-400">
                              ${request.approved.toLocaleString()}
                            </p>
                          </div>
                        )}
                      </div>

                      {request.status === 'challenged' && (
                        <div className="mt-3 p-3 bg-yellow-50 dark:bg-yellow-950/20 rounded border border-yellow-200 dark:border-yellow-800">
                          <p className="text-sm">
                            <strong>Action Required:</strong> Cost Controller has challenged this request.
                            Please provide justification for the amount exceeding historical baseline.
                          </p>
                          <Button size="sm" className="mt-2">Provide Justification</Button>
                        </div>
                      )}
                    </div>
                  ))
                ) : (
                  <div className="text-center p-8 text-muted-foreground">
                    <p>No budget requests for {department}</p>
                    <Button onClick={() => setRequestModalOpen(true)} className="mt-4">
                      Submit New Request
                    </Button>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Submit New Budget Request</CardTitle>
              <CardDescription>k-NN similarity retrieval will show historical context</CardDescription>
            </CardHeader>
            <CardContent>
              <Button onClick={() => setRequestModalOpen(true)} className="w-full" size="lg">
                <FileText className="size-4 mr-2" />
                Create New Budget Request
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="spending" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Spending Breakdown by Cost Element</CardTitle>
              <CardDescription>Current month spending for {department}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {[
                  { element: 'Wages & Salaries', amount: 315000, budget: 305000 },
                  { element: 'Software Licenses', amount: 85000, budget: 80000 },
                  { element: 'Hardware Equipment', amount: 42000, budget: 40000 },
                  { element: 'Contractor Fees', amount: 18000, budget: 20000 },
                  { element: 'Training', amount: 5000, budget: 5000 },
                ].map((item) => {
                  const variance = item.amount - item.budget;
                  const variancePercent = (variance / item.budget) * 100;
                  return (
                    <div key={item.element} className="border rounded-lg p-4">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-medium">{item.element}</h4>
                        <Badge variant={variance > 0 ? 'destructive' : 'default'}>
                          {variance > 0 ? '+' : ''}{variancePercent.toFixed(1)}%
                        </Badge>
                      </div>
                      <div className="grid grid-cols-3 gap-4 text-sm">
                        <div>
                          <p className="text-muted-foreground">Budget</p>
                          <p className="font-mono">${item.budget.toLocaleString()}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Actual</p>
                          <p className="font-mono">${item.amount.toLocaleString()}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Variance</p>
                          <p className={`font-mono ${variance > 0 ? 'text-red-600 dark:text-red-400' : 'text-green-600 dark:text-green-400'}`}>
                            {variance > 0 ? '+' : ''}${Math.abs(variance).toLocaleString()}
                          </p>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="alerts" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <KPICard
              title="My Alerts"
              value={departmentAlerts.length.toString()}
              subtitle="For my department"
              variant="warning"
            />
            <KPICard
              title="Critical"
              value={departmentAlerts.filter(a => a.severity === 'critical').length.toString()}
              subtitle="Immediate action needed"
              variant="danger"
            />
            <KPICard
              title="Resolved This Month"
              value="5"
              subtitle="Addressed alerts"
              variant="success"
            />
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Alerts for {department}</CardTitle>
              <CardDescription>Specific and tiered alerts - scoped to your department only</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {departmentAlerts.length > 0 ? (
                  departmentAlerts.map(alert => (
                    <AlertCard key={alert.id} {...alert} />
                  ))
                ) : (
                  <div className="text-center p-8 text-muted-foreground">
                    <CheckCircle className="size-12 mx-auto mb-2 text-green-500" />
                    <p>No active alerts for {department}</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="summary" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Weekly AI Summary for {department}</CardTitle>
              <CardDescription>AI-generated insights including pricing policy implications</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="p-4 bg-blue-50 dark:bg-blue-950/20 rounded-lg border border-blue-200 dark:border-blue-800">
                  <h4 className="font-semibold mb-2">Week of May 5-11, 2026</h4>
                  <div className="space-y-3 text-sm">
                    <div>
                      <p className="font-semibold">Budget Performance</p>
                      <p>Your department spent $465K against a budget of $450K, representing a +3.3% variance.
                      Primary driver: increased software license costs (+$5K) and contractor fees (+$8K).</p>
                    </div>
                    <div>
                      <p className="font-semibold">Key Highlights</p>
                      <ul className="list-disc list-inside space-y-1 ml-2">
                        <li>AWS Egypt payment was 3x higher than usual - flagged for investigation</li>
                        <li>New hires in May increased wage costs by $10K</li>
                        <li>Software license renewal completed on time</li>
                      </ul>
                    </div>
                    <div>
                      <p className="font-semibold">Pricing Policy Implications</p>
                      <p className="text-sm">
                        Your department's increased infrastructure costs (+12% MoM) are affecting product margins.
                        Consider reviewing cloud resource allocation or adjusting product pricing to maintain target margins.
                        Current gross margin impact: -0.8 percentage points.
                      </p>
                    </div>
                    <div>
                      <p className="font-semibold">Upcoming Items</p>
                      <ul className="list-disc list-inside space-y-1 ml-2">
                        <li>Q3 budget request deadline: May 20</li>
                        <li>Annual performance reviews due: May 31</li>
                        <li>Cloud infrastructure audit scheduled: May 15</li>
                      </ul>
                    </div>
                  </div>
                </div>

                <div className="p-4 border rounded-lg">
                  <h4 className="font-semibold mb-2">AI Recommendations</h4>
                  <ul className="text-sm space-y-2">
                    <li className="flex items-start gap-2">
                      <Badge variant="outline" className="mt-0.5">Cost Optimization</Badge>
                      <span>Review AWS usage patterns - potential for 15-20% savings through reserved instances</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Badge variant="outline" className="mt-0.5">Budget Planning</Badge>
                      <span>Consider requesting +8% budget increase for Q3 to account for planned headcount growth</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Badge variant="outline" className="mt-0.5">Process Improvement</Badge>
                      <span>Implement approval workflow for contractor fees above $5K to prevent budget overruns</span>
                    </li>
                  </ul>
                </div>

                <Button
                  className="w-full"
                  onClick={() => {
                    toast.success('Generating detailed report...');
                    setTimeout(() => {
                      const blob = new Blob([`Weekly AI Summary Report for ${department}\n\nGenerated: ${new Date().toLocaleDateString()}`], {
                        type: 'text/plain',
                      });
                      const url = URL.createObjectURL(blob);
                      const a = document.createElement('a');
                      a.href = url;
                      a.download = `${department}_Weekly_Report_${new Date().toISOString().split('T')[0]}.pdf`;
                      a.click();
                      URL.revokeObjectURL(url);
                      toast.success('Report downloaded successfully!');
                    }, 1000);
                  }}
                >
                  <Download className="size-4 mr-2" />
                  Generate Detailed Report
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <BudgetRequestModal
        open={requestModalOpen}
        onClose={() => setRequestModalOpen(false)}
        onSubmit={handleRequestSubmit}
        department={department}
      />
    </div>
  );
}
