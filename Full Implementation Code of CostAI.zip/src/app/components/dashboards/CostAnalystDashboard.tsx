import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../ui/card';
import { KPICard } from '../KPICard';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { ScatterChart, Scatter, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, Legend } from 'recharts';
import { transactions, departmentCosts, costElementBreakdown, monthlyRevenueData } from '../../data/mockData';
import { FileText, Download, AlertOctagon } from 'lucide-react';
import { useState } from 'react';
import { ReportGeneratorModal } from '../modals/ReportGeneratorModal';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Textarea } from '../ui/textarea';
import { toast } from 'sonner';

export function CostAnalystDashboard() {
  const [reportModalOpen, setReportModalOpen] = useState(false);
  const [reviewedTransactions, setReviewedTransactions] = useState<Set<number>>(new Set());
  const [feedbackStates, setFeedbackStates] = useState<{[key: number]: {reason: string, notes: string}}>({});
  const [showFeedbackForm, setShowFeedbackForm] = useState<number | null>(null);

  const anomalyData = transactions.map((t, i) => ({
    id: t.id,
    amount: t.amount,
    anomalyScore: t.anomaly ? Math.random() * 0.5 + 0.5 : Math.random() * 0.3,
    vendor: t.vendor,
  }));

  const handleMarkFalsePositive = (transactionId: number) => {
    const feedback = feedbackStates[transactionId];
    if (!feedback || !feedback.reason) {
      toast.error('Please select a reason before submitting');
      return;
    }

    setReviewedTransactions(new Set([...reviewedTransactions, transactionId]));
    toast.success('Feedback submitted — this will improve future detection');
    setShowFeedbackForm(null);
  };

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Cost Analyst Dashboard</h1>
        <p className="text-muted-foreground">Deep analytics, anomaly investigation, and reporting</p>
      </div>

      <Tabs defaultValue="analytics" className="w-full">
        <TabsList>
          <TabsTrigger value="analytics">Cost Analytics</TabsTrigger>
          <TabsTrigger value="anomaly">Anomaly Investigation</TabsTrigger>
          <TabsTrigger value="trends">Trend Analysis</TabsTrigger>
          <TabsTrigger value="report">Generate Report</TabsTrigger>
        </TabsList>

        <TabsContent value="analytics" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <KPICard
              title="Total Transactions"
              value={transactions.length.toString()}
              subtitle="This month"
              variant="default"
            />
            <KPICard
              title="Anomalies Detected"
              value={transactions.filter(t => t.anomaly).length.toString()}
              subtitle="Flagged for review"
              variant="warning"
            />
            <KPICard
              title="Avg Transaction Size"
              value={`$${(transactions.reduce((sum, t) => sum + t.amount, 0) / transactions.length / 1000).toFixed(1)}K`}
              subtitle="Mean value"
              variant="default"
            />
            <KPICard
              title="Analysis Models"
              value="2 Active"
              subtitle="Autoencoder, Isolation Forest"
              variant="success"
            />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Department Cost Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {departmentCosts.map((dept) => {
                    const percent = (dept.actual / departmentCosts.reduce((sum, d) => sum + d.actual, 0)) * 100;
                    return (
                      <div key={dept.department} className="space-y-1">
                        <div className="flex items-center justify-between text-sm">
                          <span>{dept.department}</span>
                          <span className="font-mono">${(dept.actual / 1000).toFixed(0)}K ({percent.toFixed(1)}%)</span>
                        </div>
                        <div className="h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-blue-500"
                            style={{ width: `${percent}%` }}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Cost Element Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {costElementBreakdown.slice(0, 5).map((element) => {
                    const percent = (element.amount / costElementBreakdown.reduce((sum, e) => sum + e.amount, 0)) * 100;
                    return (
                      <div key={element.element} className="space-y-1">
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-xs">{element.element}</span>
                          <span className="font-mono text-xs">${(element.amount / 1000).toFixed(0)}K ({percent.toFixed(1)}%)</span>
                        </div>
                        <div className="h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-green-500"
                            style={{ width: `${percent}%` }}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="anomaly" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>AI Anomaly Detection</CardTitle>
              <CardDescription>Autoencoder and Isolation Forest methods for advanced pattern recognition</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="mb-6">
                <ResponsiveContainer width="100%" height={300}>
                  <ScatterChart>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="id" name="Transaction ID" />
                    <YAxis dataKey="amount" name="Amount" />
                    <Tooltip
                      content={({ payload }) => {
                        if (payload && payload.length > 0) {
                          const data = payload[0].payload;
                          return (
                            <div className="bg-white dark:bg-gray-800 p-3 border rounded shadow-lg">
                              <p className="font-semibold">{data.vendor}</p>
                              <p className="text-sm">Amount: ${data.amount.toLocaleString()}</p>
                              <p className="text-sm">Anomaly Score: {(data.anomalyScore * 100).toFixed(1)}%</p>
                            </div>
                          );
                        }
                        return null;
                      }}
                    />
                    <Scatter
                      data={anomalyData}
                      fill={(entry) => entry.anomalyScore > 0.5 ? '#ef4444' : '#3b82f6'}
                    />
                  </ScatterChart>
                </ResponsiveContainer>
              </div>

              <div className="space-y-3">
                <h4 className="font-semibold">Flagged Transactions</h4>
                {transactions.filter(t => t.anomaly).map((transaction) => {
                  const isReviewed = reviewedTransactions.has(transaction.id);
                  const isFormOpen = showFeedbackForm === transaction.id;
                  const feedback = feedbackStates[transaction.id] || { reason: '', notes: '' };

                  return (
                    <div
                      key={transaction.id}
                      className={`border rounded-lg p-4 ${isReviewed ? 'bg-gray-100 dark:bg-gray-800/50 opacity-75' : 'bg-red-50 dark:bg-red-950/20'}`}
                    >
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <h4 className="font-semibold">{transaction.vendor}</h4>
                          <p className="text-sm text-muted-foreground">{transaction.category} - {transaction.department}</p>
                        </div>
                        {isReviewed ? (
                          <Badge variant="outline">Reviewed — False Positive</Badge>
                        ) : (
                          <Badge variant="destructive">ANOMALY</Badge>
                        )}
                      </div>
                      <div className="grid grid-cols-3 gap-4 text-sm mt-3">
                        <div>
                          <p className="text-muted-foreground">Amount</p>
                          <p className="font-mono font-semibold">{transaction.currency} {transaction.amount.toLocaleString()}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Date</p>
                          <p className="font-mono">{transaction.date}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Detection</p>
                          <p className="text-xs">Autoencoder + Isolation Forest</p>
                        </div>
                      </div>
                      {transaction.id === 1 && (
                        <div className="mt-3 p-2 bg-white dark:bg-gray-900 rounded text-xs">
                          <strong>Why flagged:</strong> Amount 3x higher than historical average for this vendor.
                          Previous payments: EGP 18,500 (avg). Current: EGP 57,555.
                        </div>
                      )}

                      {!isReviewed && (
                        <div className="mt-4">
                          {!isFormOpen ? (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => setShowFeedbackForm(transaction.id)}
                              className="flex items-center gap-2"
                            >
                              <AlertOctagon className="size-4" />
                              Mark as False Positive
                            </Button>
                          ) : (
                            <div className="space-y-3 p-4 bg-white dark:bg-gray-900 rounded-lg border">
                              <div>
                                <label className="text-sm font-medium mb-2 block">Reason</label>
                                <Select
                                  value={feedback.reason}
                                  onValueChange={(value) =>
                                    setFeedbackStates({ ...feedbackStates, [transaction.id]: { ...feedback, reason: value }})
                                  }
                                >
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select a reason..." />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="expected">Expected Payment</SelectItem>
                                    <SelectItem value="approved">Already Approved</SelectItem>
                                    <SelectItem value="duplicate">Duplicate of Known Transaction</SelectItem>
                                    <SelectItem value="other">Other</SelectItem>
                                  </SelectContent>
                                </Select>
                              </div>

                              <div>
                                <label className="text-sm font-medium mb-2 block">Investigation Notes</label>
                                <Textarea
                                  placeholder="Add context about why this is a false positive..."
                                  value={feedback.notes}
                                  onChange={(e) =>
                                    setFeedbackStates({ ...feedbackStates, [transaction.id]: { ...feedback, notes: e.target.value }})
                                  }
                                  className="min-h-[80px]"
                                />
                              </div>

                              <div className="flex gap-2">
                                <Button
                                  size="sm"
                                  onClick={() => handleMarkFalsePositive(transaction.id)}
                                >
                                  Confirm & Submit Feedback
                                </Button>
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() => setShowFeedbackForm(null)}
                                >
                                  Cancel
                                </Button>
                              </div>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Detection Algorithm Comparison</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left p-2">Algorithm</th>
                      <th className="text-left p-2">Type</th>
                      <th className="text-right p-2">Anomalies Found</th>
                      <th className="text-right p-2">Precision</th>
                      <th className="text-left p-2">Best For</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border-b">
                      <td className="p-2">Autoencoder</td>
                      <td className="p-2"><Badge variant="outline">Neural Net</Badge></td>
                      <td className="text-right p-2 font-mono">3</td>
                      <td className="text-right p-2 font-mono">94%</td>
                      <td className="p-2 text-sm">Complex pattern learning</td>
                    </tr>
                    <tr className="border-b">
                      <td className="p-2">Isolation Forest</td>
                      <td className="p-2"><Badge variant="outline">Tree-based</Badge></td>
                      <td className="text-right p-2 font-mono">3</td>
                      <td className="text-right p-2 font-mono">92%</td>
                      <td className="p-2 text-sm">High-dimensional data</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="trends" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Historical Trend Analysis</CardTitle>
              <CardDescription>6-month cost trends with forecasting</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={350}>
                <LineChart data={monthlyRevenueData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip formatter={(value) => `$${(Number(value) / 1000).toFixed(0)}K`} />
                  <Legend />
                  <Line type="monotone" dataKey="actual" stroke="#3b82f6" strokeWidth={2} name="Actual" />
                  <Line type="monotone" dataKey="forecast" stroke="#10b981" strokeWidth={2} strokeDasharray="5 5" name="Forecast" />
                </LineChart>
              </ResponsiveContainer>

              <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-4 border rounded-lg">
                  <p className="text-sm text-muted-foreground">Month-over-Month Growth</p>
                  <p className="text-2xl font-bold text-green-600 dark:text-green-400">+12.3%</p>
                  <p className="text-xs text-muted-foreground mt-1">Average trend</p>
                </div>
                <div className="p-4 border rounded-lg">
                  <p className="text-sm text-muted-foreground">Forecast Accuracy</p>
                  <p className="text-2xl font-bold">94.2%</p>
                  <p className="text-xs text-muted-foreground mt-1">Past 3 months</p>
                </div>
                <div className="p-4 border rounded-lg">
                  <p className="text-sm text-muted-foreground">Trend Direction</p>
                  <p className="text-2xl font-bold text-blue-600 dark:text-blue-400">Upward</p>
                  <p className="text-xs text-muted-foreground mt-1">Positive momentum</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="report" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="size-5" />
                Generate Comprehensive Report
              </CardTitle>
              <CardDescription>
                Multi-currency handling, cost element breakdowns, and on-track/off-track status
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Button onClick={() => setReportModalOpen(true)} className="w-full" size="lg">
                <FileText className="size-4 mr-2" />
                Open Report Generator
              </Button>

              <div className="bg-blue-50 dark:bg-blue-950/20 p-4 rounded-lg border border-blue-200 dark:border-blue-800">
                <h4 className="font-semibold mb-2 text-sm">Report Features</h4>
                <ul className="text-sm space-y-1">
                  <li>• Cost element level breakdowns (not just department totals)</li>
                  <li>• Multi-currency handling with independent exchange rates</li>
                  <li>• On-track/off-track status per department and element</li>
                  <li>• AI-generated insights and recommendations</li>
                  <li>• Anomaly detection findings with explainability</li>
                  <li>• Export to PDF, Excel, or PowerPoint</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <ReportGeneratorModal
        open={reportModalOpen}
        onClose={() => setReportModalOpen(false)}
      />
    </div>
  );
}
