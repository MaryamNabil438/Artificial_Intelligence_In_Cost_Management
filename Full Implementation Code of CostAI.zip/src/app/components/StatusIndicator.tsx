import { CheckCircle, AlertTriangle, XCircle } from 'lucide-react';
import { Badge } from './ui/badge';

interface StatusIndicatorProps {
  status: 'on-track' | 'at-risk' | 'off-track' | 'low' | 'medium' | 'high' | 'critical';
  showIcon?: boolean;
  showBadge?: boolean;
  label?: string;
}

export function StatusIndicator({ status, showIcon = true, showBadge = true, label }: StatusIndicatorProps) {
  const config = {
    'on-track': {
      icon: CheckCircle,
      color: 'text-green-600 dark:text-green-400',
      bgColor: 'bg-green-50 dark:bg-green-950/20',
      variant: 'default' as const,
      text: 'ON TRACK',
    },
    'at-risk': {
      icon: AlertTriangle,
      color: 'text-yellow-600 dark:text-yellow-400',
      bgColor: 'bg-yellow-50 dark:bg-yellow-950/20',
      variant: 'outline' as const,
      text: 'AT RISK',
    },
    'off-track': {
      icon: XCircle,
      color: 'text-red-600 dark:text-red-400',
      bgColor: 'bg-red-50 dark:bg-red-950/20',
      variant: 'destructive' as const,
      text: 'OFF TRACK',
    },
    'low': {
      icon: CheckCircle,
      color: 'text-green-600 dark:text-green-400',
      bgColor: 'bg-green-50 dark:bg-green-950/20',
      variant: 'secondary' as const,
      text: 'LOW',
    },
    'medium': {
      icon: AlertTriangle,
      color: 'text-yellow-600 dark:text-yellow-400',
      bgColor: 'bg-yellow-50 dark:bg-yellow-950/20',
      variant: 'outline' as const,
      text: 'MEDIUM',
    },
    'high': {
      icon: XCircle,
      color: 'text-orange-600 dark:text-orange-400',
      bgColor: 'bg-orange-50 dark:bg-orange-950/20',
      variant: 'destructive' as const,
      text: 'HIGH',
    },
    'critical': {
      icon: XCircle,
      color: 'text-red-600 dark:text-red-400',
      bgColor: 'bg-red-50 dark:bg-red-950/20',
      variant: 'destructive' as const,
      text: 'CRITICAL',
    },
  };

  const { icon: Icon, color, variant, text } = config[status];

  if (showBadge) {
    return (
      <Badge variant={variant} className="flex items-center gap-1">
        {showIcon && <Icon className="size-3" />}
        {label || text}
      </Badge>
    );
  }

  return (
    <div className={`flex items-center gap-2 ${color}`}>
      {showIcon && <Icon className="size-4" />}
      {label && <span className="font-medium">{label}</span>}
    </div>
  );
}

export function VarianceIndicator({ value, showIcon = true }: { value: number; showIcon?: boolean }) {
  const isPositive = value > 0;
  const Icon = isPositive ? XCircle : CheckCircle;
  const color = isPositive ? 'text-red-600 dark:text-red-400' : 'text-green-600 dark:text-green-400';

  return (
    <span className={`flex items-center gap-1 ${color} font-mono`}>
      {showIcon && <Icon className="size-3" />}
      {isPositive ? '+' : ''}${Math.abs(value).toLocaleString()}
    </span>
  );
}
