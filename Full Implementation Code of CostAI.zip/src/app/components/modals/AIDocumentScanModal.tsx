import { useState, useRef } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '../ui/dialog';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Upload, Camera, Loader2, CheckCircle, AlertCircle, FileImage, X } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';

type DocumentType = 'Invoice' | 'Receipt' | 'Financial Statement' | 'Contract' | 'Payroll';
type ProcessingStage = 'idle' | 'preprocessing' | 'layout-analysis' | 'ocr' | 'complete';

interface ExtractedField {
  label: string;
  value: string;
  confidence: number;
  key: string;
}

interface AIDocumentScanModalProps {
  open: boolean;
  onClose: () => void;
  onComplete: (data: any) => void;
}

export function AIDocumentScanModal({ open, onClose, onComplete }: AIDocumentScanModalProps) {
  const [file, setFile] = useState<File | null>(null);
  const [filePreview, setFilePreview] = useState<string | null>(null);
  const [documentType, setDocumentType] = useState<DocumentType>('Invoice');
  const [stage, setStage] = useState<ProcessingStage>('idle');
  const [extractedFields, setExtractedFields] = useState<ExtractedField[]>([]);
  const [isHandwritten, setIsHandwritten] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [dragActive, setDragActive] = useState(false);

  const handleFileSelect = (selectedFile: File) => {
    setFile(selectedFile);
    setExtractedFields([]);
    setStage('idle');

    if (selectedFile.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setFilePreview(e.target?.result as string);
      };
      reader.readAsDataURL(selectedFile);
    } else {
      setFilePreview(null);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileSelect(e.dataTransfer.files[0]);
    }
  };

  const OCR_BACKEND_URL = 'http://localhost:8000';

  const processDocumentWithBackend = async (imageFile: File): Promise<ExtractedField[]> => {
    const formData = new FormData();
    formData.append('file', imageFile);

    const response = await fetch(`${OCR_BACKEND_URL}/process-document`, {
      method: 'POST',
      body: formData,
    });

    if (!response.ok) {
      throw new Error(`OCR backend error: ${response.statusText}`);
    }

    const data = await response.json();

    if (!data.success || !data.fields || data.fields.length === 0) {
      throw new Error('No fields extracted from document');
    }

    return data.fields;
  };

  const handleScan = async () => {
    if (!file) return;

    try {
      // Stage 1: Preprocessing (happens in backend)
      setStage('preprocessing');
      await new Promise(resolve => setTimeout(resolve, 800));

      // Stage 2: Layout Analysis (happens in backend)
      setStage('layout-analysis');
      await new Promise(resolve => setTimeout(resolve, 800));

      // Stage 3: OCR - Call backend API to process the actual image
      setStage('ocr');
      const fields = await processDocumentWithBackend(file);

      // Check for handwritten detection (backend could add this flag)
      const hasLowConfidence = fields.some(f => f.confidence < 0.70);
      setIsHandwritten(hasLowConfidence);

      setExtractedFields(fields);
      setStage('complete');
    } catch (error) {
      console.error('OCR processing failed:', error);

      let errorMessage = 'Failed to process document';

      if (error instanceof TypeError && error.message === 'Failed to fetch') {
        errorMessage = 'Cannot connect to OCR backend. Please start the backend server at http://localhost:8000 (see ocr-backend/README.md for setup instructions)';
      } else if (error instanceof Error) {
        errorMessage = error.message;
      }

      setExtractedFields([{
        label: 'Backend Connection Error',
        value: errorMessage,
        confidence: 0.0,
        key: 'error'
      }]);
      setStage('complete');
    }
  };

  const handleFieldEdit = (key: string, value: string) => {
    setExtractedFields(prev =>
      prev.map(f => f.key === key ? { ...f, value, confidence: 1.0 } : f)
    );
  };

  const handleComplete = () => {
    const data = {
      documentType,
      file: file?.name,
      fields: extractedFields,
      isHandwritten,
      scanDate: new Date().toISOString(),
    };
    onComplete(data);
    handleReset();
  };

  const handleReset = () => {
    setFile(null);
    setFilePreview(null);
    setExtractedFields([]);
    setStage('idle');
    setIsHandwritten(false);
    onClose();
  };

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 0.9) return 'text-green-600 dark:text-green-400 bg-green-50 dark:bg-green-950/20 border-green-200 dark:border-green-800';
    if (confidence >= 0.8) return 'text-yellow-600 dark:text-yellow-400 bg-yellow-50 dark:bg-yellow-950/20 border-yellow-200 dark:border-yellow-800';
    return 'text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-950/20 border-red-200 dark:border-red-800';
  };

  return (
    <Dialog open={open} onOpenChange={handleReset}>
      <DialogContent className="max-w-7xl max-h-[95vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle>AI Document Scanning - 3-Stage Pipeline</DialogTitle>
          <DialogDescription>
            LayoutLMv3/Donut + AWS Textract/Google Document AI with TrOCR for handwritten documents
          </DialogDescription>
        </DialogHeader>

        <div className="p-3 bg-amber-50 dark:bg-amber-950/20 rounded-lg border border-amber-200 dark:border-amber-800 -mt-2">
          <div className="flex items-start gap-2">
            <AlertCircle className="size-5 text-amber-600 dark:text-amber-400 flex-shrink-0 mt-0.5" />
            <div className="text-sm">
              <p className="font-medium text-amber-900 dark:text-amber-100">Backend Setup Required (~10 minutes)</p>
              <p className="text-amber-800 dark:text-amber-200 mt-1">
                This feature requires the OCR backend server running on <code className="bg-amber-100 dark:bg-amber-900 px-1 py-0.5 rounded text-xs">http://localhost:8000</code>
                {' '}— See <code className="bg-amber-100 dark:bg-amber-900 px-1 py-0.5 rounded text-xs">ocr-backend/QUICKSTART.md</code> for setup instructions.
              </p>
            </div>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto">
          {!file ? (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div
                  className={`border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors ${
                    dragActive ? 'border-blue-500 bg-blue-50 dark:bg-blue-950/20' : 'border-gray-300 dark:border-gray-700'
                  }`}
                  onDragEnter={() => setDragActive(true)}
                  onDragLeave={() => setDragActive(false)}
                  onDragOver={(e) => e.preventDefault()}
                  onDrop={handleDrop}
                  onClick={() => fileInputRef.current?.click()}
                >
                  <Upload className="size-12 mx-auto mb-4 text-gray-400" />
                  <p className="font-medium mb-2">Drop file here or click to upload</p>
                  <p className="text-sm text-muted-foreground">
                    Supports: PDF, JPG, PNG, TIFF
                  </p>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*,.pdf"
                    onChange={(e) => e.target.files && handleFileSelect(e.target.files[0])}
                    className="hidden"
                  />
                </div>

                <div className="border-2 border-dashed rounded-lg p-8 text-center bg-gray-50 dark:bg-gray-900">
                  <Camera className="size-12 mx-auto mb-4 text-gray-400" />
                  <p className="font-medium mb-2">Capture from camera</p>
                  <p className="text-sm text-muted-foreground mb-4">
                    Use device camera for scanning
                  </p>
                  <Button variant="outline" size="sm">
                    <Camera className="size-4 mr-2" />
                    Open Camera
                  </Button>
                </div>
              </div>

              <div>
                <Label>Document Type</Label>
                <Select value={documentType} onValueChange={(v) => setDocumentType(v as DocumentType)}>
                  <SelectTrigger className="w-full mt-2">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Invoice">Invoice</SelectItem>
                    <SelectItem value="Receipt">Receipt</SelectItem>
                    <SelectItem value="Financial Statement">Financial Statement</SelectItem>
                    <SelectItem value="Contract">Contract</SelectItem>
                    <SelectItem value="Payroll">Payroll</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="bg-blue-50 dark:bg-blue-950/20 p-4 rounded-lg border border-blue-200 dark:border-blue-800">
                <h4 className="font-semibold mb-2 text-sm">3-Stage AI Pipeline</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex items-start gap-2">
                    <span className="font-mono text-blue-600">1.</span>
                    <span><strong>Preprocessing:</strong> Deskew, contrast enhancement, noise removal</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className="font-mono text-blue-600">2.</span>
                    <span><strong>Layout Analysis:</strong> ViT model (LayoutLMv3/Donut) detects regions visually</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className="font-mono text-blue-600">3.</span>
                    <span><strong>OCR Extraction:</strong> AWS Textract/Google Document AI per detected region</span>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-6">
              {/* Left: Original Image */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold">Original Document</h3>
                  <Button variant="ghost" size="sm" onClick={() => { setFile(null); setFilePreview(null); setExtractedFields([]); setStage('idle'); }}>
                    <X className="size-4 mr-1" />
                    Clear
                  </Button>
                </div>

                {filePreview ? (
                  <div className="border rounded-lg overflow-hidden bg-gray-100 dark:bg-gray-800">
                    <img
                      src={filePreview}
                      alt="Document"
                      className="w-full h-auto max-h-[600px] object-contain"
                    />
                  </div>
                ) : (
                  <div className="border rounded-lg p-12 text-center bg-gray-50 dark:bg-gray-900 h-[600px] flex items-center justify-center">
                    <div>
                      <FileImage className="size-16 mx-auto mb-3 text-gray-400" />
                      <p className="text-sm text-muted-foreground">PDF Preview</p>
                    </div>
                  </div>
                )}

                <div className="text-sm text-muted-foreground">
                  <div className="flex items-center justify-between py-1">
                    <span>File:</span>
                    <span className="font-medium">{file.name}</span>
                  </div>
                  <div className="flex items-center justify-between py-1">
                    <span>Size:</span>
                    <span className="font-medium">{(file.size / 1024).toFixed(1)} KB</span>
                  </div>
                  <div className="flex items-center justify-between py-1">
                    <span>Type:</span>
                    <Badge variant="outline">{documentType}</Badge>
                  </div>
                </div>
              </div>

              {/* Right: Processing / Extracted Fields */}
              <div className="space-y-3">
                <h3 className="font-semibold">Extraction Results</h3>

                {stage === 'idle' && (
                  <div className="space-y-4">
                    <Button onClick={handleScan} size="lg" className="w-full">
                      Start AI Processing Pipeline
                    </Button>
                    <div className="p-4 bg-gray-50 dark:bg-gray-900 rounded-lg border text-sm">
                      <p className="text-muted-foreground">
                        Ready to process <strong>{documentType}</strong> through 3-stage AI pipeline
                      </p>
                    </div>
                  </div>
                )}

                {(stage === 'preprocessing' || stage === 'layout-analysis' || stage === 'ocr') && (
                  <div className="space-y-4">
                    <div className="p-8 border rounded-lg bg-blue-50 dark:bg-blue-950/20">
                      <Loader2 className="size-12 animate-spin mx-auto mb-4 text-blue-600" />

                      {stage === 'preprocessing' && (
                        <>
                          <p className="text-center font-semibold mb-1">Stage 1: Preparing image...</p>
                          <p className="text-center text-sm text-muted-foreground">
                            Deskew, contrast enhancement, noise removal
                          </p>
                        </>
                      )}

                      {stage === 'layout-analysis' && (
                        <>
                          <p className="text-center font-semibold mb-1">Stage 2: Analyzing document layout...</p>
                          <p className="text-center text-sm text-muted-foreground">
                            ViT model detecting regions visually
                          </p>
                        </>
                      )}

                      {stage === 'ocr' && (
                        <>
                          <p className="text-center font-semibold mb-1">Stage 3: Extracting fields...</p>
                          <p className="text-center text-sm text-muted-foreground">
                            OCR running per detected region
                          </p>
                        </>
                      )}
                    </div>

                    <div className="space-y-2 text-sm">
                      <div className={`flex items-center gap-2 ${stage !== 'preprocessing' ? 'text-green-600' : ''}`}>
                        {stage !== 'preprocessing' ? <CheckCircle className="size-4" /> : <Loader2 className="size-4 animate-spin" />}
                        <span>Preprocessing</span>
                      </div>
                      <div className={`flex items-center gap-2 ${stage === 'ocr' || stage === 'complete' ? 'text-green-600' : stage === 'layout-analysis' ? '' : 'text-muted-foreground'}`}>
                        {stage === 'ocr' || stage === 'complete' ? <CheckCircle className="size-4" /> : stage === 'layout-analysis' ? <Loader2 className="size-4 animate-spin" /> : <div className="size-4 border-2 rounded-full" />}
                        <span>Layout Analysis</span>
                      </div>
                      <div className={`flex items-center gap-2 ${stage === 'complete' ? 'text-green-600' : stage === 'ocr' ? '' : 'text-muted-foreground'}`}>
                        {stage === 'complete' ? <CheckCircle className="size-4" /> : stage === 'ocr' ? <Loader2 className="size-4 animate-spin" /> : <div className="size-4 border-2 rounded-full" />}
                        <span>OCR Extraction</span>
                      </div>
                    </div>
                  </div>
                )}

                {stage === 'complete' && (
                  <div className="space-y-4">
                    <div className={`p-4 rounded-lg border ${isHandwritten ? 'bg-purple-50 dark:bg-purple-950/20 border-purple-200 dark:border-purple-800' : 'bg-green-50 dark:bg-green-950/20 border-green-200 dark:border-green-800'}`}>
                      <div className="flex items-center gap-2">
                        <CheckCircle className={`size-5 ${isHandwritten ? 'text-purple-600 dark:text-purple-400' : 'text-green-600 dark:text-green-400'}`} />
                        <p className="font-semibold">Extraction Complete</p>
                      </div>
                      {isHandwritten && (
                        <p className="text-sm mt-2">
                          <strong>TrOCR detected:</strong> Handwritten content processed with specialized model
                        </p>
                      )}
                    </div>

                    <div className="max-h-[450px] overflow-y-auto space-y-3 pr-2">
                      {extractedFields.map((field) => (
                        <div key={field.key} className="space-y-2">
                          <div className="flex items-center justify-between">
                            <Label className="text-sm font-medium">{field.label}</Label>
                            <Badge
                              variant="outline"
                              className={`text-xs border ${getConfidenceColor(field.confidence)}`}
                            >
                              {(field.confidence * 100).toFixed(0)}% confidence
                            </Badge>
                          </div>
                          <Input
                            value={field.value}
                            onChange={(e) => handleFieldEdit(field.key, e.target.value)}
                            className={field.confidence < 0.85 ? 'border-yellow-500' : ''}
                          />
                        </div>
                      ))}

                      {extractedFields.filter(f => f.confidence < 0.85).length > 0 && (
                        <div className="p-3 bg-amber-50 dark:bg-amber-950/20 rounded border border-amber-200 dark:border-amber-800 flex items-start gap-2 mt-4">
                          <AlertCircle className="size-4 text-amber-600 dark:text-amber-400 mt-0.5 flex-shrink-0" />
                          <p className="text-xs text-amber-900 dark:text-amber-100">
                            {extractedFields.filter(f => f.confidence < 0.85).length} field(s) flagged for review. Please verify highlighted fields.
                          </p>
                        </div>
                      )}
                    </div>

                    <div className="flex gap-2 pt-4 border-t">
                      <Button onClick={handleReset} variant="outline" className="flex-1">
                        Scan Another
                      </Button>
                      <Button onClick={handleComplete} className="flex-1">
                        Confirm & Add to Repository
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
