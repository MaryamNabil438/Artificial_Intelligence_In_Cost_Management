import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '../ui/dialog';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Badge } from '../ui/badge';
import { Card, CardContent } from '../ui/card';
import { Loader2, Zap, InfoIcon } from 'lucide-react';

interface ScenarioSimulatorModalProps {
  open: boolean;
  onClose: () => void;
}

export function ScenarioSimulatorModal({ open, onClose }: ScenarioSimulatorModalProps) {
  const [scenarioType, setScenarioType] = useState('Revenue Growth');
  const [impactMin, setImpactMin] = useState('-10');
  const [impactMax, setImpactMax] = useState('20');
  const [running, setRunning] = useState(false);
  const [results, setResults] = useState<any>(null);

  const handleRun = async () => {
    setRunning(true);
    setResults(null);

    // Simulate Gradient Boosting model training and prediction
    await new Promise(resolve => setTimeout(resolve, 2500));

    // Mock results from XGBoost/LightGBM
    const baseRevenue = 1680000;
    const minImpact = parseFloat(impactMin) / 100;
    const maxImpact = parseFloat(impactMax) / 100;

    setResults({
      p10: Math.round(baseRevenue * (1 + minImpact)),
      p50: Math.round(baseRevenue * (1 + (minImpact + maxImpact) / 2)),
      p90: Math.round(baseRevenue * (1 + maxImpact)),
      featureImportance: [
        { feature: 'Headcount', importance: 0.42 },
        { feature: 'Revenue (historical)', importance: 0.28 },
        { feature: 'Exchange Rates', importance: 0.15 },
        { feature: 'Cost Elements', importance: 0.10 },
        { feature: 'Seasonality', importance: 0.05 },
      ],
      confidence: 0.89,
    });

    setRunning(false);
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Zap className="size-5" />
            Scenario Simulator - Gradient Boosting
          </DialogTitle>
          <DialogDescription>
            AI-powered scenario analysis using XGBoost/LightGBM - learns from historical patterns
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          <div className="grid grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label>Scenario Type</Label>
              <select
                className="w-full p-2 border rounded-md"
                value={scenarioType}
                onChange={(e) => setScenarioType(e.target.value)}
              >
                <option>Revenue Growth</option>
                <option>Cost Reduction</option>
                <option>Headcount Change</option>
                <option>Market Downturn</option>
                <option>Exchange Rate Shock</option>
              </select>
            </div>
            <div className="space-y-2">
              <Label>Min Impact (%)</Label>
              <Input
                type="number"
                value={impactMin}
                onChange={(e) => setImpactMin(e.target.value)}
                placeholder="-10"
              />
            </div>
            <div className="space-y-2">
              <Label>Max Impact (%)</Label>
              <Input
                type="number"
                value={impactMax}
                onChange={(e) => setImpactMax(e.target.value)}
                placeholder="20"
              />
            </div>
          </div>

          <Button
            onClick={handleRun}
            disabled={running}
            className="w-full"
          >
            {running ? (
              <>
                <Loader2 className="size-4 mr-2 animate-spin" />
                Training Gradient Boosting Model...
              </>
            ) : (
              <>
                <Zap className="size-4 mr-2" />
                Run Gradient Boosting Simulation
              </>
            )}
          </Button>

          {results && (
            <div className="space-y-4">
              <div className="bg-blue-50 dark:bg-blue-950/20 p-4 rounded-lg border border-blue-200 dark:border-blue-800">
                <div className="flex items-start gap-2">
                  <InfoIcon className="size-5 text-blue-600 dark:text-blue-400 mt-0.5 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold mb-1">Understanding Your Simulation Results</h4>
                    <p className="text-sm">
                      The model analyzed historical patterns and uncertainty to predict a range of possible outcomes.
                      The three values below represent different confidence levels—think of them as worst-case, most likely, and best-case scenarios.
                    </p>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <Card className="border-red-200 dark:border-red-800 bg-red-50 dark:bg-red-950/20">
                  <CardContent className="pt-6">
                    <p className="text-sm text-muted-foreground mb-1">P10 Outcome (Pessimistic)</p>
                    <p className="text-2xl font-bold">${(results.p10 / 1000000).toFixed(2)}M</p>
                    <p className="text-xs text-muted-foreground mt-1">10th percentile</p>
                    <p className="text-xs mt-2 leading-relaxed">
                      10% chance the outcome will be below this value. This is your downside risk scenario.
                    </p>
                  </CardContent>
                </Card>

                <Card className="border-blue-200 dark:border-blue-800 bg-blue-50 dark:bg-blue-950/20">
                  <CardContent className="pt-6">
                    <p className="text-sm text-muted-foreground mb-1">P50 Outcome (Most Likely)</p>
                    <p className="text-2xl font-bold">${(results.p50 / 1000000).toFixed(2)}M</p>
                    <p className="text-xs text-muted-foreground mt-1">Median prediction</p>
                    <p className="text-xs mt-2 leading-relaxed">
                      50% chance of being above or below this value. Your best central estimate.
                    </p>
                  </CardContent>
                </Card>

                <Card className="border-green-200 dark:border-green-800 bg-green-50 dark:bg-green-950/20">
                  <CardContent className="pt-6">
                    <p className="text-sm text-muted-foreground mb-1">P90 Outcome (Optimistic)</p>
                    <p className="text-2xl font-bold">${(results.p90 / 1000000).toFixed(2)}M</p>
                    <p className="text-xs text-muted-foreground mt-1">90th percentile</p>
                    <p className="text-xs mt-2 leading-relaxed">
                      90% chance the outcome will be below this value. Your upside potential scenario.
                    </p>
                  </CardContent>
                </Card>
              </div>

              <div className="bg-purple-50 dark:bg-purple-950/20 p-4 rounded-lg border border-purple-200 dark:border-purple-800">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-semibold">Feature Importance (XGBoost)</h4>
                  <Badge variant="outline">Model Confidence: {(results.confidence * 100).toFixed(0)}%</Badge>
                </div>
                <p className="text-sm text-muted-foreground mb-3">
                  Shows which factors had the biggest impact on the prediction. Higher percentages mean the model relied more on that factor.
                </p>
                <div className="space-y-2">
                  {results.featureImportance.map((item: any) => (
                    <div key={item.feature} className="space-y-1">
                      <div className="flex items-center justify-between text-sm">
                        <span>{item.feature}</span>
                        <span className="font-mono">{(item.importance * 100).toFixed(0)}%</span>
                      </div>
                      <div className="h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-purple-500"
                          style={{ width: `${item.importance * 100}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
                <p className="text-xs text-muted-foreground mt-3 italic">
                  Model Confidence ({(results.confidence * 100).toFixed(0)}%) indicates how well the model fits historical data. Higher is better, but doesn't guarantee future accuracy.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-amber-50 dark:bg-amber-950/20 p-4 rounded-lg border border-amber-200 dark:border-amber-800">
                  <h4 className="font-semibold mb-2 flex items-center gap-2">
                    <InfoIcon className="size-4" />
                    How to Use These Results
                  </h4>
                  <ul className="text-sm space-y-2">
                    <li className="flex items-start gap-2">
                      <span className="text-amber-600 dark:text-amber-400 mt-0.5">•</span>
                      <span><strong>P10 (Pessimistic):</strong> Use for risk planning and stress testing. Prepare contingency plans for this scenario.</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-amber-600 dark:text-amber-400 mt-0.5">•</span>
                      <span><strong>P50 (Most Likely):</strong> Use for budgets and forecasts. Your baseline planning assumption.</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-amber-600 dark:text-amber-400 mt-0.5">•</span>
                      <span><strong>P90 (Optimistic):</strong> Use for upside planning. What resources you'd need if things go better than expected.</span>
                    </li>
                  </ul>
                </div>

                <div className="bg-blue-50 dark:bg-blue-950/20 p-4 rounded-lg border border-blue-200 dark:border-blue-800">
                  <h4 className="font-semibold mb-2">Why Gradient Boosting?</h4>
                  <p className="text-sm">
                    This model learns non-linear relationships between inputs (headcount, revenue, exchange rates) from
                    historical data. Gradient Boosting produces predictions grounded in actual patterns from your company's past.
                    It handles mixed data types naturally and is highly accurate for tabular financial data.
                  </p>
                </div>
              </div>

              <div className="bg-gray-50 dark:bg-gray-900 p-4 rounded-lg border border-gray-200 dark:border-gray-700">
                <h4 className="font-semibold mb-2">Example Interpretation</h4>
                <p className="text-sm text-muted-foreground">
                  If you simulated "<strong>{scenarioType}</strong>" with a {impactMin}% to {impactMax}% impact range:
                </p>
                <ul className="text-sm space-y-1 mt-2 text-muted-foreground">
                  <li>• There's a 10% chance revenue falls to <strong>${(results.p10 / 1000000).toFixed(2)}M</strong> or below (worst case)</li>
                  <li>• The most likely outcome is around <strong>${(results.p50 / 1000000).toFixed(2)}M</strong> (median)</li>
                  <li>• There's a 10% chance revenue reaches <strong>${(results.p90 / 1000000).toFixed(2)}M</strong> or higher (best case)</li>
                  <li>• The biggest drivers are <strong>{results.featureImportance[0].feature}</strong> ({(results.featureImportance[0].importance * 100).toFixed(0)}%) and <strong>{results.featureImportance[1].feature}</strong> ({(results.featureImportance[1].importance * 100).toFixed(0)}%)</li>
                </ul>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
