import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '../ui/dialog';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Upload, CheckCircle, Loader2, FileImage, AlertCircle } from 'lucide-react';

interface DocumentScanModalProps {
  open: boolean;
  onClose: () => void;
  onExtract: (data: any) => void;
}

export function DocumentScanModal({ open, onClose, onExtract }: DocumentScanModalProps) {
  const [file, setFile] = useState<File | null>(null);
  const [filePreview, setFilePreview] = useState<string | null>(null);
  const [processing, setProcessing] = useState(false);
  const [extractedData, setExtractedData] = useState<any>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const selectedFile = e.target.files[0];
      setFile(selectedFile);
      setExtractedData(null);

      // Create preview for images
      if (selectedFile.type.startsWith('image/')) {
        const reader = new FileReader();
        reader.onload = (e) => {
          setFilePreview(e.target?.result as string);
        };
        reader.readAsDataURL(selectedFile);
      } else {
        setFilePreview(null);
      }
    }
  };

  const generateRealisticExtraction = (fileName: string) => {
    // Generate varied realistic data based on filename patterns
    const scenarios = [
      {
        vendor: 'AWS Egypt',
        amount: '57555',
        currency: 'EGP',
        date: '2026-05-08',
        category: 'Software Licenses',
        department: 'Engineering',
        invoiceNumber: 'INV-2026-0512',
        confidence: { vendor: 0.96, amount: 0.98, date: 0.94, category: 0.89, department: 0.92 },
      },
      {
        vendor: 'Microsoft Azure',
        amount: '12450',
        currency: 'USD',
        date: '2026-05-10',
        category: 'Cloud Infrastructure',
        department: 'Engineering',
        invoiceNumber: 'MS-AZ-8891234',
        confidence: { vendor: 0.99, amount: 0.97, date: 0.95, category: 0.91, department: 0.88 },
      },
      {
        vendor: 'Office Depot',
        amount: '2340',
        currency: 'USD',
        date: '2026-05-09',
        category: 'Office Supplies',
        department: 'Operations',
        invoiceNumber: 'OD-2026-4421',
        confidence: { vendor: 0.93, amount: 0.96, date: 0.97, category: 0.87, department: 0.84 },
      },
      {
        vendor: 'Cairo Office Lease Corp',
        amount: '125000',
        currency: 'EGP',
        date: '2026-05-01',
        category: 'Rent & Facilities',
        department: 'Finance',
        invoiceNumber: 'RENT-MAY-2026',
        confidence: { vendor: 0.92, amount: 0.99, date: 0.98, category: 0.95, department: 0.90 },
      },
      {
        vendor: 'Freelance Designer - Ahmed Hassan',
        amount: '8500',
        currency: 'EGP',
        date: '2026-05-07',
        category: 'Contractor Fees',
        department: 'Marketing',
        invoiceNumber: 'AH-2026-05',
        confidence: { vendor: 0.88, amount: 0.94, date: 0.92, category: 0.86, department: 0.83 },
      },
      {
        vendor: 'Egypt Electricity Company',
        amount: '18750',
        currency: 'EGP',
        date: '2026-05-05',
        category: 'Electricity & Utilities',
        department: 'Operations',
        invoiceNumber: 'EEC-APR-2026',
        confidence: { vendor: 0.97, amount: 0.96, date: 0.93, category: 0.94, department: 0.89 },
      },
    ];

    // Select scenario based on filename hash for consistency
    const hash = fileName.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
    return scenarios[hash % scenarios.length];
  };

  const handleScan = async () => {
    if (!file) return;

    setProcessing(true);

    // Simulate Vision Transformer processing with realistic delay
    await new Promise(resolve => setTimeout(resolve, 2500));

    const extracted = generateRealisticExtraction(file.name);
    setExtractedData(extracted);
    setProcessing(false);
  };

  const handleFieldChange = (field: string, value: string) => {
    setExtractedData({ ...extractedData, [field]: value });
  };

  const handleConfirm = () => {
    if (extractedData) {
      onExtract(extractedData);
      setFile(null);
      setExtractedData(null);
      onClose();
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-5xl max-h-[95vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Document Scanning - Vision Transformer</DialogTitle>
          <DialogDescription>
            AI-powered extraction using Vision Transformer (ViT) - understands document layout and spatial relationships
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {!file ? (
            <div className="border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-lg p-8 text-center">
              <Upload className="size-12 mx-auto mb-4 text-gray-400" />
              <p className="text-sm text-muted-foreground mb-4">
                Upload invoice, receipt, or financial document
              </p>
              <input
                type="file"
                accept="image/*,.pdf"
                onChange={handleFileChange}
                className="hidden"
                id="file-upload"
              />
              <label htmlFor="file-upload">
                <Button type="button" variant="outline" onClick={() => document.getElementById('file-upload')?.click()}>
                  Choose File
                </Button>
              </label>
              <p className="text-xs text-muted-foreground mt-4">
                Supported: PDF, JPG, PNG | Vision Transformer processes spatial layout
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Left: File Preview */}
                <div className="space-y-3">
                  <div className="p-4 bg-blue-50 dark:bg-blue-950/20 rounded-lg border border-blue-200 dark:border-blue-800">
                    <div className="flex items-center justify-between mb-2">
                      <p className="font-semibold text-sm">Document Preview</p>
                      <Badge variant="outline">{file.type || 'Document'}</Badge>
                    </div>
                    <p className="text-xs text-muted-foreground mb-3">
                      File: {file.name} ({(file.size / 1024).toFixed(1)} KB)
                    </p>
                  </div>

                  {filePreview ? (
                    <div className="border rounded-lg overflow-hidden bg-gray-100 dark:bg-gray-800">
                      <img
                        src={filePreview}
                        alt="Document preview"
                        className="w-full h-auto max-h-[400px] object-contain"
                      />
                    </div>
                  ) : (
                    <div className="border rounded-lg p-12 text-center bg-gray-50 dark:bg-gray-900">
                      <FileImage className="size-16 mx-auto mb-3 text-gray-400" />
                      <p className="text-sm text-muted-foreground">
                        {file.type === 'application/pdf' ? 'PDF Preview (scan to extract)' : 'No preview available'}
                      </p>
                    </div>
                  )}
                </div>

                {/* Right: Extracted Data */}
                <div className="space-y-3">
                  <div className="p-4 bg-purple-50 dark:bg-purple-950/20 rounded-lg border border-purple-200 dark:border-purple-800">
                    <p className="font-semibold text-sm mb-1">ViT Processing Status</p>
                    <p className="text-xs text-muted-foreground">
                      Vision Transformer analyzes spatial relationships and field associations
                    </p>
                  </div>

                  {!extractedData && !processing && (
                    <Button onClick={handleScan} size="lg" className="w-full">
                      <Upload className="size-4 mr-2" />
                      Scan with Vision Transformer
                    </Button>
                  )}

                  {processing && (
                    <div className="p-8 text-center border rounded-lg">
                      <Loader2 className="size-12 animate-spin mx-auto mb-4 text-blue-600" />
                      <p className="text-sm font-medium mb-1">Processing document with ViT...</p>
                      <p className="text-xs text-muted-foreground">
                        Analyzing spatial relationships and extracting fields...
                      </p>
                      <div className="mt-4 space-y-1 text-xs text-muted-foreground">
                        <p>✓ Document layout analysis</p>
                        <p>✓ Text region detection</p>
                        <p>✓ Field association mapping</p>
                      </div>
                    </div>
                  )}

                  {extractedData && (
                    <div className="space-y-4">
                      <div className="p-4 bg-green-50 dark:bg-green-950/20 rounded-lg border border-green-200 dark:border-green-800">
                        <div className="flex items-center gap-2 mb-2">
                          <CheckCircle className="size-5 text-green-600 dark:text-green-400" />
                          <p className="font-semibold">Extraction Complete</p>
                        </div>
                        <p className="text-xs text-muted-foreground">
                          Review and edit fields below. Confidence scores indicate extraction reliability.
                        </p>
                      </div>

                      <div className="space-y-3 max-h-[300px] overflow-y-auto pr-2">
                        <div className="space-y-2">
                          <div className="flex items-center justify-between">
                            <Label htmlFor="vendor" className="text-sm">Vendor Name</Label>
                            <Badge variant={extractedData.confidence.vendor > 0.9 ? 'default' : 'outline'} className="text-xs">
                              {(extractedData.confidence.vendor * 100).toFixed(0)}% confident
                            </Badge>
                          </div>
                          <Input
                            id="vendor"
                            value={extractedData.vendor}
                            onChange={(e) => handleFieldChange('vendor', e.target.value)}
                          />
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                          <div className="space-y-2">
                            <div className="flex items-center justify-between">
                              <Label htmlFor="amount" className="text-sm">Amount</Label>
                              <Badge variant={extractedData.confidence.amount > 0.9 ? 'default' : 'outline'} className="text-xs">
                                {(extractedData.confidence.amount * 100).toFixed(0)}%
                              </Badge>
                            </div>
                            <Input
                              id="amount"
                              value={extractedData.amount}
                              onChange={(e) => handleFieldChange('amount', e.target.value)}
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="currency" className="text-sm">Currency</Label>
                            <Input
                              id="currency"
                              value={extractedData.currency}
                              onChange={(e) => handleFieldChange('currency', e.target.value)}
                            />
                          </div>
                        </div>

                        <div className="space-y-2">
                          <div className="flex items-center justify-between">
                            <Label htmlFor="date" className="text-sm">Date</Label>
                            <Badge variant={extractedData.confidence.date > 0.9 ? 'default' : 'outline'} className="text-xs">
                              {(extractedData.confidence.date * 100).toFixed(0)}%
                            </Badge>
                          </div>
                          <Input
                            id="date"
                            type="date"
                            value={extractedData.date}
                            onChange={(e) => handleFieldChange('date', e.target.value)}
                          />
                        </div>

                        <div className="space-y-2">
                          <div className="flex items-center justify-between">
                            <Label htmlFor="category" className="text-sm">Cost Element</Label>
                            <Badge variant={extractedData.confidence.category > 0.85 ? 'default' : 'outline'} className="text-xs">
                              {(extractedData.confidence.category * 100).toFixed(0)}%
                            </Badge>
                          </div>
                          <Input
                            id="category"
                            value={extractedData.category}
                            onChange={(e) => handleFieldChange('category', e.target.value)}
                          />
                        </div>

                        <div className="space-y-2">
                          <div className="flex items-center justify-between">
                            <Label htmlFor="department" className="text-sm">Department</Label>
                            <Badge variant={extractedData.confidence.department > 0.85 ? 'default' : 'outline'} className="text-xs">
                              {(extractedData.confidence.department * 100).toFixed(0)}%
                            </Badge>
                          </div>
                          <Input
                            id="department"
                            value={extractedData.department}
                            onChange={(e) => handleFieldChange('department', e.target.value)}
                          />
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="invoiceNumber" className="text-sm">Invoice Number</Label>
                          <Input
                            id="invoiceNumber"
                            value={extractedData.invoiceNumber}
                            onChange={(e) => handleFieldChange('invoiceNumber', e.target.value)}
                          />
                        </div>

                        {(extractedData.confidence.vendor < 0.85 ||
                          extractedData.confidence.amount < 0.85 ||
                          extractedData.confidence.category < 0.80) && (
                          <div className="p-3 bg-amber-50 dark:bg-amber-950/20 rounded border border-amber-200 dark:border-amber-800 flex items-start gap-2">
                            <AlertCircle className="size-4 text-amber-600 dark:text-amber-400 mt-0.5 flex-shrink-0" />
                            <p className="text-xs text-amber-900 dark:text-amber-100">
                              Some fields have lower confidence. Please review and correct if needed.
                            </p>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {extractedData && (
                <div className="flex gap-2">
                  <Button
                    onClick={() => {
                      setFile(null);
                      setExtractedData(null);
                      setFilePreview(null);
                    }}
                    variant="outline"
                    className="flex-1"
                  >
                    Scan Another
                  </Button>
                  <Button onClick={handleConfirm} className="flex-1">
                    Confirm & Add to System
                  </Button>
                </div>
              )}
            </div>
          )}

          <div className="bg-purple-50 dark:bg-purple-950/20 p-4 rounded-lg border border-purple-200 dark:border-purple-800">
            <h4 className="font-semibold mb-2 text-sm">Vision Transformer Advantage</h4>
            <p className="text-xs">
              Unlike standard OCR, ViT understands spatial relationships between fields. It correctly associates
              "AWS Egypt" with the vendor field and "EGP 57,555" with amount even when invoice layouts vary.
              Works with handwritten or non-standard formats common in international markets.
            </p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
