import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '../ui/dialog';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Input } from '../ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { FileText, Upload, Download, Eye, Lock, X } from 'lucide-react';
import { useState } from 'react';
import { toast } from 'sonner';

type Statement = {
  id: number;
  name: string;
  type: 'Balance Sheet' | 'Income Statement' | 'Cash Flow' | 'Other';
  date: string;
  uploadedBy: string;
  role: string;
  allowedRoles: string[];
};

const mockStatements: Statement[] = [
  {
    id: 1,
    name: 'Q1 2026 Balance Sheet',
    type: 'Balance Sheet',
    date: '2026-03-31',
    uploadedBy: 'Sarah Johnson',
    role: 'CFO',
    allowedRoles: ['CFO', 'Finance Manager', 'Cost Controller'],
  },
  {
    id: 2,
    name: 'Q1 2026 Income Statement',
    type: 'Income Statement',
    date: '2026-03-31',
    uploadedBy: 'Sarah Johnson',
    role: 'CFO',
    allowedRoles: ['CFO', 'Finance Manager', 'Cost Controller'],
  },
  {
    id: 3,
    name: 'Q1 2026 Cash Flow Statement',
    type: 'Cash Flow',
    date: '2026-03-31',
    uploadedBy: 'Michael Chen',
    role: 'Finance Manager',
    allowedRoles: ['CFO', 'Finance Manager', 'Cost Controller', 'Cost Analyst'],
  },
  {
    id: 4,
    name: 'April 2026 Expense Report',
    type: 'Other',
    date: '2026-04-30',
    uploadedBy: 'Emily Rodriguez',
    role: 'Cost Controller',
    allowedRoles: ['CFO', 'Finance Manager', 'Cost Controller', 'Cost Analyst'],
  },
];

interface FinancialStatementsModalProps {
  open: boolean;
  onClose: () => void;
  userRole: string;
}

export function FinancialStatementsModal({ open, onClose, userRole }: FinancialStatementsModalProps) {
  const [statements, setStatements] = useState<Statement[]>(mockStatements);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [uploadType, setUploadType] = useState<'manual' | 'vit'>('manual');
  const [previewStatement, setPreviewStatement] = useState<Statement | null>(null);

  const accessibleStatements = statements.filter(s => s.allowedRoles.includes(userRole));

  const generateStatementContent = (statement: Statement): string => {
    const date = new Date(statement.date);
    const formattedDate = date.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });

    switch (statement.type) {
      case 'Balance Sheet':
        return `
BALANCE SHEET
As of ${formattedDate}

ASSETS
Current Assets:
  Cash and Cash Equivalents          $4,950,000
  Accounts Receivable                $2,120,000
  Inventory                          $1,580,000
  Prepaid Expenses                     $350,000
  ───────────────────────────────────────────
  Total Current Assets               $9,000,000

Non-Current Assets:
  Property, Plant & Equipment        $5,200,000
  Intangible Assets                  $1,800,000
  Long-term Investments              $2,500,000
  ───────────────────────────────────────────
  Total Non-Current Assets           $9,500,000

TOTAL ASSETS                        $18,500,000

LIABILITIES AND EQUITY
Current Liabilities:
  Accounts Payable                   $1,850,000
  Short-term Debt                    $1,200,000
  Accrued Expenses                     $950,000
  ───────────────────────────────────────────
  Total Current Liabilities          $4,000,000

Non-Current Liabilities:
  Long-term Debt                     $3,500,000
  Deferred Tax Liabilities             $800,000
  ───────────────────────────────────────────
  Total Non-Current Liabilities      $4,300,000

Shareholders' Equity:
  Common Stock                       $5,000,000
  Retained Earnings                  $5,200,000
  ───────────────────────────────────────────
  Total Equity                      $10,200,000

TOTAL LIABILITIES & EQUITY          $18,500,000

Current Ratio: ${(9000000 / 4000000).toFixed(2)}
Debt-to-Equity Ratio: ${((3500000 + 1200000) / 10200000).toFixed(2)}

Prepared by: ${statement.uploadedBy}
Date Prepared: ${formattedDate}
        `;
      case 'Income Statement':
        return `
INCOME STATEMENT
For the Period Ending ${formattedDate}

REVENUE
  Product Sales                      $8,450,000
  Service Revenue                    $3,120,000
  ───────────────────────────────────────────
  Total Revenue                     $11,570,000

COST OF REVENUE
  Cost of Goods Sold                 $4,850,000
  ───────────────────────────────────────────
  Gross Profit                       $6,720,000

OPERATING EXPENSES
  Wages & Salaries                   $2,890,000
  Rent & Facilities                    $375,000
  Software Licenses                    $255,000
  Contractor Fees                      $620,000
  Marketing & Advertising              $480,000
  Utilities                            $135,000
  Depreciation                         $220,000
  Other Operating Expenses             $345,000
  ───────────────────────────────────────────
  Total Operating Expenses           $5,320,000

OPERATING INCOME                     $1,400,000

OTHER INCOME (EXPENSE)
  Interest Income                       $45,000
  Interest Expense                    ($125,000)
  ───────────────────────────────────────────
  Net Other Income (Expense)           ($80,000)

INCOME BEFORE TAX                    $1,320,000

  Income Tax Expense                   $370,000
  ───────────────────────────────────────────
NET INCOME                           $  950,000

Gross Profit Margin: ${(6720000 / 11570000 * 100).toFixed(1)}%
Net Profit Margin: ${(950000 / 11570000 * 100).toFixed(1)}%

Prepared by: ${statement.uploadedBy}
Date Prepared: ${formattedDate}
        `;
      case 'Cash Flow':
        return `
CASH FLOW STATEMENT
For the Period Ending ${formattedDate}

OPERATING ACTIVITIES
  Net Income                           $950,000
  Adjustments:
    Depreciation & Amortization        $220,000
    Changes in Working Capital:
      Accounts Receivable             ($180,000)
      Inventory                        ($95,000)
      Accounts Payable                  $125,000
      Accrued Expenses                   $55,000
  ───────────────────────────────────────────
  Net Cash from Operating Activities $1,075,000

INVESTING ACTIVITIES
  Purchase of Equipment               ($420,000)
  Sale of Investments                  $150,000
  ───────────────────────────────────────────
  Net Cash from Investing Activities  ($270,000)

FINANCING ACTIVITIES
  Proceeds from Debt                   $500,000
  Repayment of Debt                   ($350,000)
  Dividends Paid                      ($200,000)
  ───────────────────────────────────────────
  Net Cash from Financing Activities   ($50,000)

NET INCREASE IN CASH                  $755,000

Cash at Beginning of Period         $4,195,000
Cash at End of Period               $4,950,000

Operating Cash Flow Ratio: ${(1075000 / 4000000).toFixed(2)}

Prepared by: ${statement.uploadedBy}
Date Prepared: ${formattedDate}
        `;
      default:
        return `
FINANCIAL DOCUMENT
${statement.name}
Date: ${formattedDate}

This is a financial document containing important company information.
Access is restricted to authorized personnel.

Document Type: ${statement.type}
Uploaded By: ${statement.uploadedBy} (${statement.role})
Authorized Roles: ${statement.allowedRoles.join(', ')}

For internal use only.
        `;
    }
  };

  const handleFileUpload = (file: File) => {
    setSelectedFile(file);
  };

  const handleViTScan = () => {
    if (!selectedFile) {
      toast.error('Please select a file first');
      return;
    }

    // Simulate ViT processing
    toast.success('Vision Transformer processing... Extracting data from document');

    setTimeout(() => {
      const newStatement: Statement = {
        id: statements.length + 1,
        name: selectedFile.name,
        type: 'Other',
        date: new Date().toISOString().split('T')[0],
        uploadedBy: 'Current User',
        role: userRole,
        allowedRoles: ['CFO', 'Finance Manager', 'Cost Controller', 'Cost Analyst'],
      };

      setStatements([newStatement, ...statements]);
      toast.success('Document processed and uploaded successfully!');
      setSelectedFile(null);
    }, 2000);
  };

  const handleManualUpload = () => {
    if (!selectedFile) {
      toast.error('Please select a file first');
      return;
    }

    const newStatement: Statement = {
      id: statements.length + 1,
      name: selectedFile.name,
      type: 'Other',
      date: new Date().toISOString().split('T')[0],
      uploadedBy: 'Current User',
      role: userRole,
      allowedRoles: ['CFO', 'Finance Manager', 'Cost Controller', 'Cost Analyst'],
    };

    setStatements([newStatement, ...statements]);
    toast.success('Document uploaded successfully!');
    setSelectedFile(null);
  };

  const handlePreview = (statement: Statement) => {
    setPreviewStatement(statement);
  };

  const handleDownload = (statement: Statement) => {
    const content = generateStatementContent(statement);
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${statement.name.replace(/\s+/g, '_')}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast.success(`Downloaded ${statement.name}`);
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileText className="size-5" />
            Financial Statements Repository
          </DialogTitle>
          <DialogDescription>
            Access and manage financial statements with role-based permissions
          </DialogDescription>
        </DialogHeader>

        <Tabs defaultValue="view" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="view">View Statements</TabsTrigger>
            <TabsTrigger value="upload">Upload New</TabsTrigger>
          </TabsList>

          <TabsContent value="view" className="space-y-4">
            <div className="flex items-center justify-between">
              <p className="text-sm text-muted-foreground">
                Showing {accessibleStatements.length} statements accessible to {userRole}
              </p>
              <Badge variant="outline">{userRole}</Badge>
            </div>

            <div className="space-y-3">
              {accessibleStatements.map((statement) => (
                <Card key={statement.id}>
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <FileText className="size-4 text-blue-600" />
                          <h4 className="font-semibold">{statement.name}</h4>
                          <Badge variant="outline">{statement.type}</Badge>
                        </div>
                        <div className="grid grid-cols-3 gap-4 text-sm text-muted-foreground">
                          <div>
                            <p className="text-xs">Date</p>
                            <p className="font-mono">{statement.date}</p>
                          </div>
                          <div>
                            <p className="text-xs">Uploaded By</p>
                            <p>{statement.uploadedBy}</p>
                          </div>
                          <div>
                            <p className="text-xs">Access Level</p>
                            <p className="text-xs">{statement.allowedRoles.join(', ')}</p>
                          </div>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handlePreview(statement)}
                        >
                          <Eye className="size-4 mr-1" />
                          View
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleDownload(statement)}
                        >
                          <Download className="size-4 mr-1" />
                          Download
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}

              {accessibleStatements.length === 0 && (
                <div className="text-center p-8 text-muted-foreground">
                  <Lock className="size-12 mx-auto mb-2 opacity-50" />
                  <p>No statements accessible with your current role</p>
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="upload" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Upload Method</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <Button
                    variant={uploadType === 'manual' ? 'default' : 'outline'}
                    onClick={() => setUploadType('manual')}
                    className="h-20"
                  >
                    <div className="text-center">
                      <Upload className="size-6 mx-auto mb-1" />
                      <p className="text-sm">Manual Upload</p>
                    </div>
                  </Button>
                  <Button
                    variant={uploadType === 'vit' ? 'default' : 'outline'}
                    onClick={() => setUploadType('vit')}
                    className="h-20"
                  >
                    <div className="text-center">
                      <FileText className="size-6 mx-auto mb-1" />
                      <p className="text-sm">ViT Auto-Extract</p>
                    </div>
                  </Button>
                </div>

                {uploadType === 'vit' && (
                  <div className="bg-blue-50 dark:bg-blue-950/20 p-4 rounded-lg border border-blue-200 dark:border-blue-800">
                    <h4 className="font-semibold mb-2 text-sm">Vision Transformer (ViT)</h4>
                    <p className="text-sm">
                      AI-powered OCR with spatial understanding. Automatically extracts structured data
                      from scanned financial statements, including tables, numbers, and labels.
                    </p>
                  </div>
                )}

                <div className="border-2 border-dashed rounded-lg p-8 text-center">
                  <Input
                    type="file"
                    accept=".pdf,.png,.jpg,.jpeg"
                    onChange={(e) => e.target.files && handleFileUpload(e.target.files[0])}
                    className="max-w-xs mx-auto"
                  />
                  {selectedFile && (
                    <div className="mt-4 p-3 bg-green-50 dark:bg-green-950/20 rounded border border-green-200 dark:border-green-800">
                      <p className="text-sm font-medium">Selected: {selectedFile.name}</p>
                      <p className="text-xs text-muted-foreground">
                        {(selectedFile.size / 1024).toFixed(1)} KB
                      </p>
                    </div>
                  )}
                </div>

                <Button
                  className="w-full"
                  size="lg"
                  onClick={uploadType === 'vit' ? handleViTScan : handleManualUpload}
                  disabled={!selectedFile}
                >
                  {uploadType === 'vit' ? 'Process with ViT & Upload' : 'Upload Document'}
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Preview Modal */}
        {previewStatement && (
          <Dialog open={!!previewStatement} onOpenChange={() => setPreviewStatement(null)}>
            <DialogContent className="max-w-4xl max-h-[90vh]">
              <DialogHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <DialogTitle className="flex items-center gap-2">
                      <FileText className="size-5" />
                      {previewStatement.name}
                    </DialogTitle>
                    <DialogDescription>
                      {previewStatement.type} • {new Date(previewStatement.date).toLocaleDateString()}
                    </DialogDescription>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setPreviewStatement(null)}
                  >
                    <X className="size-4" />
                  </Button>
                </div>
              </DialogHeader>

              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Badge variant="outline">{previewStatement.type}</Badge>
                    <span className="text-sm text-muted-foreground">
                      Uploaded by {previewStatement.uploadedBy}
                    </span>
                  </div>
                  <Button
                    size="sm"
                    onClick={() => handleDownload(previewStatement)}
                  >
                    <Download className="size-4 mr-1" />
                    Download
                  </Button>
                </div>

                <div className="border rounded-lg bg-gray-50 dark:bg-gray-900 p-6 max-h-[600px] overflow-y-auto">
                  <pre className="text-xs font-mono whitespace-pre-wrap">
                    {generateStatementContent(previewStatement)}
                  </pre>
                </div>

                <div className="bg-blue-50 dark:bg-blue-950/20 p-3 rounded-lg border border-blue-200 dark:border-blue-800">
                  <p className="text-xs text-muted-foreground">
                    <strong>Note:</strong> This is a simplified text preview. The actual document may contain additional formatting, charts, and detailed breakdowns.
                  </p>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        )}
      </DialogContent>
    </Dialog>
  );
}
