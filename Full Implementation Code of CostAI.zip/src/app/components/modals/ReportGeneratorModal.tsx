import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '../ui/dialog';
import { Button } from '../ui/button';
import { Label } from '../ui/label';
import { Badge } from '../ui/badge';
import { Download, FileText, Loader2, CheckCircle } from 'lucide-react';
import { toast } from 'sonner';

interface ReportGeneratorModalProps {
  open: boolean;
  onClose: () => void;
}

export function ReportGeneratorModal({ open, onClose }: ReportGeneratorModalProps) {
  const [reportType, setReportType] = useState('Executive Summary (All)');
  const [period, setPeriod] = useState('May 2026');
  const [currency, setCurrency] = useState('Multi-currency (split)');
  const [format, setFormat] = useState('PDF');
  const [generating, setGenerating] = useState(false);
  const [generated, setGenerated] = useState(false);

  const [sections, setSections] = useState({
    executiveSummary: true,
    departmentBreakdown: true,
    costElementAnalysis: true,
    budgetVariance: true,
    onTrackStatus: true,
    anomalyDetection: true,
    multiCurrency: true,
    forecastProjections: true,
    recommendations: true,
  });

  const handleGenerate = async () => {
    setGenerating(true);
    setGenerated(false);

    // Simulate report generation
    await new Promise(resolve => setTimeout(resolve, 2500));

    setGenerating(false);
    setGenerated(true);
  };

  const handleDownload = () => {
    // Generate report content
    const enabledSections = Object.entries(sections)
      .filter(([_, enabled]) => enabled)
      .map(([key, _]) => key);

    const reportContent = `
COMPREHENSIVE COST ANALYSIS REPORT
Generated: ${new Date().toLocaleString()}

Report Type: ${reportType}
Period: ${period}
Currency Display: ${currency}
Format: ${format}

═══════════════════════════════════════════════════════════════

${sections.executiveSummary ? `
EXECUTIVE SUMMARY
──────────────────────────────────────────────────────────────
Total Budget: $1,590,000
Total Actual: $1,593,000
Overall Variance: +$3,000 (+0.2%)
Budget Utilization: 100.2%

Key Highlights:
• 3 of 6 departments on track
• Anomalies detected: 3 transactions
• Cost elements analyzed: 10
• Multi-currency transactions processed
` : ''}

${sections.departmentBreakdown ? `
DEPARTMENT-LEVEL BREAKDOWN
──────────────────────────────────────────────────────────────
Engineering:    Budget $450,000 | Actual $465,000 | Variance +$15,000 (+3.3%)
Sales:          Budget $320,000 | Actual $298,000 | Variance -$22,000 (-6.9%)
Marketing:      Budget $280,000 | Actual $305,000 | Variance +$25,000 (+8.9%)
Operations:     Budget $210,000 | Actual $195,000 | Variance -$15,000 (-7.1%)
HR:             Budget $180,000 | Actual $178,000 | Variance -$2,000 (-1.1%)
Finance:        Budget $150,000 | Actual $152,000 | Variance +$2,000 (+1.3%)
` : ''}

${sections.costElementAnalysis ? `
COST ELEMENT ANALYSIS
──────────────────────────────────────────────────────────────
Wages & Salaries:        $890,000 (Budget: $850,000) +$40,000
Contractor Fees:         $120,000 (Budget: $100,000) +$20,000
Raw Materials:           $210,000 (Budget: $200,000) +$10,000
Electricity & Utilities: $45,000 (Budget: $40,000) +$5,000
Software Licenses:       $85,000 (Budget: $90,000) -$5,000
Rent & Facilities:       $125,000 (Budget: $130,000) -$5,000
Travel & Entertainment:  $38,000 (Budget: $50,000) -$12,000
` : ''}

${sections.budgetVariance ? `
BUDGET VS ACTUAL VARIANCE
──────────────────────────────────────────────────────────────
Departments Over Budget: 3 (Engineering, Marketing, Finance)
Departments Under Budget: 3 (Sales, Operations, HR)
Largest Positive Variance: Marketing (+$25,000)
Largest Negative Variance: Sales (-$22,000)
` : ''}

${sections.onTrackStatus ? `
ON-TRACK / OFF-TRACK STATUS
──────────────────────────────────────────────────────────────
ON TRACK (variance < 5%):
✓ Sales (-6.9% but improving)
✓ Operations (-7.1% but stable)
✓ HR (-1.1%)
✓ Finance (+1.3%)

OFF TRACK (variance > 5%):
✗ Engineering (+3.3%)
✗ Marketing (+8.9%)
` : ''}

${sections.anomalyDetection ? `
ANOMALY DETECTION RESULTS
──────────────────────────────────────────────────────────────
Algorithms Used: Autoencoder (Neural Network), Isolation Forest (Tree-based)
Transactions Analyzed: ${period === 'May 2026' ? '247' : '1,234'}
Anomalies Detected: 3

Flagged Transactions:
1. AWS Egypt - EGP 57,555 (3x higher than usual)
   Detection Method: Autoencoder + Isolation Forest
   Reason: Amount significantly exceeds historical average

2. Supplier XYZ - $4,500 (Potential duplicate)
   Detection Method: Isolation Forest
   Reason: Similar amount, same vendor, same date range

3. Marketing Agency Pro - $35,000
   Detection Method: Autoencoder
   Reason: Unusual pattern in contractor fees
` : ''}

${sections.multiCurrency ? `
MULTI-CURRENCY BREAKDOWN
──────────────────────────────────────────────────────────────
USD Transactions: $1,245,000 (78.2%)
EUR Transactions: €185,000 (~$198,000 @ 1.07) (12.4%)
EGP Transactions: EGP 2,850,000 (~$150,000 @ 19.0) (9.4%)

Exchange Rates Used:
• USD/EUR: 1.07
• USD/EGP: 19.0
` : ''}

${sections.forecastProjections ? `
FORECAST PROJECTIONS
──────────────────────────────────────────────────────────────
Next Month (June 2026):
• Projected Costs: $1,625,000
• Forecast Accuracy: 94.2% (based on last 3 months)
• Trend: Upward (+2.0% MoM growth)

Q3 2026 Projections:
• July: $1,650,000
• August: $1,680,000
• September: $1,710,000
` : ''}

${sections.recommendations ? `
AI-GENERATED RECOMMENDATIONS
──────────────────────────────────────────────────────────────
HIGH PRIORITY:
1. Review Marketing contractor fees (+20% over budget)
   Potential Savings: $20,000/month

2. Investigate Engineering payroll variance
   Action: Analyze new hires vs. budget plan

3. Renegotiate office lease contract
   Potential Savings: $85,000/year

MEDIUM PRIORITY:
4. Optimize cloud infrastructure usage
   Potential Savings: $40,000/year

5. Review duplicate transaction (Supplier XYZ)
   Action: Verify with Accounts Payable

LOW PRIORITY:
6. Continue monitoring HR department (on track)
7. Evaluate Sales department efficiency (under budget)
` : ''}

═══════════════════════════════════════════════════════════════
Report generated by CostAI Management System
Powered by AI: Autoencoder, Isolation Forest, Gradient Boosting
End of Report
    `.trim();

    // Create and download the report
    const blob = new Blob([reportContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;

    const fileExtension = format.toLowerCase();
    const fileName = `CostAI_Report_${reportType.replace(/\s+/g, '_')}_${period.replace(/\s+/g, '_')}.${fileExtension === 'powerpoint' ? 'pptx' : fileExtension === 'excel' ? 'xlsx' : 'pdf'}`;
    a.download = fileName;

    a.click();
    URL.revokeObjectURL(url);

    toast.success(`Report downloaded successfully as ${fileName}`);

    setTimeout(() => {
      onClose();
    }, 500);
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileText className="size-5" />
            Generate Comprehensive Report
          </DialogTitle>
          <DialogDescription>
            Multi-currency handling, cost element breakdowns, and on-track/off-track status
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Report Type</Label>
              <select
                className="w-full p-2 border rounded-md"
                value={reportType}
                onChange={(e) => setReportType(e.target.value)}
              >
                <option>Monthly Cost Analysis</option>
                <option>Department Performance</option>
                <option>Cost Element Breakdown</option>
                <option>Anomaly Investigation Summary</option>
                <option>Executive Summary (All)</option>
              </select>
            </div>
            <div className="space-y-2">
              <Label>Period</Label>
              <select
                className="w-full p-2 border rounded-md"
                value={period}
                onChange={(e) => setPeriod(e.target.value)}
              >
                <option>May 2026</option>
                <option>April 2026</option>
                <option>Q2 2026</option>
                <option>YTD 2026</option>
              </select>
            </div>
            <div className="space-y-2">
              <Label>Currency Display</Label>
              <select
                className="w-full p-2 border rounded-md"
                value={currency}
                onChange={(e) => setCurrency(e.target.value)}
              >
                <option>Multi-currency (split)</option>
                <option>USD only</option>
                <option>EUR only</option>
                <option>EGP only</option>
              </select>
            </div>
            <div className="space-y-2">
              <Label>Format</Label>
              <select
                className="w-full p-2 border rounded-md"
                value={format}
                onChange={(e) => setFormat(e.target.value)}
              >
                <option>PDF</option>
                <option>Excel</option>
                <option>PowerPoint</option>
              </select>
            </div>
          </div>

          <div className="space-y-3">
            <h4 className="font-semibold">Report Sections</h4>
            <div className="grid grid-cols-2 gap-2">
              {Object.entries({
                executiveSummary: 'Executive Summary',
                departmentBreakdown: 'Department-level breakdown',
                costElementAnalysis: 'Cost element analysis',
                budgetVariance: 'Budget vs Actual variance',
                onTrackStatus: 'On-track/Off-track status',
                anomalyDetection: 'Anomaly detection results',
                multiCurrency: 'Multi-currency breakdown',
                forecastProjections: 'Forecast projections',
                recommendations: 'AI Recommendations',
              }).map(([key, label]) => (
                <label
                  key={key}
                  className="flex items-center gap-2 p-2 border rounded cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-800"
                >
                  <input
                    type="checkbox"
                    checked={sections[key as keyof typeof sections]}
                    onChange={(e) => setSections({ ...sections, [key]: e.target.checked })}
                    className="rounded"
                  />
                  <span className="text-sm">{label}</span>
                </label>
              ))}
            </div>
          </div>

          {!generated && (
            <Button
              onClick={handleGenerate}
              disabled={generating}
              className="w-full"
            >
              {generating ? (
                <>
                  <Loader2 className="size-4 mr-2 animate-spin" />
                  Generating Report...
                </>
              ) : (
                <>
                  <FileText className="size-4 mr-2" />
                  Generate Report
                </>
              )}
            </Button>
          )}

          {generated && (
            <div className="space-y-4">
              <div className="p-4 bg-green-50 dark:bg-green-950/20 rounded-lg border border-green-200 dark:border-green-800">
                <div className="flex items-center gap-2 mb-3">
                  <CheckCircle className="size-5 text-green-600 dark:text-green-400" />
                  <p className="font-semibold">Report Generated Successfully</p>
                </div>
                <div className="text-sm space-y-1 text-muted-foreground">
                  <p>• Format: {format}</p>
                  <p>• Period: {period}</p>
                  <p>• Sections: {Object.values(sections).filter(Boolean).length} included</p>
                  <p>• Size: 2.4 MB</p>
                </div>
              </div>

              <Button onClick={handleDownload} className="w-full">
                <Download className="size-4 mr-2" />
                Download Report
              </Button>
            </div>
          )}

          <div className="bg-blue-50 dark:bg-blue-950/20 p-4 rounded-lg border border-blue-200 dark:border-blue-800">
            <h4 className="font-semibold mb-2 text-sm">Report Features</h4>
            <ul className="text-sm space-y-1">
              <li>• Cost element level breakdowns (not just department totals)</li>
              <li>• Multi-currency handling with independent exchange rates</li>
              <li>• On-track/off-track status per department and element</li>
              <li>• AI-generated insights and recommendations</li>
              <li>• Anomaly detection findings with explainability</li>
            </ul>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
