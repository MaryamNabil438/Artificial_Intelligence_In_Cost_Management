import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '../ui/dialog';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Input } from '../ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Search, Filter, Eye, Download, AlertCircle, FileText, Settings } from 'lucide-react';

type DocumentType = 'Invoice' | 'Receipt' | 'Financial Statement' | 'Contract' | 'Payroll' | 'All';
type UserRole = 'Finance Manager' | 'Procurement' | 'Operations' | 'Admin';

interface Document {
  id: number;
  type: DocumentType;
  uploadDate: string;
  status: 'verified' | 'pending-review' | 'flagged';
  confidence: number;
  [key: string]: any;
}

interface DocumentRepositoryModalProps {
  open: boolean;
  onClose: () => void;
  userRole: UserRole;
  documents: Document[];
  onViewDocument: (doc: Document) => void;
}

export function DocumentRepositoryModal({
  open,
  onClose,
  userRole,
  documents,
  onViewDocument
}: DocumentRepositoryModalProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<DocumentType>('All');

  // Role-based access control
  const getAccessibleTypes = (role: UserRole): DocumentType[] => {
    switch (role) {
      case 'Finance Manager':
        return ['Financial Statement', 'Payroll', 'Invoice'];
      case 'Procurement':
        return ['Invoice', 'Contract'];
      case 'Operations':
        return ['Receipt', 'Invoice'];
      case 'Admin':
        return ['Invoice', 'Receipt', 'Financial Statement', 'Contract', 'Payroll'];
      default:
        return [];
    }
  };

  const accessibleTypes = getAccessibleTypes(userRole);

  // Filter documents
  const filteredDocs = documents.filter(doc => {
    const typeMatch = filterType === 'All' || doc.type === filterType;
    const accessMatch = accessibleTypes.includes(doc.type as DocumentType);
    const searchMatch = searchQuery === '' || Object.values(doc).some(val =>
      String(val).toLowerCase().includes(searchQuery.toLowerCase())
    );
    return typeMatch && accessMatch && searchMatch;
  });

  // Stats
  const stats = {
    total: filteredDocs.length,
    verified: filteredDocs.filter(d => d.status === 'verified').length,
    pendingReview: filteredDocs.filter(d => d.status === 'pending-review').length,
    flagged: filteredDocs.filter(d => d.status === 'flagged').length,
  };

  const invoiceDocs = filteredDocs.filter(d => d.type === 'Invoice');
  const receiptDocs = filteredDocs.filter(d => d.type === 'Receipt');
  const statementDocs = filteredDocs.filter(d => d.type === 'Financial Statement');
  const contractDocs = filteredDocs.filter(d => d.type === 'Contract');
  const payrollDocs = filteredDocs.filter(d => d.type === 'Payroll');

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'verified':
        return <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">Verified</Badge>;
      case 'pending-review':
        return <Badge className="bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200">Pending Review</Badge>;
      case 'flagged':
        return <Badge className="bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200">Flagged</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-[95vw] max-h-[95vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <div>
              <DialogTitle>Document Repository</DialogTitle>
              <DialogDescription>
                Structured database - Role: {userRole} • {stats.total} documents accessible
              </DialogDescription>
            </div>
            <Badge variant="outline" className="text-sm">
              <Settings className="size-3 mr-1" />
              {userRole}
            </Badge>
          </div>
        </DialogHeader>

        {/* Stats Row */}
        <div className="grid grid-cols-4 gap-4">
          <div className="border rounded-lg p-3">
            <div className="text-2xl font-bold">{stats.total}</div>
            <div className="text-sm text-muted-foreground">Total Documents</div>
          </div>
          <div className="border rounded-lg p-3">
            <div className="text-2xl font-bold text-green-600">{stats.verified}</div>
            <div className="text-sm text-muted-foreground">Verified</div>
          </div>
          <div className="border rounded-lg p-3">
            <div className="text-2xl font-bold text-yellow-600">{stats.pendingReview}</div>
            <div className="text-sm text-muted-foreground">Pending Review</div>
          </div>
          <div className="border rounded-lg p-3">
            <div className="text-2xl font-bold text-red-600">{stats.flagged}</div>
            <div className="text-sm text-muted-foreground">Flagged</div>
          </div>
        </div>

        {/* Search & Filter */}
        <div className="flex gap-3">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
            <Input
              placeholder="Search extracted field values (vendor, amount, date, etc.)"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          <div className="flex gap-2">
            {['All', ...accessibleTypes].map(type => (
              <Button
                key={type}
                variant={filterType === type ? 'default' : 'outline'}
                size="sm"
                onClick={() => setFilterType(type as DocumentType)}
              >
                {type}
              </Button>
            ))}
          </div>
        </div>

        {/* Tables by Type */}
        <div className="flex-1 overflow-y-auto space-y-6">
          {accessibleTypes.includes('Invoice') && invoiceDocs.length > 0 && (
            <div>
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-semibold">Invoices ({invoiceDocs.length})</h3>
              </div>
              <div className="border rounded-lg overflow-hidden">
                <table className="w-full text-sm">
                  <thead className="bg-gray-50 dark:bg-gray-900">
                    <tr>
                      <th className="text-left p-3 font-medium">Invoice #</th>
                      <th className="text-left p-3 font-medium">Vendor</th>
                      <th className="text-left p-3 font-medium">Date</th>
                      <th className="text-right p-3 font-medium">Amount</th>
                      <th className="text-left p-3 font-medium">Currency</th>
                      <th className="text-left p-3 font-medium">Department</th>
                      <th className="text-left p-3 font-medium">Status</th>
                      <th className="text-left p-3 font-medium">Confidence</th>
                      <th className="text-right p-3 font-medium">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {invoiceDocs.map(doc => (
                      <tr key={doc.id} className="border-t hover:bg-gray-50 dark:hover:bg-gray-900">
                        <td className="p-3 font-mono text-xs">{doc.invoiceNumber}</td>
                        <td className="p-3">{doc.vendor}</td>
                        <td className="p-3">{doc.date}</td>
                        <td className="p-3 text-right font-mono">{doc.amount}</td>
                        <td className="p-3">{doc.currency}</td>
                        <td className="p-3">{doc.department}</td>
                        <td className="p-3">{getStatusBadge(doc.status)}</td>
                        <td className="p-3">
                          <div className="text-xs font-medium">{(doc.confidence * 100).toFixed(0)}%</div>
                        </td>
                        <td className="p-3 text-right">
                          <Button size="sm" variant="ghost" onClick={() => onViewDocument(doc)}>
                            <Eye className="size-4" />
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {accessibleTypes.includes('Receipt') && receiptDocs.length > 0 && (
            <div>
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-semibold">Receipts ({receiptDocs.length})</h3>
              </div>
              <div className="border rounded-lg overflow-hidden">
                <table className="w-full text-sm">
                  <thead className="bg-gray-50 dark:bg-gray-900">
                    <tr>
                      <th className="text-left p-3 font-medium">Receipt #</th>
                      <th className="text-left p-3 font-medium">Vendor</th>
                      <th className="text-left p-3 font-medium">Date</th>
                      <th className="text-right p-3 font-medium">Amount</th>
                      <th className="text-left p-3 font-medium">Payment Method</th>
                      <th className="text-left p-3 font-medium">Department</th>
                      <th className="text-left p-3 font-medium">Status</th>
                      <th className="text-right p-3 font-medium">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {receiptDocs.map(doc => (
                      <tr key={doc.id} className="border-t hover:bg-gray-50 dark:hover:bg-gray-900">
                        <td className="p-3 font-mono text-xs">{doc.receiptNumber}</td>
                        <td className="p-3">{doc.vendor}</td>
                        <td className="p-3">{doc.date}</td>
                        <td className="p-3 text-right font-mono">{doc.amount}</td>
                        <td className="p-3">{doc.paymentMethod}</td>
                        <td className="p-3">{doc.department}</td>
                        <td className="p-3">{getStatusBadge(doc.status)}</td>
                        <td className="p-3 text-right">
                          <Button size="sm" variant="ghost" onClick={() => onViewDocument(doc)}>
                            <Eye className="size-4" />
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {accessibleTypes.includes('Financial Statement') && statementDocs.length > 0 && (
            <div>
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-semibold">Financial Statements ({statementDocs.length})</h3>
              </div>
              <div className="border rounded-lg overflow-hidden">
                <table className="w-full text-sm">
                  <thead className="bg-gray-50 dark:bg-gray-900">
                    <tr>
                      <th className="text-left p-3 font-medium">Type</th>
                      <th className="text-left p-3 font-medium">Period Ending</th>
                      <th className="text-right p-3 font-medium">Total Assets</th>
                      <th className="text-right p-3 font-medium">Total Liabilities</th>
                      <th className="text-right p-3 font-medium">Equity</th>
                      <th className="text-left p-3 font-medium">Prepared By</th>
                      <th className="text-left p-3 font-medium">Status</th>
                      <th className="text-right p-3 font-medium">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {statementDocs.map(doc => (
                      <tr key={doc.id} className="border-t hover:bg-gray-50 dark:hover:bg-gray-900">
                        <td className="p-3">{doc.statementType}</td>
                        <td className="p-3">{doc.periodEnding}</td>
                        <td className="p-3 text-right font-mono">{doc.totalAssets}</td>
                        <td className="p-3 text-right font-mono">{doc.totalLiabilities}</td>
                        <td className="p-3 text-right font-mono">{doc.totalEquity}</td>
                        <td className="p-3">{doc.preparedBy}</td>
                        <td className="p-3">{getStatusBadge(doc.status)}</td>
                        <td className="p-3 text-right">
                          <Button size="sm" variant="ghost" onClick={() => onViewDocument(doc)}>
                            <Eye className="size-4" />
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {accessibleTypes.includes('Contract') && contractDocs.length > 0 && (
            <div>
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-semibold">Contracts ({contractDocs.length})</h3>
              </div>
              <div className="border rounded-lg overflow-hidden">
                <table className="w-full text-sm">
                  <thead className="bg-gray-50 dark:bg-gray-900">
                    <tr>
                      <th className="text-left p-3 font-medium">Contract #</th>
                      <th className="text-left p-3 font-medium">Title</th>
                      <th className="text-left p-3 font-medium">Vendor</th>
                      <th className="text-left p-3 font-medium">Start Date</th>
                      <th className="text-left p-3 font-medium">End Date</th>
                      <th className="text-right p-3 font-medium">Value</th>
                      <th className="text-left p-3 font-medium">Status</th>
                      <th className="text-right p-3 font-medium">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {contractDocs.map(doc => (
                      <tr key={doc.id} className="border-t hover:bg-gray-50 dark:hover:bg-gray-900">
                        <td className="p-3 font-mono text-xs">{doc.contractNumber}</td>
                        <td className="p-3">{doc.title}</td>
                        <td className="p-3">{doc.vendor}</td>
                        <td className="p-3">{doc.startDate}</td>
                        <td className="p-3">{doc.endDate}</td>
                        <td className="p-3 text-right font-mono">{doc.contractValue}</td>
                        <td className="p-3">{getStatusBadge(doc.status)}</td>
                        <td className="p-3 text-right">
                          <Button size="sm" variant="ghost" onClick={() => onViewDocument(doc)}>
                            <Eye className="size-4" />
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {accessibleTypes.includes('Payroll') && payrollDocs.length > 0 && (
            <div>
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-semibold">Payroll ({payrollDocs.length})</h3>
              </div>
              <div className="border rounded-lg overflow-hidden">
                <table className="w-full text-sm">
                  <thead className="bg-gray-50 dark:bg-gray-900">
                    <tr>
                      <th className="text-left p-3 font-medium">Pay Period</th>
                      <th className="text-left p-3 font-medium">Pay Date</th>
                      <th className="text-right p-3 font-medium">Gross Pay</th>
                      <th className="text-right p-3 font-medium">Deductions</th>
                      <th className="text-right p-3 font-medium">Net Pay</th>
                      <th className="text-right p-3 font-medium">Employees</th>
                      <th className="text-left p-3 font-medium">Status</th>
                      <th className="text-right p-3 font-medium">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {payrollDocs.map(doc => (
                      <tr key={doc.id} className="border-t hover:bg-gray-50 dark:hover:bg-gray-900">
                        <td className="p-3">{doc.payPeriod}</td>
                        <td className="p-3">{doc.payDate}</td>
                        <td className="p-3 text-right font-mono">{doc.grossPay}</td>
                        <td className="p-3 text-right font-mono">{doc.deductions}</td>
                        <td className="p-3 text-right font-mono">{doc.netPay}</td>
                        <td className="p-3 text-right font-mono">{doc.employeeCount}</td>
                        <td className="p-3">{getStatusBadge(doc.status)}</td>
                        <td className="p-3 text-right">
                          <Button size="sm" variant="ghost" onClick={() => onViewDocument(doc)}>
                            <Eye className="size-4" />
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {filteredDocs.length === 0 && (
            <div className="text-center py-12 text-muted-foreground">
              <FileText className="size-12 mx-auto mb-3 opacity-50" />
              <p>No documents found matching your search.</p>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
