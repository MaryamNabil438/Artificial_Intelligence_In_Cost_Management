import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '../ui/dialog';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Badge } from '../ui/badge';
import { TrendingUp } from 'lucide-react';
import { costElements } from '../../data/mockData';

interface BudgetRequestModalProps {
  open: boolean;
  onClose: () => void;
  onSubmit: (request: any) => void;
  department: string;
}

export function BudgetRequestModal({ open, onClose, onSubmit, department }: BudgetRequestModalProps) {
  const [formData, setFormData] = useState({
    costElement: costElements[0],
    amount: '',
    justification: '',
  });

  const [similarRequests, setSimilarRequests] = useState<any[]>([]);
  const [showSimilar, setShowSimilar] = useState(false);

  const handleAmountChange = (amount: string) => {
    setFormData({ ...formData, amount });

    if (parseInt(amount) > 50000) {
      // Simulate k-NN similarity retrieval
      setSimilarRequests([
        { dept: 'Marketing', element: 'Contractor Fees', requested: 120000, approved: 100000, actualSpend: 98000, outcome: 'Challenged & Reduced' },
        { dept: 'Sales', element: 'Software Licenses', requested: 95000, approved: 95000, actualSpend: 92000, outcome: 'Approved' },
        { dept: 'Engineering', element: 'Cloud Infrastructure', requested: 110000, approved: 105000, actualSpend: 108000, outcome: 'Challenged & Reduced' },
      ]);
      setShowSimilar(true);
    } else {
      setShowSimilar(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({
      id: Date.now(),
      department,
      element: formData.costElement,
      requested: parseInt(formData.amount),
      approved: null,
      status: 'pending',
      justification: formData.justification,
    });
    setFormData({
      costElement: costElements[0],
      amount: '',
      justification: '',
    });
    setShowSimilar(false);
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Submit Budget Request - {department}</DialogTitle>
          <DialogDescription>
            k-NN similarity retrieval will show historical context for your request
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="costElement">Cost Element</Label>
              <select
                id="costElement"
                className="w-full p-2 border rounded-md"
                value={formData.costElement}
                onChange={(e) => setFormData({ ...formData, costElement: e.target.value })}
                required
              >
                {costElements.map((element) => (
                  <option key={element}>{element}</option>
                ))}
              </select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="amount">Requested Amount</Label>
              <Input
                id="amount"
                type="number"
                placeholder="0.00"
                value={formData.amount}
                onChange={(e) => handleAmountChange(e.target.value)}
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="justification">Justification</Label>
            <textarea
              id="justification"
              className="w-full p-2 border rounded-md min-h-[100px]"
              placeholder="Explain why this budget is needed..."
              value={formData.justification}
              onChange={(e) => setFormData({ ...formData, justification: e.target.value })}
              required
            />
          </div>

          {showSimilar && (
            <div className="space-y-3">
              <div className="flex items-center gap-2 text-sm font-semibold">
                <TrendingUp className="size-4" />
                <span>k-NN Similar Historical Requests</span>
                <Badge variant="outline">AI-Powered Context</Badge>
              </div>

              <div className="space-y-2">
                {similarRequests.map((req, idx) => (
                  <div key={idx} className="p-3 border rounded-lg bg-blue-50 dark:bg-blue-950/20">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <p className="font-medium text-sm">{req.dept} - {req.element}</p>
                        <p className="text-xs text-muted-foreground">Similar to your request</p>
                      </div>
                      <Badge variant={req.outcome.includes('Approved') ? 'default' : 'destructive'}>
                        {req.outcome}
                      </Badge>
                    </div>
                    <div className="grid grid-cols-3 gap-2 text-xs">
                      <div>
                        <p className="text-muted-foreground">Requested</p>
                        <p className="font-mono">${req.requested.toLocaleString()}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Approved</p>
                        <p className="font-mono">${req.approved.toLocaleString()}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Actual Spend</p>
                        <p className="font-mono">${req.actualSpend.toLocaleString()}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="bg-yellow-50 dark:bg-yellow-950/20 p-3 rounded-lg border border-yellow-200 dark:border-yellow-800">
                <p className="text-xs">
                  <strong>AI Insight:</strong> Similar requests were challenged when exceeding $100K.
                  Consider breaking down the request or providing detailed ROI justification to improve approval chances.
                </p>
              </div>
            </div>
          )}

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit">Submit Request</Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
