import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '../ui/dialog';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Checkbox } from '../ui/checkbox';
import { AlertCircle, CheckCircle, X, Eye } from 'lucide-react';

interface ReviewDocument {
  id: number;
  type: string;
  uploadDate: string;
  lowConfidenceFields: {
    label: string;
    value: string;
    confidence: number;
    key: string;
  }[];
  imagePreview?: string;
}

interface ReviewQueueModalProps {
  open: boolean;
  onClose: () => void;
  documents: ReviewDocument[];
  onApprove: (docIds: number[]) => void;
  onReject: (docIds: number[]) => void;
}

export function ReviewQueueModal({
  open,
  onClose,
  documents,
  onApprove,
  onReject
}: ReviewQueueModalProps) {
  const [selectedDocs, setSelectedDocs] = useState<number[]>([]);
  const [currentDoc, setCurrentDoc] = useState<ReviewDocument | null>(null);
  const [editedFields, setEditedFields] = useState<Record<string, string>>({});

  const handleSelectAll = () => {
    if (selectedDocs.length === documents.length) {
      setSelectedDocs([]);
    } else {
      setSelectedDocs(documents.map(d => d.id));
    }
  };

  const handleSelectDoc = (id: number) => {
    if (selectedDocs.includes(id)) {
      setSelectedDocs(selectedDocs.filter(docId => docId !== id));
    } else {
      setSelectedDocs([...selectedDocs, id]);
    }
  };

  const handleReview = (doc: ReviewDocument) => {
    setCurrentDoc(doc);
    const initialEdits: Record<string, string> = {};
    doc.lowConfidenceFields.forEach(field => {
      initialEdits[field.key] = field.value;
    });
    setEditedFields(initialEdits);
  };

  const handleSaveEdits = () => {
    // Save the edited fields and approve
    if (currentDoc) {
      onApprove([currentDoc.id]);
      setCurrentDoc(null);
      setEditedFields({});
    }
  };

  const handleBulkApprove = () => {
    onApprove(selectedDocs);
    setSelectedDocs([]);
  };

  const handleBulkReject = () => {
    onReject(selectedDocs);
    setSelectedDocs([]);
  };

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 0.8) return 'text-yellow-600';
    return 'text-red-600';
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-7xl max-h-[95vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle>Review Queue - Low Confidence Documents</DialogTitle>
          <DialogDescription>
            {documents.length} documents flagged for human verification
          </DialogDescription>
        </DialogHeader>

        {!currentDoc ? (
          <div className="flex-1 overflow-hidden flex flex-col space-y-4">
            {/* Bulk Actions */}
            <div className="flex items-center justify-between border-b pb-3">
              <div className="flex items-center gap-3">
                <Checkbox
                  checked={selectedDocs.length === documents.length && documents.length > 0}
                  onCheckedChange={handleSelectAll}
                />
                <span className="text-sm text-muted-foreground">
                  {selectedDocs.length} selected
                </span>
              </div>
              <div className="flex gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  disabled={selectedDocs.length === 0}
                  onClick={handleBulkApprove}
                  className="text-green-600 hover:text-green-700"
                >
                  <CheckCircle className="size-4 mr-1" />
                  Approve Selected ({selectedDocs.length})
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  disabled={selectedDocs.length === 0}
                  onClick={handleBulkReject}
                  className="text-red-600 hover:text-red-700"
                >
                  <X className="size-4 mr-1" />
                  Reject Selected ({selectedDocs.length})
                </Button>
              </div>
            </div>

            {/* Document List */}
            <div className="flex-1 overflow-y-auto">
              <div className="border rounded-lg overflow-hidden">
                <table className="w-full text-sm">
                  <thead className="bg-gray-50 dark:bg-gray-900 sticky top-0">
                    <tr>
                      <th className="w-12 p-3"></th>
                      <th className="text-left p-3 font-medium">Document Type</th>
                      <th className="text-left p-3 font-medium">Upload Date</th>
                      <th className="text-left p-3 font-medium">Low Confidence Fields</th>
                      <th className="text-left p-3 font-medium">Issues</th>
                      <th className="text-right p-3 font-medium">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {documents.map(doc => (
                      <tr
                        key={doc.id}
                        className={`border-t hover:bg-gray-50 dark:hover:bg-gray-900 ${
                          selectedDocs.includes(doc.id) ? 'bg-blue-50 dark:bg-blue-950/20' : ''
                        }`}
                      >
                        <td className="p-3">
                          <Checkbox
                            checked={selectedDocs.includes(doc.id)}
                            onCheckedChange={() => handleSelectDoc(doc.id)}
                          />
                        </td>
                        <td className="p-3">
                          <div className="flex items-center gap-2">
                            <Badge variant="outline">{doc.type}</Badge>
                          </div>
                        </td>
                        <td className="p-3">{new Date(doc.uploadDate).toLocaleString()}</td>
                        <td className="p-3">
                          <div className="flex flex-wrap gap-1">
                            {doc.lowConfidenceFields.map((field, idx) => (
                              <Badge key={idx} variant="outline" className="text-xs">
                                {field.label}
                              </Badge>
                            ))}
                          </div>
                        </td>
                        <td className="p-3">
                          <div className="flex items-center gap-1 text-amber-600 dark:text-amber-400">
                            <AlertCircle className="size-4" />
                            <span className="text-xs font-medium">
                              {doc.lowConfidenceFields.length} field(s) need review
                            </span>
                          </div>
                        </td>
                        <td className="p-3 text-right">
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => handleReview(doc)}
                          >
                            <Eye className="size-4 mr-1" />
                            Review
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {documents.length === 0 && (
                <div className="text-center py-12 text-muted-foreground">
                  <CheckCircle className="size-12 mx-auto mb-3 text-green-600 opacity-50" />
                  <p className="font-medium">All documents verified</p>
                  <p className="text-sm">No documents require review at this time</p>
                </div>
              )}
            </div>
          </div>
        ) : (
          <div className="flex-1 overflow-hidden grid grid-cols-2 gap-6">
            {/* Left: Image Preview */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold">Original Document</h3>
                <Button variant="ghost" size="sm" onClick={() => setCurrentDoc(null)}>
                  <X className="size-4 mr-1" />
                  Back to Queue
                </Button>
              </div>

              {currentDoc.imagePreview ? (
                <div className="border rounded-lg overflow-hidden bg-gray-100 dark:bg-gray-800">
                  <img
                    src={currentDoc.imagePreview}
                    alt="Document"
                    className="w-full h-auto max-h-[600px] object-contain"
                  />
                </div>
              ) : (
                <div className="border rounded-lg p-12 text-center bg-gray-50 dark:bg-gray-900 h-[600px] flex items-center justify-center">
                  <div>
                    <AlertCircle className="size-16 mx-auto mb-3 text-gray-400" />
                    <p className="text-sm text-muted-foreground">No preview available</p>
                  </div>
                </div>
              )}

              <div className="p-3 bg-gray-50 dark:bg-gray-900 rounded-lg border text-sm">
                <div className="flex items-center justify-between py-1">
                  <span className="text-muted-foreground">Type:</span>
                  <Badge variant="outline">{currentDoc.type}</Badge>
                </div>
                <div className="flex items-center justify-between py-1">
                  <span className="text-muted-foreground">Uploaded:</span>
                  <span>{new Date(currentDoc.uploadDate).toLocaleString()}</span>
                </div>
              </div>
            </div>

            {/* Right: Fields to Review */}
            <div className="space-y-3 flex flex-col">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold">Fields Requiring Review</h3>
                <Badge className="bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-200">
                  {currentDoc.lowConfidenceFields.length} fields flagged
                </Badge>
              </div>

              <div className="p-4 bg-amber-50 dark:bg-amber-950/20 rounded-lg border border-amber-200 dark:border-amber-800">
                <div className="flex items-start gap-2">
                  <AlertCircle className="size-5 text-amber-600 dark:text-amber-400 flex-shrink-0 mt-0.5" />
                  <div className="text-sm">
                    <p className="font-medium mb-1">Please verify or correct the following fields:</p>
                    <p className="text-xs text-muted-foreground">
                      Low confidence values are highlighted. Edit if corrections are needed.
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex-1 overflow-y-auto space-y-4 pr-2">
                {currentDoc.lowConfidenceFields.map((field) => (
                  <div key={field.key} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label className="text-sm font-medium">{field.label}</Label>
                      <Badge
                        variant="outline"
                        className={`text-xs ${
                          field.confidence >= 0.8
                            ? 'text-yellow-600 bg-yellow-50 border-yellow-200'
                            : 'text-red-600 bg-red-50 border-red-200'
                        }`}
                      >
                        {(field.confidence * 100).toFixed(0)}% confidence
                      </Badge>
                    </div>
                    <Input
                      value={editedFields[field.key] || field.value}
                      onChange={(e) => setEditedFields({ ...editedFields, [field.key]: e.target.value })}
                      className={field.confidence < 0.8 ? 'border-red-300' : 'border-yellow-300'}
                    />
                    {field.confidence < 0.7 && (
                      <p className="text-xs text-red-600 dark:text-red-400">
                        Critical: Very low confidence - please verify carefully
                      </p>
                    )}
                  </div>
                ))}
              </div>

              <div className="flex gap-2 pt-4 border-t">
                <Button
                  variant="outline"
                  className="flex-1"
                  onClick={() => {
                    setCurrentDoc(null);
                    setEditedFields({});
                  }}
                >
                  Skip
                </Button>
                <Button
                  variant="outline"
                  className="flex-1 text-red-600 hover:text-red-700"
                  onClick={() => {
                    onReject([currentDoc.id]);
                    setCurrentDoc(null);
                    setEditedFields({});
                  }}
                >
                  <X className="size-4 mr-1" />
                  Reject
                </Button>
                <Button
                  className="flex-1 bg-green-600 hover:bg-green-700"
                  onClick={handleSaveEdits}
                >
                  <CheckCircle className="size-4 mr-1" />
                  Save & Approve
                </Button>
              </div>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
