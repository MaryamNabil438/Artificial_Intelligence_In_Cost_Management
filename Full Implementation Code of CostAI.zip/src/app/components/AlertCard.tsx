import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { AlertTriangle, AlertCircle, Info } from 'lucide-react';
import { Badge } from './ui/badge';

interface AlertCardProps {
  title: string;
  description: string;
  severity: 'critical' | 'high' | 'medium' | 'low';
  type: 'strategic' | 'operational';
  timestamp: string;
  department?: string;
}

export function AlertCard({ title, description, severity, type, timestamp, department }: AlertCardProps) {
  const severityConfig = {
    critical: { icon: AlertTriangle, color: 'bg-red-500', textColor: 'text-red-600 dark:text-red-400', badge: 'destructive' as const },
    high: { icon: AlertCircle, color: 'bg-orange-500', textColor: 'text-orange-600 dark:text-orange-400', badge: 'destructive' as const },
    medium: { icon: AlertCircle, color: 'bg-yellow-500', textColor: 'text-yellow-600 dark:text-yellow-400', badge: 'outline' as const },
    low: { icon: Info, color: 'bg-blue-500', textColor: 'text-blue-600 dark:text-blue-400', badge: 'secondary' as const },
  };

  const config = severityConfig[severity];
  const Icon = config.icon;

  return (
    <Card className={severity === 'critical' || severity === 'high' ? 'border-red-500 bg-red-50 dark:bg-red-950/20' : ''}>
      <CardHeader>
        <div className="flex items-start gap-3">
          <div className={`${config.color} p-2 rounded-lg`}>
            <Icon className="size-5 text-white" />
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-2 flex-wrap">
              <CardTitle className="text-base">{title}</CardTitle>
              <Badge variant={config.badge}>{severity.toUpperCase()}</Badge>
              {type === 'strategic' && <Badge variant="outline">STRATEGIC</Badge>}
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <p className="text-sm">{description}</p>
        <div className="flex items-center gap-4 mt-3 text-xs text-muted-foreground">
          <span>{new Date(timestamp).toLocaleString()}</span>
          {department && <span>Department: {department}</span>}
        </div>
      </CardContent>
    </Card>
  );
}
