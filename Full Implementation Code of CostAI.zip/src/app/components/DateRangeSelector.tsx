import { useState } from 'react';
import { Calendar } from 'lucide-react';
import { Button } from './ui/button';
import { Popover, PopoverContent, PopoverTrigger } from './ui/popover';

interface DateRangeSelectorProps {
  onChange?: (range: string) => void;
}

export function DateRangeSelector({ onChange }: DateRangeSelectorProps) {
  const [selectedRange, setSelectedRange] = useState('Last 3 months');

  const ranges = [
    'Last 30 days',
    'Last 3 months',
    'Last 6 months',
    'Last 12 months',
    'Custom range',
  ];

  const handleSelect = (range: string) => {
    setSelectedRange(range);
    onChange?.(range);
  };

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="outline" size="sm" className="flex items-center gap-2">
          <Calendar className="size-4" />
          {selectedRange}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-48 p-2" align="end">
        <div className="space-y-1">
          {ranges.map((range) => (
            <button
              key={range}
              onClick={() => handleSelect(range)}
              className={`w-full text-left px-3 py-2 rounded text-sm hover:bg-gray-100 dark:hover:bg-gray-800 ${
                selectedRange === range ? 'bg-gray-100 dark:bg-gray-800 font-medium' : ''
              }`}
            >
              {range}
            </button>
          ))}
        </div>
      </PopoverContent>
    </Popover>
  );
}
