import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Search, FileText, AlertTriangle, Building, DollarSign } from 'lucide-react';
import { transactions, alerts, departments, costElements } from '../data/mockData';

interface GlobalSearchProps {
  open: boolean;
  onClose: () => void;
}

export function GlobalSearch({ open, onClose }: GlobalSearchProps) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<any>({
    transactions: [],
    alerts: [],
    departments: [],
    costElements: [],
  });

  useEffect(() => {
    if (!query.trim()) {
      setResults({ transactions: [], alerts: [], departments: [], costElements: [] });
      return;
    }

    const q = query.toLowerCase();

    const transactionResults = transactions.filter(
      t => t.vendor.toLowerCase().includes(q) ||
           t.category.toLowerCase().includes(q) ||
           t.department.toLowerCase().includes(q)
    );

    const alertResults = alerts.filter(
      a => a.title.toLowerCase().includes(q) ||
           a.description.toLowerCase().includes(q) ||
           a.department?.toLowerCase().includes(q)
    );

    const departmentResults = departments.filter(d => d.toLowerCase().includes(q));
    const costElementResults = costElements.filter(c => c.toLowerCase().includes(q));

    setResults({
      transactions: transactionResults.slice(0, 5),
      alerts: alertResults.slice(0, 5),
      departments: departmentResults.slice(0, 5),
      costElements: costElementResults.slice(0, 5),
    });
  }, [query]);

  const totalResults = results.transactions.length + results.alerts.length +
                       results.departments.length + results.costElements.length;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Search</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-3 size-4 text-muted-foreground" />
            <Input
              placeholder="Search transactions, vendors, alerts, departments, cost elements..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="pl-10"
              autoFocus
            />
          </div>

          {query && totalResults === 0 && (
            <div className="text-center py-8 text-muted-foreground">
              <p>No results found for "{query}"</p>
            </div>
          )}

          {results.transactions.length > 0 && (
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-sm font-semibold">
                <DollarSign className="size-4" />
                <span>Transactions</span>
                <Badge variant="secondary">{results.transactions.length}</Badge>
              </div>
              <div className="space-y-1">
                {results.transactions.map((t: any) => (
                  <div key={t.id} className="p-3 border rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 cursor-pointer">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">{t.vendor}</p>
                        <p className="text-sm text-muted-foreground">
                          {t.category} • {t.department} • {t.date}
                        </p>
                      </div>
                      <p className="font-mono font-semibold">{t.currency} {t.amount.toLocaleString()}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {results.alerts.length > 0 && (
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-sm font-semibold">
                <AlertTriangle className="size-4" />
                <span>Alerts</span>
                <Badge variant="secondary">{results.alerts.length}</Badge>
              </div>
              <div className="space-y-1">
                {results.alerts.map((a: any) => (
                  <div key={a.id} className="p-3 border rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 cursor-pointer">
                    <div className="flex items-start justify-between">
                      <div>
                        <p className="font-medium">{a.title}</p>
                        <p className="text-sm text-muted-foreground line-clamp-1">{a.description}</p>
                      </div>
                      <Badge variant={a.severity === 'critical' || a.severity === 'high' ? 'destructive' : 'outline'}>
                        {a.severity.toUpperCase()}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {results.departments.length > 0 && (
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-sm font-semibold">
                <Building className="size-4" />
                <span>Departments</span>
                <Badge variant="secondary">{results.departments.length}</Badge>
              </div>
              <div className="flex flex-wrap gap-2">
                {results.departments.map((d: string) => (
                  <div key={d} className="px-3 py-2 border rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 cursor-pointer">
                    <span className="text-sm font-medium">{d}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {results.costElements.length > 0 && (
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-sm font-semibold">
                <FileText className="size-4" />
                <span>Cost Elements</span>
                <Badge variant="secondary">{results.costElements.length}</Badge>
              </div>
              <div className="flex flex-wrap gap-2">
                {results.costElements.map((c: string) => (
                  <div key={c} className="px-3 py-2 border rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 cursor-pointer">
                    <span className="text-sm font-medium">{c}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
