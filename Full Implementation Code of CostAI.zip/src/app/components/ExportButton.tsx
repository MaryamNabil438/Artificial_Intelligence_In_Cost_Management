import { Download } from 'lucide-react';
import { Button } from './ui/button';
import { Popover, PopoverContent, PopoverTrigger } from './ui/popover';
import { toast } from 'sonner';

interface ExportButtonProps {
  data?: any[];
  filename?: string;
  title?: string;
}

export function ExportButton({ data = [], filename = 'export', title = 'Data Export' }: ExportButtonProps) {
  const handleExport = (format: 'PDF' | 'Excel') => {
    let content = '';
    let mimeType = '';
    let fileExtension = '';

    if (format === 'PDF') {
      // Generate simple text content for PDF simulation
      content = `${title}\nGenerated: ${new Date().toLocaleString()}\n\n`;

      if (data.length > 0) {
        // Convert data to readable format
        data.forEach((item, index) => {
          content += `Record ${index + 1}:\n`;
          Object.entries(item).forEach(([key, value]) => {
            content += `  ${key}: ${value}\n`;
          });
          content += '\n';
        });
      } else {
        content += 'No data available for export.';
      }

      mimeType = 'text/plain';
      fileExtension = 'pdf';
    } else {
      // Generate CSV content for Excel
      if (data.length > 0) {
        const headers = Object.keys(data[0]);
        content = headers.join(',') + '\n';
        data.forEach(item => {
          const values = headers.map(header => {
            const value = item[header];
            // Escape commas and quotes
            if (typeof value === 'string' && (value.includes(',') || value.includes('"'))) {
              return `"${value.replace(/"/g, '""')}"`;
            }
            return value;
          });
          content += values.join(',') + '\n';
        });
      } else {
        content = 'No data available for export.';
      }

      mimeType = 'text/csv';
      fileExtension = 'xlsx';
    }

    // Create and download the file
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${filename}_${new Date().toISOString().split('T')[0]}.${fileExtension}`;
    a.click();
    URL.revokeObjectURL(url);

    toast.success(`Exported as ${format} - ${a.download}`);
  };

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="outline" size="icon" className="size-8">
          <Download className="size-4" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-40 p-2" align="end">
        <div className="space-y-1">
          <button
            onClick={() => handleExport('PDF')}
            className="w-full text-left px-3 py-2 rounded text-sm hover:bg-gray-100 dark:hover:bg-gray-800"
          >
            Export as PDF
          </button>
          <button
            onClick={() => handleExport('Excel')}
            className="w-full text-left px-3 py-2 rounded text-sm hover:bg-gray-100 dark:hover:bg-gray-800"
          >
            Export as Excel
          </button>
        </div>
      </PopoverContent>
    </Popover>
  );
}
