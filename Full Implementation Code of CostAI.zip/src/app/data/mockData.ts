// Mock data for the AI Cost Management System

export const users = [
  { id: 1, name: 'Sarah Johnson', role: 'CFO' },
  { id: 2, name: 'Michael Chen', role: 'Finance Manager' },
  { id: 3, name: 'Emily Rodriguez', role: 'Cost Controller' },
  { id: 4, name: 'David Kim', role: 'Cost Analyst' },
  { id: 5, name: 'Lisa Wang', role: 'Department Manager', department: 'Engineering' },
];

export const bankAccounts = [
  { id: 1, name: 'Operating Account USD', balance: 2450000, currency: 'USD' },
  { id: 2, name: 'Reserve Account USD', balance: 1500000, currency: 'USD' },
  { id: 3, name: 'Operating Account EUR', balance: 850000, currency: 'EUR' },
  { id: 4, name: 'Egypt Operations EGP', balance: 12500000, currency: 'EGP' },
];

export const departments = [
  'Engineering',
  'Sales',
  'Marketing',
  'Operations',
  'HR',
  'Finance',
];

export const costElements = [
  'Wages & Salaries',
  'Electricity & Utilities',
  'Raw Materials',
  'Rent & Facilities',
  'Depreciation',
  'Contractor Fees',
  'Loan Repayments',
  'Software Licenses',
  'Office Supplies',
  'Travel & Entertainment',
];

export const monthlyRevenueData = [
  { month: 'Jan', actual: 1200000, forecast: 1150000 },
  { month: 'Feb', actual: 1350000, forecast: 1200000 },
  { month: 'Mar', actual: 1280000, forecast: 1250000 },
  { month: 'Apr', actual: 1450000, forecast: 1300000 },
  { month: 'May', actual: 1520000, forecast: 1400000 },
  { month: 'Jun', actual: 1480000, forecast: 1450000 },
];

export const departmentCosts = [
  { department: 'Engineering', budget: 450000, actual: 465000, variance: 15000 },
  { department: 'Sales', budget: 320000, actual: 298000, variance: -22000 },
  { department: 'Marketing', budget: 280000, actual: 305000, variance: 25000 },
  { department: 'Operations', budget: 210000, actual: 195000, variance: -15000 },
  { department: 'HR', budget: 180000, actual: 178000, variance: -2000 },
  { department: 'Finance', budget: 150000, actual: 152000, variance: 2000 },
];

export const costElementBreakdown = [
  { element: 'Wages & Salaries', amount: 890000, budget: 850000, variance: 40000 },
  { element: 'Rent & Facilities', amount: 125000, budget: 130000, variance: -5000 },
  { element: 'Electricity & Utilities', amount: 45000, budget: 40000, variance: 5000 },
  { element: 'Software Licenses', amount: 85000, budget: 90000, variance: -5000 },
  { element: 'Contractor Fees', amount: 120000, budget: 100000, variance: 20000 },
  { element: 'Raw Materials', amount: 210000, budget: 200000, variance: 10000 },
  { element: 'Travel & Entertainment', amount: 38000, budget: 50000, variance: -12000 },
];

export const alerts = [
  {
    id: 1,
    type: 'strategic',
    severity: 'high',
    title: 'Current Ratio Below Critical Threshold',
    description: 'Current ratio dropped to 1.2 (threshold: 1.5). Immediate liquidity review required.',
    timestamp: '2026-05-08T08:30:00',
    department: 'Finance',
  },
  {
    id: 2,
    type: 'operational',
    severity: 'critical',
    title: 'Payment 3x Higher Than Usual',
    description: 'Vendor: AWS Egypt — EGP 57,555 (usual: EGP 18,500)',
    timestamp: '2026-05-08T10:15:00',
    department: 'Engineering',
  },
  {
    id: 3,
    type: 'operational',
    severity: 'medium',
    title: 'Budget Variance Alert',
    description: 'Marketing department exceeded monthly budget by 8.9%',
    timestamp: '2026-05-08T14:20:00',
    department: 'Marketing',
  },
  {
    id: 4,
    type: 'strategic',
    severity: 'high',
    title: 'Asset Mismanagement Detected',
    description: 'Depreciation schedule shows 3 assets with irregular patterns',
    timestamp: '2026-05-07T16:45:00',
    department: 'Finance',
  },
  {
    id: 5,
    type: 'operational',
    severity: 'low',
    title: 'Duplicate Transaction Detected',
    description: 'Possible duplicate payment to Supplier XYZ — $4,500',
    timestamp: '2026-05-07T11:30:00',
    department: 'Operations',
  },
];

export const upcomingPayments = [
  { id: 1, type: 'Payroll', vendor: 'All Employees', amount: 890000, currency: 'USD', dueDate: '2026-05-15' },
  { id: 2, type: 'Supplier Invoice', vendor: 'Tech Supplies Inc', amount: 45000, currency: 'USD', dueDate: '2026-05-12' },
  { id: 3, type: 'Loan Repayment', vendor: 'City Bank', amount: 125000, currency: 'USD', dueDate: '2026-05-20' },
  { id: 4, type: 'Supplier Invoice', vendor: 'Office Lease Corp', amount: 85000, currency: 'USD', dueDate: '2026-05-10' },
  { id: 5, type: 'Supplier Invoice', vendor: 'Cloud Services MENA', amount: 12500, currency: 'EGP', dueDate: '2026-05-18' },
];

export const financialRatios = {
  liquidity: {
    currentRatio: 1.2,
    quickRatio: 0.85,
  },
  profitability: {
    grossMargin: 0.42,
    netMargin: 0.18,
    roe: 0.15,
  },
  efficiency: {
    assetTurnover: 1.8,
    inventoryTurnover: 4.2,
  },
  solvency: {
    debtToEquity: 0.65,
    interestCoverage: 8.5,
  },
};

export const forecastData = {
  linear: [
    { month: 'Jul', forecast: 1550000, lower: 1480000, upper: 1620000 },
    { month: 'Aug', forecast: 1620000, lower: 1540000, upper: 1700000 },
    { month: 'Sep', forecast: 1690000, lower: 1600000, upper: 1780000 },
  ],
  arima: [
    { month: 'Jul', forecast: 1565000, lower: 1495000, upper: 1635000 },
    { month: 'Aug', forecast: 1610000, lower: 1530000, upper: 1690000 },
    { month: 'Sep', forecast: 1675000, lower: 1585000, upper: 1765000 },
  ],
  prophet: [
    { month: 'Jul', forecast: 1580000, lower: 1510000, upper: 1650000 },
    { month: 'Aug', forecast: 1635000, lower: 1555000, upper: 1715000 },
    { month: 'Sep', forecast: 1695000, lower: 1605000, upper: 1785000 },
  ],
};

export const costElementForecastData: Record<string, any> = {
  'Wages & Salaries': {
    historical: [
      { month: 'Jan', actual: 850000 },
      { month: 'Feb', actual: 855000 },
      { month: 'Mar', actual: 870000 },
      { month: 'Apr', actual: 880000 },
      { month: 'May', actual: 885000 },
      { month: 'Jun', actual: 890000 },
    ],
    forecast: [
      { month: 'Jul', forecast: 895000, lower: 880000, upper: 910000 },
      { month: 'Aug', forecast: 905000, lower: 890000, upper: 920000 },
      { month: 'Sep', forecast: 915000, lower: 900000, upper: 930000 },
    ],
  },
  'Rent & Facilities': {
    historical: [
      { month: 'Jan', actual: 125000 },
      { month: 'Feb', actual: 125000 },
      { month: 'Mar', actual: 128000 },
      { month: 'Apr', actual: 125000 },
      { month: 'May', actual: 126000 },
      { month: 'Jun', actual: 125000 },
    ],
    forecast: [
      { month: 'Jul', forecast: 127000, lower: 122000, upper: 132000 },
      { month: 'Aug', forecast: 126000, lower: 121000, upper: 131000 },
      { month: 'Sep', forecast: 128000, lower: 123000, upper: 133000 },
    ],
  },
  'Electricity & Utilities': {
    historical: [
      { month: 'Jan', actual: 38000 },
      { month: 'Feb', actual: 39000 },
      { month: 'Mar', actual: 41000 },
      { month: 'Apr', actual: 43000 },
      { month: 'May', actual: 44000 },
      { month: 'Jun', actual: 45000 },
    ],
    forecast: [
      { month: 'Jul', forecast: 47000, lower: 44000, upper: 50000 },
      { month: 'Aug', forecast: 48000, lower: 45000, upper: 51000 },
      { month: 'Sep', forecast: 46000, lower: 43000, upper: 49000 },
    ],
  },
  'Software Licenses': {
    historical: [
      { month: 'Jan', actual: 78000 },
      { month: 'Feb', actual: 80000 },
      { month: 'Mar', actual: 82000 },
      { month: 'Apr', actual: 83000 },
      { month: 'May', actual: 84000 },
      { month: 'Jun', actual: 85000 },
    ],
    forecast: [
      { month: 'Jul', forecast: 87000, lower: 84000, upper: 90000 },
      { month: 'Aug', forecast: 89000, lower: 86000, upper: 92000 },
      { month: 'Sep', forecast: 91000, lower: 88000, upper: 94000 },
    ],
  },
  'Contractor Fees': {
    historical: [
      { month: 'Jan', actual: 95000 },
      { month: 'Feb', actual: 98000 },
      { month: 'Mar', actual: 105000 },
      { month: 'Apr', actual: 110000 },
      { month: 'May', actual: 115000 },
      { month: 'Jun', actual: 120000 },
    ],
    forecast: [
      { month: 'Jul', forecast: 125000, lower: 118000, upper: 132000 },
      { month: 'Aug', forecast: 130000, lower: 123000, upper: 137000 },
      { month: 'Sep', forecast: 135000, lower: 128000, upper: 142000 },
    ],
  },
  'Raw Materials': {
    historical: [
      { month: 'Jan', actual: 195000 },
      { month: 'Feb', actual: 198000 },
      { month: 'Mar', actual: 202000 },
      { month: 'Apr', actual: 205000 },
      { month: 'May', actual: 208000 },
      { month: 'Jun', actual: 210000 },
    ],
    forecast: [
      { month: 'Jul', forecast: 213000, lower: 205000, upper: 221000 },
      { month: 'Aug', forecast: 216000, lower: 208000, upper: 224000 },
      { month: 'Sep', forecast: 219000, lower: 211000, upper: 227000 },
    ],
  },
  'Travel & Entertainment': {
    historical: [
      { month: 'Jan', actual: 42000 },
      { month: 'Feb', actual: 40000 },
      { month: 'Mar', actual: 39000 },
      { month: 'Apr', actual: 37000 },
      { month: 'May', actual: 36000 },
      { month: 'Jun', actual: 38000 },
    ],
    forecast: [
      { month: 'Jul', forecast: 37000, lower: 33000, upper: 41000 },
      { month: 'Aug', forecast: 36000, lower: 32000, upper: 40000 },
      { month: 'Sep', forecast: 38000, lower: 34000, upper: 42000 },
    ],
  },
};

export const budgetRequests = [
  { id: 1, department: 'Engineering', element: 'Software Licenses', requested: 95000, approved: null, status: 'pending' },
  { id: 2, department: 'Marketing', element: 'Contractor Fees', requested: 120000, approved: 100000, status: 'challenged' },
  { id: 3, department: 'Sales', element: 'Travel & Entertainment', requested: 65000, approved: null, status: 'pending' },
  { id: 4, department: 'Operations', element: 'Raw Materials', requested: 220000, approved: 200000, status: 'approved' },
];

export const transactions = [
  { id: 1, date: '2026-05-07', vendor: 'AWS Egypt', amount: 57555, currency: 'EGP', category: 'Software Licenses', department: 'Engineering', anomaly: true },
  { id: 2, date: '2026-05-06', vendor: 'Office Lease Corp', amount: 85000, currency: 'USD', category: 'Rent & Facilities', department: 'Finance', anomaly: false },
  { id: 3, date: '2026-05-05', vendor: 'Tech Supplies Inc', amount: 4500, currency: 'USD', category: 'Office Supplies', department: 'Operations', anomaly: false },
  { id: 4, date: '2026-05-05', vendor: 'Supplier XYZ', amount: 4500, currency: 'USD', category: 'Office Supplies', department: 'Operations', anomaly: true },
  { id: 5, date: '2026-05-04', vendor: 'Marketing Agency Pro', amount: 35000, currency: 'USD', category: 'Contractor Fees', department: 'Marketing', anomaly: false },
];
