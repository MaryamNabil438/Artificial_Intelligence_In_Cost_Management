Adjustments to the Website:

Add a search bar in the top navigation bar visible on every dashboard for every role. It should search across transactions, vendors, alerts, departments, and cost elements. Results should be grouped by type (Transactions / Alerts / Departments / Reports). This is currently missing entirely from the prototype.

Add a notification preferences screen accessible from the top navigation under a bell icon for every role. The screen should show toggles for:
Email notifications: on/off per alert type
SMS notifications: on/off per alert type
Push notifications: on/off per alert type
Show three alert categories with independent toggles:
Critical alerts (Strategic Red Flags) — default on for all channels
High severity alerts — default on for email only
Low/medium alerts — default off
Add a small bell icon with a red badge counter in the top navigation bar showing unread alerts. Clicking it opens a dropdown showing the five most recent alerts across all types with a "View All" link.
Every chart in the prototype currently shows a fixed time period with no way to change it. Add a date range selector to the top right of every chart panel. Options should be: Last 30 days / Last 3 months / Last 6 months / Last 12 months / Custom range. This applies to:
Revenue vs Forecast chart (CFO)
Cost Breakdown by Department chart (CFO)
3-Month Forecast Comparison chart (CFO)
Historical Trend Analysis chart (Cost Analyst)
Anomaly trend chart (Cost Analyst — new addition from previous brief)
Monthly Budget Trend chart (Department Manager)
Resource Allocation charts (Finance Manager)
Add a download icon button to the top right corner of the following panels. Clicking it shows a small dropdown: Export as PDF / Export as Excel.
Panels that need this:
Built-in Financial Ratios panel (CFO)
Upcoming Payments table (CFO)
Bank & Cash Visibility table (CFO)
All three Financial Statements tables (Income Statement, Balance Sheet, Cash Flow)
Variance Analysis panel (Finance Manager)
Flagged Transactions panel (Cost Analyst)
Monthly On-Track Report (Cost Controller)
The system uses red, amber, and green throughout for status indicators, alert severity, and variance. This is invisible to colour-blind users. For every instance of RAG colour coding add a secondary visual cue alongside the colour:
Red / OFF TRACK / HIGH → add an X icon
Amber / AT RISK / MEDIUM → add a warning triangle icon
Green / ON TRACK / LOW → add a checkmark icon
This applies to:
Department status rows (Cost Controller Monthly Report)
Cost Element status rows (Cost Controller Monthly Report)
Alert severity badges throughout all dashboards
Budget variance percentages throughout all dashboards
Risk indicator rows (CFO Risk Indicators tab)
Do not remove the colours — just add the icon alongside every instance.

In the Budget Review & Challenge tab, add a "Version History" button next to the consolidated budget total. Clicking it opens a side panel showing a timeline of every change made to the budget: who changed it, what was changed, the old value, the new value, and the timestamp. This is an audit requirement. Each row in the timeline should show: Date / User / Action (Approved / Challenged / Adjusted) / Department / Cost Element / Old Value / New Value.

In the Monthly On-Track Report tab, the "Generate & Send Monthly Report to CFO" button currently sends immediately with no preview. Change this to a two-step flow:
Step 1: Button label changes to "Preview & Send Report to CFO"
Step 2: Clicking opens a full-screen preview of the report exactly as the CFO will see it, with a "Send to CFO" button at the top right and a "Back to Edit" button at the top left
Already specified in the Financial Statements brief. Adding here for completeness: when the AI detects a reconciliation mismatch between statements, highlight the specific mismatched cell in red with an inline tooltip showing the exact discrepancy amount and which statement it conflicts with. Do not use a generic alert banner — the flag must be on the specific cell so the Finance Manager knows exactly where to look.
The Current Ratio is shown as 1.20 in red (below the 1.5 threshold) but the surrounding KPI cards show positive sentiment. This creates a confusing mixed message. When any financial ratio is in a critical state, add a thin red border to the entire Built-in Financial Ratios panel and change the panel header to amber: "Financial Ratios — 1 Critical." The individual ratio value stays red. The positive KPI cards above do not change — but the visual separation between the sections should be clearer so the contradiction is intentional and readable rather than confusing.
Here's a complete summary of every decision made in this conversation, structured by area:

CostAI — Full Decision Log

1. Roles
System has 5 roles: CFO, Finance Manager, Cost Controller, Cost Analyst, Department Manager
Cost Controller is a new first-class role, not a minor addition
Department Manager has the weakest AI integration and needs budget request AI guidance added

2. AI Techniques — Final Decisions
Every technique replaced or confirmed:
Feature
Old
New Decision
Forecasting
ARIMA + Linear Regression + Prophet equally
Prophet as primary, others as secondary/comparison only
Scenario Simulation
Monte Carlo
Gradient Boosting (XGBoost/LightGBM) — Monte Carlo removed entirely, not AI
Anomaly Detection
Z-Score + Isolation Forest equally
Autoencoder as primary, all others run silently in background
NLP — Ask CostAI
ML intent classification + NER
RAG with fine-tuned financial encoder — hallucination structurally eliminated
Document Scanning
Generic OCR
Vision Transformer (ViT) with structured extraction head
Recommendations
Rule-based
Contextual Bandit — learns from what each user acts on over time
Strategic Alerts
Threshold rules
Isolation Forest applied to financial ratio time series — catches gradual deterioration before threshold is crossed
Budget Challenge Assist
Manual judgment
k-NN similarity retrieval — surfaces comparable historical submissions and their outcomes


3. Monte Carlo — Removed
Monte Carlo is not an AI technique — it is a classical probabilistic method from the 1940s
Replaced with Gradient Boosting (XGBoost/LightGBM)
P10/P50/P90 outputs are preserved but now generated through input perturbations on the trained model
Do not present Gradient Boosting as "Monte Carlo replacement" in the UI — just label it as the scenario simulation engine

4. CFO Dashboard — Changes
Executive Overview is overloaded — too many panels on one screen, needs visual hierarchy improvement
Revenue vs Forecast chart missing axis labels on some screens — fix required
Three forecast model outputs ($1550K, $1565K, $1580K) shown as equals — should show Prophet as recommended figure, others as context
AI explainability block is buried below the forecast chart — move it closer to the numbers
Multi-currency forecasting never visually demonstrated in prototype — needs a screen showing currencies split independently
Scenario Simulator: replace Monte Carlo with Gradient Boosting, keep P10/P50/P90 output format
Scenario Simulator: add side-by-side scenario comparison — currently missing entirely
Scenario Simulator: replace free-text Impact Range field with a slider or structured input
Strategic Red Flag alerts and Unusual Movements panels look too similar — need stronger visual separation
Current Ratio shown as 1.20 in red but overall dashboard tone is positive — contradiction needs resolving
Strategic alerts triggered by Isolation Forest on ratio time series, not just threshold breaches

5. Bank & Cash Visibility + Upcoming Payments — Full Redesign
Approach changed from Live Bank API to ViT Statement Upload:
Do not build OAuth / Open Banking API integration for the initial version
Use the same Vision Transformer already recommended for document scanning
Finance Manager uploads a PDF or photo of a bank statement
ViT extracts account name, balance, transactions, scheduled payments automatically
Works for every bank immediately — no aggregator partnership needed
Live API connection can be added later for real-time accounts if needed
Screens needed:
Empty state — upload area with "Upload Statement" button and drag-and-drop zone
Processing state — loading indicator while ViT reads the document
Review state — extracted rows shown in amber (editable) with "Confirm & Save" button and "Extracted by AI — please review before confirming" banner
Low confidence state — specific cells highlighted red with tooltip "We couldn't read this field clearly — please enter manually"
Populated state — table showing normally with last-updated timestamp and document icon per row, plus "Upload New Statement" button
Error state — "We could not read this file" with Retry button
Table rules:
Add Source column: bank/document icon for uploaded statement rows, pencil icon for manual entries, checkmark for matched rows
Long vendor names: truncate at 24 characters with hover tooltip
More than 8 rows: pagination not infinite scroll
AI-predicted payments: show existing AI explainability label
Each row shows native currency
Footer shows USD-equivalent total with "Converted at live rates — last updated [time]"
If exchange rate unavailable: show "—" with tooltip explanation
Role visibility:
CFO → reads table and last-updated timestamp, does not see upload button
Finance Manager → owns the entire upload flow
Cost Controller, Cost Analyst, Department Manager → panel does not appear in navigation
Alert hierarchy for connection issues:
Upload errors and low confidence warnings → amber inline banner inside Bank & Cash Visibility panel only
Do NOT escalate these to the main Strategic Red Flag Alerts panel
Strategic Red Flag Alerts remain reserved for financial distress signals only
Component reuse:
Upload zone → reuse document scanning upload component from Finance Manager dashboard
Table rows → reuse existing row component
Alert banners → reuse tiered alert component in amber

6. Financial Statements Module — New Addition
A new dedicated module where uploaded statements render as proper structured digital tables:
Three statements covered:
Income Statement (Revenue, COGS, Gross Profit, EBITDA, Net Profit)
Balance Sheet (Current Assets, Non-Current Assets, Liabilities, Equity)
Cash Flow Statement (Operating, Investing, Financing activities, Opening/Closing Balance)
Features:
Period selector: monthly, quarterly, annual
Comparison column for previous period with variance automatically calculated
Upload button to push new statement in
Download button to export as PDF or Excel
All three statements link to each other — Net Profit flows into Equity, Closing Cash matches Balance Sheet Cash
Reconciliation check — AI added value:
System automatically checks cross-statement consistency on every upload
If Net Profit on Income Statement does not match Equity on Balance Sheet → red flag inline on the mismatched cell with specific message ("difference of EGP 22,164")
If Closing Cash on Cash Flow does not match Cash & Equivalents on Balance Sheet → same inline flag
This replaces manual accountant reconciliation
Role access:
CFO → reads all three statements, sees reconciliation flags, sees variance vs prior period
Finance Manager → uploads, edits extracted data, confirms and publishes
Cost Controller → reads Income Statement only
Cost Analyst → reads Income Statement only
Department Manager → no access

7. Finance Manager — Alerts & Anomalies Tab — Redesign
What to remove:
Strategic Alerts section (Current Ratio, Asset Mismanagement) — wrong role, wrong screen
"Why Autoencoder?" explanation box — belongs in Cost Analyst dashboard
Algorithm selector buttons (Autoencoder / Isolation Forest / LOF / DBSCAN / Z-Score) — wrong role entirely
What to keep:
Summary counters (Critical: 1, High Severity: 2, All Alerts: 5)
What to show instead:
Section 1: Unusual Movements — operational anomalies flagged by detection engine, output only, no method shown
Section 2: Budget Variance Alerts — departments or cost elements exceeding budget
Strategic alert handling:
If a strategic alert fires, Finance Manager sees only a passive line: "1 strategic alert has been escalated to the CFO"
No details, no action required from this role

8. Cost Analyst — Anomaly Investigation Tab — Additions
Move here from Finance Manager:
Algorithm selector → but redesigned (see below)
Algorithm explainer → reframed as read-only comparison panel
Algorithm description text
New additions:
Confidence score (percentage) on every flagged transaction row
Cross-algorithm agreement indicator per transaction: "Flagged by: Autoencoder ✓ Isolation Forest ✓ LOF ✓ DBSCAN — Z-Score —"
"Mark as False Positive" button per flagged row with reason dropdown (Expected payment / Already approved / Duplicate of known transaction / Other) — feeds back into model learning
Investigation notes field per flagged item for analyst to record findings and actions taken
Anomaly trend chart — weekly anomaly count over past 6 months at top of tab
Model performance panel: total transactions, anomalies detected, false positives marked, current model precision percentage, drift warning if precision drops

9. Algorithm Selection — Philosophy Decision
Decision: Automatic primary, visible secondary — no free choice for the analyst
Autoencoder runs automatically on every refresh as primary method
All other algorithms (Isolation Forest, LOF, DBSCAN, Z-Score) run silently in background
Results used only to calculate cross-algorithm agreement indicator
Analyst sees output, never controls
What changes in the UI:
Remove algorithm selector buttons from top of Cost Analyst tab
Replace with read-only label: "Detection Engine: Autoencoder (Primary) — Isolation Forest, LOF, DBSCAN, Z-Score running as supporting methods"
Algorithm comparison table becomes read-only results panel — shows anomaly count and precision per method, not a selector
Only place algorithm toggling exists: inside expanded detail view of a single flagged transaction as a forensic investigation tool
System admin exception:
Changing the primary algorithm system-wide lives in admin/settings panel only
Not accessible from any role dashboard

10. Prototype-wide Issues to Fix
Color language for alerts is inconsistent across roles — strategic and operational alerts use same visual treatment in some screens
Almost every dashboard uses the same blue/gray bar chart — visual monotony makes orientation harder
Audit log mentioned in brief but appears nowhere in prototype screens — needs to be visible and accessible
Explainability layer inconsistently applied — appears on forecasting and some anomaly results but not on recommendations, risk indicators, or alert triggers — must be uniform
No empty state design anywhere — needed for first deployment
Role switching has no confirmation step — in a live financial system this needs a confirmation or re-authentication prompt to prevent accidental sensitive data exposure
Cost Controller budget review has no running total as approvals happen — needs real-time consolidated budget counter visible while reviewing submissions
Cost Controller Monthly On-Track Report has no preview before sending to CFO — one-way send with no preview is a UX risk
Document scanning has no screen showing what happens when extraction is wrong or ambiguous — needs a correction flow
Department Manager missing AI-assisted budget request guidance — should flag when a submission is above historical baseline and prompt for justification before submission

11. User Stories — Updated
All 50 user stories updated in the Word document with the following technique changes reflected:
REQ-PY-2, REQ-PY-14, REQ-PY-28 → Autoencoder as primary
REQ-PY-5, REQ-PY-17, REQ-PY-41 → Prophet as primary
REQ-PY-6, REQ-PY-19, REQ-PY-48 → Gradient Boosting replacing Monte Carlo
REQ-PY-15, REQ-PY-20, REQ-PY-31 → Contextual Bandit for recommendations
REQ-PY-21 → RAG with fine-tuned encoder
REQ-PY-23 → Vision Transformer (ViT)
REQ-PY-37 → k-NN similarity retrieval for budget challenge
REQ-PY-44 → Isolation Forest on ratio time series
REQ-PY-49 → Feature importance from Gradient Boosting or Autoencoder as applicable
Here's the exact text to send:

Financial Statements Module — New Addition Brief
Add a new section called Financial Statements to the system. This appears as a new tab in the CFO dashboard navigation and the Finance Manager dashboard navigation. It does not appear for Cost Controller, Cost Analyst, or Department Manager navigation at all.

Tab structure
Inside the Financial Statements section there are three sub-tabs:
Income Statement
Balance Sheet
Cash Flow Statement
At the top of the section, before the sub-tabs, place:
A period selector dropdown: Monthly / Quarterly / Annual
A year and month selector next to it showing the current period (e.g. "May 2026")
An Upload Statement button (Finance Manager sees this, CFO does not)
A Download button visible to both CFO and Finance Manager — clicking shows dropdown: Export as PDF / Export as Excel

Income Statement — table structure
Render as a structured table with the following layout. Left column is the row label, middle column is current period value, next column is previous period value, right column is variance percentage. Subtotal rows (Gross Profit, EBITDA, Net Profit) should have a light grey background to distinguish them from regular rows. Total rows should be bold. Negative values should appear in parentheses in red (e.g. (480,000)).
Rows in order:
Revenue
Cost of Goods Sold (indented)
Gross Profit (subtotal row)
Operating Expenses (indented)
EBITDA (subtotal row)
Depreciation (indented)
Net Profit (total row, bold)

Balance Sheet — table structure
Render as a structured table with two-level indentation. Section headers (ASSETS, LIABILITIES, EQUITY) in bold uppercase with a blue background matching the existing table header style. Category headers (Current Assets, Non-Current Assets, Current Liabilities) in bold with light grey background. Individual line items indented under their category. Subtotal rows (Total Current Assets, Total Assets, Total Liabilities) bold with a border above.
Sections in order:
ASSETS
Current Assets
Cash & Equivalents
Accounts Receivable
Inventory
Total Current Assets (subtotal)
Non-Current Assets
Property & Equipment
Less: Depreciation (shown in red parentheses)
Total Assets (bold, border above and below)
LIABILITIES
Current Liabilities
Accounts Payable
Loan Repayments
Total Liabilities (subtotal)
EQUITY (bold, single figure)

Cash Flow Statement — table structure
Three sections with the same indentation pattern as Balance Sheet. Section headers bold with light grey background. Net figures per section bold. Final three rows (Net Cash Movement, Opening Balance, Closing Balance) bold with a border above separating them from the financing section.
Sections in order:
Operating Activities
Net Income
Add: Depreciation
Changes in Working Capital
Net Operating Cash Flow (bold subtotal)
Investing Activities
Equipment Purchase
Net Investing Cash Flow (bold subtotal)
Financing Activities
Loan Repayment (red parentheses)
Net Financing Cash Flow (bold subtotal)
Net Cash Movement (bold, border above)
Opening Balance
Closing Balance (bold)

Reconciliation flags — critical feature
The system automatically checks three things every time a statement is uploaded or the period is changed. When a mismatch is detected, highlight the specific mismatched cell with a red background and a small warning icon inside the cell. Do not use a banner alert. The flag must be on the exact cell so the user knows precisely where the discrepancy is.
Three checks to visualise:
Check 1 — Net Profit on Income Statement must match the profit contribution in the Equity section of the Balance Sheet. If not, flag the Net Profit cell on the Income Statement and the Equity cell on the Balance Sheet simultaneously. Tooltip on both cells: "Net Profit (EGP 390,333) does not match Equity movement on Balance Sheet (EGP 368,000) — difference of EGP 22,333. Review operating expense entries."
Check 2 — Closing Balance on Cash Flow Statement must match Cash & Equivalents on Balance Sheet. If not, flag both cells. Tooltip: "Closing cash balance (EGP 5,277,836) does not match Cash & Equivalents on Balance Sheet (EGP 5,300,000) — difference of EGP 22,164. Review bank entries."
Check 3 — Revenue on Income Statement should align with deposit patterns in Upcoming Payments data. If materially different (more than 10% variance), flag the Revenue cell with an amber warning (not red — this is a softer check). Tooltip: "Revenue figure is 14% higher than bank deposit data for this period. Consider reconciling with bank statement."
Add a reconciliation status indicator at the top right of the Financial Statements section showing:
Green checkmark + "All statements reconciled" when no flags exist
Red warning + "2 reconciliation issues found" when flags exist, with a number badge

Upload flow — Finance Manager only
When the Finance Manager clicks Upload Statement, show the same upload component used in the Bank & Cash Visibility panel (drag and drop zone, PDF/JPG/PNG supported). After upload:
Processing state — "Reading your statement — this usually takes a few seconds"
Review state — extracted data populates the relevant statement table with all cells highlighted in amber indicating AI-extracted values. Banner at top of table: "Extracted by AI — please review each value before confirming." Every cell is editable. Confirm & Save button and Cancel button at top right.
Low confidence state — specific cells where the AI was uncertain are highlighted in red instead of amber with tooltip: "We couldn't read this value clearly — please enter manually." All other amber cells are still editable and saveable.
Confirmed state — amber highlighting removed, cells return to normal table style, last updated timestamp appears: "Last updated by Michael Chen — 10/05/2026 09:42"
Error state — "We could not read this file. Please upload a clear PDF or photo of the statement." with Retry button.
After confirmation the reconciliation check runs automatically and any flags appear immediately.

Role access summary
CFO — sees all three sub-tabs, sees reconciliation flags, sees variance column, sees download button, does not see upload button
Finance Manager — sees all three sub-tabs, sees upload button, edits and confirms extracted data, sees reconciliation flags after confirmation, sees download button
Cost Controller — sees Income Statement sub-tab only, no upload button, no download button, variance column visible, reconciliation flags not shown
Cost Analyst — sees Income Statement sub-tab only, same restrictions as Cost Controller
Department Manager — Financial Statements tab does not appear in navigation

Component reuse
Upload zone → reuse exact component from Bank & Cash Visibility upload screen
Amber cell highlight for AI-extracted values → reuse the same amber style used in the Bank & Cash Visibility review state
Red cell highlight for reconciliation flags → new style, red background with white text and warning icon inside cell
Download button → reuse existing export button style from Cost Analyst Generate Report tab
Reconciliation status indicator → reuse the existing KPI card component with green/red background

Navigation placement
CFO dashboard → Financial Statements appears as a new sixth tab after Ask CostAI in the top tab navigation
Finance Manager dashboard → Financial Statements appears as a new sixth tab after Ask CostAI in the top tab navigation
All other roles → tab does not appear

That is the complete brief for this module. Nothing else needs to be designed beyond what is specified here.



