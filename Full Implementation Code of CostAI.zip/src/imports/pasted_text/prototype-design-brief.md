Based on both expert feedbacks, here's a comprehensive breakdown of what the new prototype should look like:

---

# New Prototype — Post-Feedback Design Brief

## New User Roles (Updated)

The system now has **5 roles** instead of 4:
- CFO
- Finance Manager
- **Cost Controller** *(new — must be a first-class role)*
- Cost Analyst
- Department Manager

---

## 1. CFO Dashboard (Significantly Enriched)

### Tab 1.1 — Executive Overview (Redesigned)
The top row KPI cards must now show:
- **Cash Balance** (total across all accounts)
- **Burn Rate** — split into Gross Burn (total monthly expenses) and Net Burn (expenses minus revenue)
- **Runway** (cash balance ÷ burn rate)
- **Revenue vs. Forecast**

The middle section shows:
- Revenue chart
- Cost breakdown by department

The bottom section shows:
- Profitability metrics (gross profit, net profit, profit margin)
- Efficiency and liquidity ratios (built-in, labeled, sourced from standard financial references)

### New — Bank & Cash Visibility Panel
A dedicated bank table showing:
- Account name
- Balance per account
- Currency
- Total cash across all accounts

### New — Red Flag Alert Panel
Prominent, color-coded alerts triggered automatically when:
- A cost element enters a danger zone
- A liquidity ratio drops below a critical threshold
- Early signs of financial distress appear
- Asset mismanagement signals are detected

These are **strategic-level alerts**, distinct from operational transaction alerts, and must appear with higher visual urgency (e.g., bold red banners).

### New — Unusual Movements Panel
Automatically flags:
- Payments 3x higher than usual
- Unexpected large withdrawals
- Duplicate or suspicious transactions
- Sudden cash drops

Each alert must say specifically what happened (e.g., "Payment 3x higher than usual — Vendor: AWS Egypt — EGP 57,555") not just "anomaly detected."

### New — Upcoming Payments Section
Shows scheduled upcoming payments covering:
- Payroll
- Supplier invoices
- Loan repayments

### New — Built-in Financial Ratios Module
Embedded, clearly labeled financial equations covering:
- Liquidity ratios (current ratio, quick ratio)
- Profitability ratios (gross margin, net margin, ROE)
- Efficiency ratios (asset turnover)
- Solvency metrics (debt-to-equity)

CFO should not need to calculate these manually or refer to external sources.

### Tab 1.2 — Cost Forecast (Upgraded)
Same models (Linear Regression, ARIMA, Prophet) but now with:
- Forecasting at **cost element level** (wages, electricity, raw materials)
- Forecasting at **department level**
- Not just company-wide
- **Multi-currency support** — currencies split and handled independently with relevant exchange rates applied separately

### Tab 1.3 — Scenario Simulator (Upgraded)
- Same scenario types but now uses **Monte Carlo simulation** for probabilistic outputs instead of simple multipliers
- **Multi-currency environment support** — simulator must split currencies and apply exchange rates independently, not consolidate into one figure
- Outputs show probability distributions, not just a single projected number

### Tab 1.4 — Risk Indicators
Remains similar but now includes:
- Strategic red flag alerts integrated
- Cost element level risk view alongside department view

### Tab 1.5 — Ask CostAI (Upgraded NLP)
The NLP backend is upgraded from keyword-intent mapping to:
- **ML-based intent classification**
- **Named Entity Recognition (NER)** to identify departments, vendors, amounts in queries
- Responses **grounded directly in database queries** to prevent hallucinated outputs
- More reliable, flexible, and scalable

---

## 2. Finance Manager Dashboard (Minor Additions)

### Tab 2.1 — Expense Entry
- Add **document scanning** capability — user can photograph or upload physical financial statements and the system extracts and inserts data automatically, eliminating manual entry

### Tab 2.2 — Resource Allocation
- Now shows budget vs. actual at the **cost element level** as well as department level

### Tab 2.3 — KPI Dashboard
- Variance analysis now includes **cost element breakdowns**, not just department totals

### Tab 2.4 — Alerts & Anomalies (Upgraded)
- Alerts are now **tiered by severity** (operational vs. strategic)
- Alert messages are specific: "payment 3x higher than usual" not just "anomaly flagged"
- Alternative detection methods available: **Local Outlier Factor (LOF)**, **DBSCAN**, or **Autoencoder-based** detection alongside Z-score and Isolation Forest

### Tab 2.5 — Ask CostAI
Same upgraded NLP as CFO version.

---

## 3. NEW — Cost Controller Dashboard *(Entirely New Role)*

This is the most significant addition based on expert feedback. The Cost Controller is described as the backbone of cost management and must have a full dedicated workspace.

### Tab CC.1 — Cost Element Workspace
The Cost Controller defines which cost elements are relevant for the business type. Elements include:
- Wages & Salaries
- Electricity & Utilities
- Raw Materials
- Rent & Facilities
- Depreciation
- Contractor Fees
- Loan Repayments

This is **not a fixed list** — the Cost Controller configures it based on the nature of the business.

### Tab CC.2 — Budget Review & Challenge
Reflects the real budget-building workflow:
- **Top-down targets** set by CFO/CEO are visible
- **Bottom-up submissions** from departments arrive here
- Cost Controller reviews each submission, challenges unjustified requests, and removes misaligned items
- Approved budgets are consolidated into a company-wide budget
- Final budget is sent to CFO for approval, then to Board/CEO

### Tab CC.3 — Cost Analysis by Element
Deep-dive analysis showing costs broken down by:
- Cost element (wages, electricity, raw materials, etc.) — **not just by department**
- Budget vs. actual per cost element
- Variance per element
- This granular view is what reveals true inefficiencies

### Tab CC.4 — Contract & Rate Management
Access to:
- Contract rates per vendor
- Rental escalation clauses
- Salary structures
- Depreciation schedules
This gives the Cost Controller the context needed to validate and challenge costs.

### Tab CC.5 — Forecasting by Element & Department
- Forecasting at cost element level (e.g., will electricity costs exceed budget next quarter?)
- Forecasting at department level
- Budget vs. actual comparisons per quota

### Tab CC.6 — Monthly On-Track Reporting
Monthly report the Cost Controller sends to CFO covering:
- On-track / off-track status per department and per cost element
- Total depreciation summary
- Cost leakage indicators
- Asset management gaps
- Budget vs. actual at quota level

---

## 4. Cost Analyst Dashboard (Upgrades)

### Tab 3.2 — Anomaly Investigation (Upgraded)
Detection methods expanded to include:
- **Local Outlier Factor (LOF)**
- **DBSCAN**
- **Autoencoder-based detection**
Alongside existing Z-score and Isolation Forest.

### Tab 3.4 — Generate Report
Reports now include:
- Cost element level breakdowns
- Multi-currency handling
- On-track/off-track status per department

---

## 5. Department Manager Dashboard (Minor Changes)

### Tab 4.1 — My Dashboard
- Manager now sees their **submitted budget requests** and **approval status**
- Only sees their own department — access is strictly scoped

### Tab 4.4 — Alerts
- Alerts are more specific and tiered
- "Payment 3x higher than usual" language instead of generic anomaly labels

### Tab 4.5 — Weekly AI Summary
- Now includes pricing policy implications where relevant (how spending decisions affect margins)

---

## Key AI Upgrades Summary (For Figma Annotations)

| Feature | Old | New |
|---|---|---|
| NLP Engine | Keyword-intent matching | ML-based intent classification + NER |
| Forecasting | Company-wide only | Company + department + cost element level |
| Anomaly Detection | Z-score + Isolation Forest | + LOF, DBSCAN, Autoencoder |
| Scenario Simulation | Simple multipliers | Monte Carlo probabilistic simulation |
| Recommendations | Rule-based only | Data-driven + ranked by impact + explainable |
| Currency Handling | Single currency | Multi-currency with independent exchange rates |
| Explainability | Minimal | Feature importance shown for every AI output |

---

## New Global Features Across All Dashboards

- **Document scanning** — photograph financial statements, auto-extract data
- **Audit log** — every approval, adjustment, and AI output is traceable
- **Explainability layer** — every AI output shows *why* it was generated (why flagged, why forecasted, what factors drove the recommendation)
- **Tiered alert system** — operational alerts vs. strategic red flag alerts, visually distinct
- **Multi-currency support** throughout — all modules handle currencies independently